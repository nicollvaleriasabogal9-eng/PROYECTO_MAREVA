# MAREVA — Entrega Caribe

Esta entrega contiene el proyecto completo de MAREVA con backend Flask, frontend Jinja/CSS/JS, imágenes, SQL de base de datos y documentación.

## Cambios principales

- Sistema de gamificación basado en **niveles**, sin insignias.
- Eliminación de campos de **dirección** del cliente, proveedor y alojamiento.
- Registro con aceptación obligatoria de **Política de No Reembolso**.
- Registro de fecha/hora y versión de la política aceptada en la BD.
- Política completa disponible en `docs/POLITICA_NO_REEMBOLSO_MAREVA.md` y dentro del registro mediante modal.
- Identidad visual Caribe MAREVA: morado, mar/turquesa, arena, verde tropical, amarillo sol y coral, usados como acentos para evitar saturación.
- Navegación reforzada con accesos visibles a destinos, paquetes, comparación, favoritos y niveles.

## Base de datos

- Fuente completa: `database/mareva_unificado.sql`
- Migración para una base existente: `database/migracion_caribe_2026.sql`

La migración elimina deliberadamente las tablas de insignias y los campos de dirección indicados. Haz respaldo antes de ejecutarla sobre una base con datos.

## Accesos de demostración

- Admin: `cesar@mareva.co` / `Admin_mareva01`
- Guía: `andres.guia@mareva.co` / `Guia123`
- Cliente: `yadira@test.co` / `cliente_prueba`

## Nota legal

La política incluida es una propuesta funcional para el prototipo. No debe considerarse asesoría jurídica ni un documento contractual definitivo sin revisión profesional en Colombia. La redacción evita presentar la regla de no reembolso como absoluta y conserva las excepciones que puedan resultar obligatorias.

## Iteración UX 2026 — mejoras de navegación y operación

- Inicio renovado con buscador multicriterio sin registro, promociones activas con carrusel y flechas, más paquetes visibles y categorías con color propio.
- Catálogo público con filtros de destino, categoría, duración, rango de precio, fecha, servicios incluidos, disponibilidad y ordenamiento.
- Destinos conectados directamente con sus paquetes relacionados.
- Comparador ampliado con precio, destino, duración, fechas, cupos, personalización, servicios, extras y guía.
- Detalle de paquete con CTA de reserva claramente visible.
- Reserva rediseñada por pasos, calendario visual, datos de viajeros e idioma, personalización y resumen lateral.
- La política de no reembolso se acepta únicamente durante el registro; la reserva reutiliza esa aceptación registrada en la cuenta.
- Perfil: actualización de correo con las mismas reglas del registro y cambio de contraseña con validación de contraseña actual.
- Pie de página con medios de pago representados visualmente (sin afirmar una pasarela real integrada).
- Administración: edición/activación/desactivación de paquetes y destinos. Un paquete con reservas activas no puede suspenderse normalmente.
- Protocolo de contingencia: el administrador puede cancelar reservas por una causa extraordinaria documentada; las reservas quedan en `reembolso_estado = pendiente` y luego pueden marcarse como `realizado`.
- Guía: cada viajero registra su idioma preferido y el panel del guía muestra esa información por reserva.
- Video recomendado para la portada: campaña oficial de Colombia difundida por MinCIT/Colombia Travel.

### Migración de base de datos

Ejecutar `database/migracion_caribe_2026.sql` sobre una base existente antes de usar las funciones nuevas. La migración agrega los campos de contingencia/reembolso y el idioma de cada viajero.
