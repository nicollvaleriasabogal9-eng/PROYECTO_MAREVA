from flask import (
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

from services.reserva_services import ReservaService
from services.paquete_services import PaqueteService
from services.pdf_services import PDFService
from repositories.salida_repository import SalidaRepository


class ReservaController:

    def __init__(self):

        self.service = ReservaService()

        self.paquete_service = PaqueteService()

        self.pdf_service = PDFService()

        self.salida_repository = SalidaRepository()


    # =========================================================
    # MOSTRAR FORMULARIO
    # =========================================================

    def mostrar_formulario(
        self,
        slug
    ):

        paquete = (
            self.paquete_service.obtener_detalle(
                slug
            )
        )


        if not paquete:

            return redirect(
                url_for(
                    "paquetes.listar_catalogo"
                )
            )


        salidas = (
            self.salida_repository.obtener_por_paquete(
                paquete["id_paquete"],
                solo_disponibles=True
            )
        )


        return render_template(
            "cliente/reserva.html",
            paquete=paquete,
            salidas=salidas
        )


    # =========================================================
    # CONFIRMAR RESERVA
    # =========================================================

    def confirmar(
        self,
        slug
    ):

        usuario = session.get("usuario")


        if not usuario:

            return redirect(
                url_for(
                    "auth.mostrar_login",
                    next=f"/reserva/{slug}"
                )
            )


        paquete = (
            self.paquete_service.obtener_detalle(
                slug
            )
        )


        if not paquete:

            return redirect(
                url_for(
                    "paquetes.listar_catalogo"
                )
            )


        # -----------------------------------------------------
        # SALIDA SELECCIONADA
        # -----------------------------------------------------

        id_salida = (
            request.form
            .get("id_salida", "")
            .strip()
        )


        if not id_salida:

            salidas = (
                self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                )
            )


            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=salidas,
                error=(
                    "Debes seleccionar una fecha "
                    "de salida."
                )
            )


        try:

            id_salida = int(id_salida)

        except (
            ValueError,
            TypeError
        ):

            salidas = (
                self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                )
            )


            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=salidas,
                error=(
                    "La fecha seleccionada "
                    "no es válida."
                )
            )


        salida = (
            self.salida_repository.obtener_por_id(
                id_salida
            )
        )


        if not salida:

            salidas = (
                self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                )
            )


            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=salidas,
                error=(
                    "La salida seleccionada "
                    "no existe."
                )
            )


        if salida["id_paquete"] != paquete["id_paquete"]:

            salidas = (
                self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                )
            )


            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=salidas,
                error=(
                    "La fecha seleccionada "
                    "no pertenece a este paquete."
                )
            )


        if salida["estado"] not in (
            "programada",
            "disponible"
        ):

            salidas = (
                self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                )
            )


            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=salidas,
                error=(
                    "La fecha seleccionada "
                    "ya no está disponible."
                )
            )


        fecha_viaje = salida["fecha_salida"]


        # -----------------------------------------------------
        # CANTIDAD DE VIAJEROS
        # -----------------------------------------------------

        try:

            adultos = max(
                1,
                int(
                    request.form.get(
                        "adultos",
                        "1"
                    )
                )
            )

            menores = max(
                0,
                int(
                    request.form.get(
                        "menores",
                        "0"
                    )
                )
            )

        except (
            ValueError,
            TypeError
        ):

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                ),
                error=(
                    "La cantidad de viajeros "
                    "no es válida."
                )
            )


        total_personas = (
            adultos + menores
        )


        if total_personas < 1:

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                ),
                error=(
                    "Debes ingresar al menos "
                    "un viajero."
                )
            )


        # -----------------------------------------------------
        # DATOS GENERALES
        # -----------------------------------------------------

        alergias = (
            request.form
            .get("alergias", "")
            .strip()
        )


        observaciones = (
            request.form
            .get("observaciones", "")
            .strip()
        )


        plan = (
            request.form
            .get("plan", "completo")
            .strip()
        )


        mascotas = (
            request.form
            .get("mascotas", "no")
            .strip()
            .lower()
            == "si"
        )


        metodo_contacto = (
            request.form
            .get("metodo_contacto", "correo")
            .strip()
        )


        acepta = (
            usuario.get(
                "acepta_politica_no_reembolso",
                False
            )
        )


        if not acepta:

            acepta = (
                request.form
                .get(
                    "acepta_no_reembolso"
                )
                == "1"
            )


        if not acepta:

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                ),
                error=(
                    "Debes aceptar la política "
                    "de no reembolso."
                )
            )


        # -----------------------------------------------------
        # VIAJEROS
        # -----------------------------------------------------

        nombres = request.form.getlist(
            "viajero_nombre[]"
        )

        apellidos = request.form.getlist(
            "viajero_apellido[]"
        )

        tipos = request.form.getlist(
            "viajero_tipo_documento[]"
        )

        documentos = request.form.getlist(
            "viajero_documento[]"
        )

        idiomas = request.form.getlist(
            "viajero_idioma[]"
        )


        if (
            len(nombres) != total_personas
            or len(apellidos) != total_personas
            or len(tipos) != total_personas
            or len(documentos) != total_personas
            or len(idiomas) != total_personas
        ):

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                ),
                error=(
                    "Debes completar los datos "
                    "de todos los viajeros."
                )
            )


        viajeros = []


        for i in range(total_personas):

            nombre = nombres[i].strip()

            apellido = apellidos[i].strip()

            tipo = tipos[i].strip()

            documento = documentos[i].strip()

            idioma = idiomas[i].strip()


            if (
                not nombre
                or not apellido
                or not tipo
                or not documento
                or not idioma
            ):

                return render_template(
                    "cliente/reserva.html",
                    paquete=paquete,
                    salidas=self.salida_repository.obtener_por_paquete(
                        paquete["id_paquete"],
                        solo_disponibles=True
                    ),
                    error=(
                        f"Completa los datos "
                        f"del viajero {i + 1}."
                    )
                )


            viajeros.append(
                {
                    "nombre": nombre,
                    "apellido": apellido,
                    "tipo_documento": tipo,
                    "numero_documento": documento,
                    "idioma": idioma
                }
            )


        # -----------------------------------------------------
        # SERVICIOS EXTRA
        # -----------------------------------------------------

        extras_ids = []


        for extra in request.form.getlist(
            "extras"
        ):

            try:

                extras_ids.append(
                    int(extra)
                )

            except (
                ValueError,
                TypeError
            ):

                continue


        # -----------------------------------------------------
        # CLIENTE
        # -----------------------------------------------------

        id_cliente = (
            usuario.get("id")
            or usuario.get("id_cliente")
        )


        # -----------------------------------------------------
        # VALOR REFERENCIAL
        # -----------------------------------------------------

        try:

            precio = float(
                paquete.get(
                    "precio",
                    0
                ) or 0
            )

        except (
            ValueError,
            TypeError
        ):

            precio = 0


        valor_referencial = (
            precio * total_personas
        )


        # -----------------------------------------------------
        # DATOS DE RESERVA
        # -----------------------------------------------------

        resultado = (
            self.service.confirmar_reserva(

                id_cliente=id_cliente,

                id_paquete=paquete[
                    "id_paquete"
                ],

                id_salida=id_salida,

                fecha_viaje=fecha_viaje,

                cant_adultos=adultos,

                cant_menores=menores,

                observaciones=observaciones,

                acepta_no_reembolso=acepta,

                alergias=alergias,

                mascotas=mascotas,

                plan=plan,

                metodo_contacto=metodo_contacto,

                extras_ids=extras_ids,

                viajeros=viajeros

            )
        )


        if not resultado:

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                ),
                error=(
                    "No fue posible registrar "
                    "la reserva."
                )
            )


        if not resultado.get("ok"):

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                salidas=self.salida_repository.obtener_por_paquete(
                    paquete["id_paquete"],
                    solo_disponibles=True
                ),
                error=resultado.get(
                    "error",
                    "No fue posible registrar "
                    "la reserva."
                )
            )


        # -----------------------------------------------------
        # DETALLE PARA CONFIRMACIÓN
        # -----------------------------------------------------

        detalle = resultado.copy()


        detalle.update(
            {
                "paquete": paquete,

                "id_salida": id_salida,

                "fecha_viaje": fecha_viaje,

                "fecha_regreso": (
                    salida["fecha_regreso"]
                ),

                "cant_adultos": adultos,

                "cant_menores": menores,

                "total_personas": total_personas,

                "valor_referencial":
                    valor_referencial,

                "viajeros": viajeros,

                "estado":
                    detalle.get(
                        "estado",
                        "solicitada"
                    ),

                "pago_directo": True
            }
        )


        session["detalle_reserva"] = detalle


        return redirect(
            url_for(
                "reserva.confirmacion"
            )
        )


    # =========================================================
    # CONFIRMACIÓN
    # =========================================================

    def mostrar_confirmacion(self):

        detalle = session.get(
            "detalle_reserva"
        )


        if not detalle:

            return redirect(
                url_for(
                    "paquetes.listar_catalogo"
                )
            )


        return render_template(
            "principal/reserva_confirmada.html",
            reserva=detalle,
            detalle=detalle
        )


    # =========================================================
    # PDF
    # =========================================================

    def descargar_pdf(self):

        detalle = session.get(
            "detalle_reserva"
        )


        if not detalle:

            return redirect(
                url_for(
                    "paquetes.listar_catalogo"
                )
            )


        return self.pdf_service.generar_resumen_reserva(
            detalle
        )