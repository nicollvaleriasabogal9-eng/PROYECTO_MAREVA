/* LIMPIAR EL TEXTO QUITANDO ACENTOS, ESPACIOS EXTRA Y PASANDO A MINÚSCULAS */
function normalizar(str) {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

/* LEER LOS VALORES MARCADOS DE UN GRUPO DE CHECKBOXES DENTRO DE UN FIELDSET */
function valoresMarcados(selectorGrupo) {
  return Array.from(document.querySelectorAll(`${selectorGrupo} input[type="checkbox"]:checked`))
    .map(c => c.value);
}

/* EVALUAR Y MOSTRAR U OCULTAR LAS TARJETAS SEGÚN TODOS LOS FILTROS ACTIVOS */
function aplicarFiltros() {
  const texto = normalizar(document.getElementById("searchInput")?.value || "");
  const categoria = document.getElementById("categoria")?.value || "todos";
  const precio = parseInt(document.getElementById("precioRange")?.value || 9999999);
  const ciudad = document.getElementById("ciudad")?.value || "todas";

  const duracionesMarcadas = valoresMarcados("#filtroDuracion");
  const incluyeMarcados = valoresMarcados("#filtroIncluye");

  const cards = document.querySelectorAll(".card[data-categoria]");
  let visibles = 0;

  cards.forEach(card => {
    const titulo = normalizar(card.querySelector(".card__title")?.textContent || "");
    const desc = normalizar(card.querySelector(".card__desc")?.textContent || "");
    const cat = card.dataset.categoria;
    const precioCard = parseInt(card.dataset.precio || "0");
    const duracionCard = card.dataset.duracion || "";
    const incluyeCard = (card.dataset.incluye || "").split(" ").filter(Boolean);
    const ciudadCard = card.dataset.ciudad || "";

    const matchTexto = texto === "" || titulo.includes(texto) || desc.includes(texto);
    const matchCat = categoria === "todos" || cat === categoria;
    const matchPrecio = precioCard <= precio;
    const matchCiudad = ciudad === "todas" || ciudadCard === ciudad;

    /* SI NO HAY NINGUNA DURACIÓN MARCADA, NO FILTRA POR ESTE CRITERIO */
    const matchDuracion = duracionesMarcadas.length === 0 || duracionesMarcadas.includes(duracionCard);

    /* LA TARJETA DEBE INCLUIR TODOS LOS SERVICIOS MARCADOS (NO SOLO UNO) */
    const matchIncluye = incluyeMarcados.length === 0 ||
      incluyeMarcados.every(item => incluyeCard.includes(item));

    const mostrar = matchTexto && matchCat && matchPrecio && matchCiudad && matchDuracion && matchIncluye;
    card.style.display = mostrar ? "" : "none";
    if (mostrar) visibles++;
  });

  const contador = document.getElementById("totalPaquetes");
  if (contador) contador.textContent = visibles;

  const noResultados = document.getElementById("noResultados");
  if (noResultados) noResultados.hidden = visibles !== 0;
}

/* ORDENAR LAS TARJETAS VISIBLES SEGÚN EL CRITERIO ELEGIDO (PRECIO O DÍAS) */
function ordenarPaquetes() {
  const criterio = document.getElementById("ordenarPor")?.value || "relevancia";
  const contenedor = document.getElementById("paquetesGrid");
  const tarjetas = Array.from(contenedor.querySelectorAll(".card[data-categoria]"));

  const comparadores = {
    "precio_asc":  (a, b) => parseInt(a.dataset.precio) - parseInt(b.dataset.precio),
    "precio_desc": (a, b) => parseInt(b.dataset.precio) - parseInt(a.dataset.precio),
    "dias_asc":    (a, b) => parseInt(a.dataset.dias || 0) - parseInt(b.dataset.dias || 0),
    "dias_desc":   (a, b) => parseInt(b.dataset.dias || 0) - parseInt(a.dataset.dias || 0),
  };

  if (comparadores[criterio]) {
    tarjetas.sort(comparadores[criterio]);
    tarjetas.forEach(t => contenedor.appendChild(t));
  }
}

/* DETENER EL ENVÍO DEL FORMULARIO Y PROCESAR LA BÚSQUEDA CON EL SISTEMA GENERAL */
function buscarPaquete(event) {
  if (event) event.preventDefault();
  aplicarFiltros();
}

/* LEER LOS PARÁMETROS DE LA URL PARA COPIAR EL TEXTO DE BÚSQUEDA EN EL INPUT */
function filtrarPorQuery() {
  const params = new URLSearchParams(window.location.search);
  const query = params.get("q");
  if (!query) return;

  const input = document.getElementById("searchInput");
  if (input) input.value = query;

  aplicarFiltros();
}

/* ACTUALIZAR EL TEXTO DE PRECIO EN LA INTERFAZ CON FORMATO DE MONEDA LOCAL */
function actualizarPrecio(valor) {
  const label = document.getElementById("precioValor");
  if (label) {
    label.textContent = "$" + Number(valor).toLocaleString("es-CO");
  }
  aplicarFiltros();
}

/*  INIT (CARGA AUTOMÁTICA)*/
document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const q = params.get("q");
  if (q) {
    const input = document.getElementById("searchInput");
    if (input) input.value = q;
  }

  aplicarFiltros();
});