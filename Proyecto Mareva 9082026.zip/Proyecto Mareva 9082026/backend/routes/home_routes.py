from flask import Blueprint, render_template, redirect, session, url_for
from services.paquete_services import PaqueteService

home_bp = Blueprint('home', __name__)
paquete_service = PaqueteService()

@home_bp.route("/")
def home():
    destacados = paquete_service.listar_activos()[:6]
    return render_template("principal/index.html", destacados=destacados)

@home_bp.route("/perfil")
def perfil():
    if 'usuario' not in session:
        return redirect(url_for('auth.mostrar_login'))
    return render_template("cliente/perfil.html", usuario=session['usuario'])

@home_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home.home'))