from config.conexion import Conexion
from models.cliente import Cliente
from werkzeug.security import generate_password_hash
from psycopg.errors import UniqueViolation


class AuthRepository:

    def __init__(self):
        self.conexion = Conexion().obtener_conexion()

    def guardar_usuario(self, nombre, apellido, tipo_documento, numero_documento, telefono, codigo, correo, password):
        cursor = self.conexion.cursor()
        password_hash = generate_password_hash(password)

        try:
            cursor.execute("""INSERT INTO cliente(nombre, apellido, tipo_documento, numero_documento, telefono, correo, contrasena)
                            VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                            (nombre, apellido, tipo_documento, numero_documento, telefono, correo, password_hash))

            self.conexion.commit()
            cursor.close()
            return {"ok": True}

        except UniqueViolation as e:
            self.conexion.rollback()
            cursor.close()

            mensaje = str(e)
            if "cliente_correo_key" in mensaje:
                return {"ok": False, "campo": "correo", "error": "Ese correo ya está registrado."}
            elif "cliente_numero_documento_key" in mensaje:
                return {"ok": False, "campo": "numero_documento", "error": "Ese número de documento ya está registrado."}
            else:
                return {"ok": False, "campo": None, "error": "Ya existe un usuario con esos datos."}

        except Exception:
            self.conexion.rollback()
            cursor.close()
            return {"ok": False, "campo": None, "error": "No fue posible completar el registro. Intenta de nuevo."}

    def buscar_por_correo(self, correo):
        cursor = self.conexion.cursor()

        try:
            cursor.execute("SELECT * FROM cliente WHERE correo = %s", (correo,))
            fila = cursor.fetchone()
            cursor.close()
        except Exception:
            self.conexion.rollback()
            cursor.close()
            return None

        if fila is None:
            return None

        usuario = Cliente(
            fila[0],
            fila[1],
            fila[2],
            fila[3],
            fila[4],
            fila[5],
            fila[6],
            fila[7],
            fila[8],
            fila[9],
            fila[10],
            fila[11],
            fila[12],
            fila[13],
            fila[14]
        )

        return usuario

    def obtener_password_por_correo(self, correo):
        cursor = self.conexion.cursor()

        try:
            cursor.execute("SELECT contrasena FROM cliente WHERE correo = %s", (correo,))
            fila = cursor.fetchone()
            cursor.close()
        except Exception:
            self.conexion.rollback()
            cursor.close()
            return None

        if fila is None:
            return None

        return fila[0]

    def obtener_todos_id_password(self):
        cursor = self.conexion.cursor()

        try:
            cursor.execute("SELECT id, contrasena FROM cliente")
            filas = cursor.fetchall()
            cursor.close()
            return filas
        except Exception:
            self.conexion.rollback()
            cursor.close()
            return []