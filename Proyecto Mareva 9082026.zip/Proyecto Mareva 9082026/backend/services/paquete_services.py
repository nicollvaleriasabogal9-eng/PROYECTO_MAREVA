import re
import unicodedata
from repositories.paquete_repository import PaqueteRepository
from models.paquete import factory_paquete


class PaqueteService:

    def __init__(self):
        self.repo = PaqueteRepository()

    def listar_activos(self):
        paquetes = [factory_paquete(p).to_dict() for p in self.repo.obtener_todos(solo_activos=True)]
        for p in paquetes:
            p["incluye"] = self.repo.obtener_incluye(p["id_paquete"])
        return paquetes

    def listar_todos_admin(self):
        return [factory_paquete(p).to_dict() for p in self.repo.obtener_todos(solo_activos=False)]

    def obtener_detalle(self, slug):
        data = self.repo.obtener_por_slug(slug)
        if not data:
            return None
        paquete = factory_paquete(data).to_dict()
        paquete["servicios_extra"] = self.repo.obtener_servicios_extra(data["id_paquete"])
        return paquete

    def obtener_para_editar(self, id_paquete):
        data = self.repo.obtener_por_id(id_paquete)
        return data

    def datos_formulario(self):
        return {
            "destinos": self.repo.obtener_destinos(),
            "guias": self.repo.obtener_guias(),
        }

    def crear_paquete(self, datos):
        datos["slug"] = self._generar_slug(datos["nombre"])
        return self.repo.crear(datos)

    def actualizar_paquete(self, id_paquete, datos):
        return self.repo.actualizar(id_paquete, datos)

    def suspender(self, id_paquete):
        return self.repo.cambiar_estado(id_paquete, "suspendido")

    def activar(self, id_paquete):
        return self.repo.cambiar_estado(id_paquete, "activo")

    @staticmethod
    def _generar_slug(nombre):
        texto = unicodedata.normalize("NFKD", nombre).encode("ascii", "ignore").decode()
        texto = texto.lower().strip()
        return re.sub(r"[^a-z0-9]+", "-", texto).strip("-")
    
def obtener_disponibilidad(self, id_paquete):
    return self.repo.obtener_disponibilidad(id_paquete)