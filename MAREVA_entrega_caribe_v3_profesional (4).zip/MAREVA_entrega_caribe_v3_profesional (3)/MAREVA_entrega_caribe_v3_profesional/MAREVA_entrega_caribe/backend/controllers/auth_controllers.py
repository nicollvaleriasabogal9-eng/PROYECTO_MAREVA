from flask import redirect, url_for, request, render_template, session
from services.auth_services import AuthServices
import re
import phonenumbers


class AuthController:

    def __init__(self):
        self.service = AuthServices()

    def registrar_usuario(self):

        nombre = " ".join(
            request.form.get("nombre", "").split()
        )

        apellido = " ".join(
            request.form.get("apellido", "").split()
        )

        tipo = request.form.get(
            "tipo",
            ""
        ).strip()

        numero = request.form.get(
            "numero",
            ""
        ).strip()

        telefono = request.form.get(
            "telefono",
            ""
        ).strip()

        codigo = request.form.get(
            "codigo",
            ""
        ).strip()

        correo = request.form.get(
            "correo",
            ""
        ).strip().lower()

        password = request.form.get(
            "password",
            ""
        )

        confirm_password = request.form.get(
            "confirm_password",
            ""
        )

        terminos = request.form.get(
            "terminos"
        )

        acepta_politica = request.form.get(
            "politica_no_reembolso"
        )

        if not re.fullmatch(
            r"[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,50}",
            nombre
        ):
            return render_template(
                "principal/registro.html",
                error="El nombre solo puede contener letras."
            )

        if not re.fullmatch(
            r"[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,50}",
            apellido
        ):
            return render_template(
                "principal/registro.html",
                error="El apellido solo puede contener letras."
            )

        tipos = [
            "CC",
            "TI",
            "CE",
            "PA",
            "PEP",
            "PPT",
            "RC"
        ]

        if tipo not in tipos:
            return render_template(
                "principal/registro.html",
                error="Seleccione un documento válido."
            )

        reglas_documento = {
            "CC": r"\d{6,10}",
            "TI": r"\d{10}",
            "CE": r"\d{6,7}",
            "PA": r"[A-Za-z0-9]{6,12}"
        }

        if (
            tipo in reglas_documento
            and not re.fullmatch(
                reglas_documento[tipo],
                numero
            )
        ):
            return render_template(
                "principal/registro.html",
                error="El número de documento no es válido."
            )

        try:

            if not telefono.startswith("+"):
                return render_template(
                    "principal/registro.html",
                    error="Ingrese un teléfono válido."
                )

            numero_tel = phonenumbers.parse(
                telefono,
                None
            )

            if not phonenumbers.is_valid_number(
                numero_tel
            ):
                return render_template(
                    "principal/registro.html",
                    error=(
                        "El teléfono no es válido "
                        "para el país seleccionado."
                    )
                )

        except phonenumbers.NumberParseException:

            return render_template(
                "principal/registro.html",
                error="Ingrese un teléfono válido."
            )

        if codigo and not re.fullmatch(
            r"[A-Za-z0-9]{1,20}",
            codigo
        ):
            return render_template(
                "principal/registro.html",
                error="Código de referido inválido."
            )

        correo_valido = (
            r"^[a-zA-Z0-9._%+-]+"
            r"@(gmail|outlook|hotmail|live|yahoo)"
            r"\.(com|es|co)$"
        )

        if not re.fullmatch(
            correo_valido,
            correo
        ):
            return render_template(
                "principal/registro.html",
                error=(
                    "Solo se permiten correos Gmail, "
                    "Outlook, Hotmail/Live o Yahoo."
                )
            )

        if not terminos:
            return render_template(
                "principal/registro.html",
                error=(
                    "Debes aceptar los términos "
                    "y condiciones."
                )
            )

        if not acepta_politica:
            return render_template(
                "principal/registro.html",
                error=(
                    "Debes leer y aceptar la Política "
                    "de No Reembolso para crear tu cuenta."
                )
            )

        if password != confirm_password:
            return render_template(
                "principal/registro.html",
                error="Las contraseñas no coinciden."
            )

        if not (
            len(password) >= 8
            and re.search(
                r"[A-ZÁÉÍÓÚÑ]",
                password
            )
            and re.search(
                r"\d",
                password
            )
            and re.search(
                r"[^A-Za-z0-9]",
                password
            )
        ):
            return render_template(
                "principal/registro.html",
                error=(
                    "La contraseña debe tener mínimo "
                    "8 caracteres, mayúscula, número "
                    "y carácter especial."
                )
            )

        resultado = self.service.registrar_usuario(
            nombre,
            apellido,
            tipo,
            numero,
            telefono,
            codigo,
            correo,
            password,
            True
        )

        if resultado["ok"]:

            return render_template(
                "principal/login.html",
                mensaje=(
                    "Registro exitoso. "
                    "Ahora inicia sesión."
                )
            )

        return render_template(
            "principal/registro.html",
            error=resultado["error"]
        )

    def iniciar_sesion(self):

        correo = request.form.get(
            "correo",
            ""
        ).strip().lower()

        password = request.form.get(
            "password",
            ""
        )

        usuario = self.service.iniciar_sesion(
            correo,
            password
        )

        if usuario is None:

            return render_template(
                "principal/login.html",
                error="Correo o contraseña incorrectos.",
                correo=correo
            )

        recordar = request.form.get(
            "recordar"
        )

        session.permanent = bool(
            recordar
        )

        self._guardar_sesion(
            usuario
        )

        return self._redirigir_por_rol(
            request.args.get("next")
            or request.form.get("next")
        )

    def iniciar_sesion_google(self):

        resultado = self.service.crear_url_google()

        if not resultado.get("ok"):

            return render_template(
                "principal/login.html",
                error=resultado.get(
                    "error",
                    "No fue posible iniciar sesión con Google."
                )
            )

        session["google_state"] = resultado["state"]

        return redirect(
            resultado["url"]
        )

    def google_callback(self):

        error = request.args.get(
            "error"
        )

        if error:

            return render_template(
                "principal/login.html",
                error=(
                    "Google canceló o rechazó "
                    "el inicio de sesión."
                )
            )

        state = request.args.get(
            "state",
            ""
        )

        state_guardado = session.pop(
            "google_state",
            ""
        )

        if (
            not state
            or not state_guardado
            or state != state_guardado
        ):

            return render_template(
                "principal/login.html",
                error=(
                    "La solicitud de Google no es válida. "
                    "Vuelve a intentarlo."
                )
            )

        code = request.args.get(
            "code",
            ""
        )

        if not code:

            return render_template(
                "principal/login.html",
                error=(
                    "Google no devolvió el código "
                    "de autorización."
                )
            )

        resultado = self.service.procesar_codigo_google(
            code
        )

        if not resultado.get("ok"):

            return render_template(
                "principal/login.html",
                error=resultado.get(
                    "error",
                    "No fue posible iniciar sesión con Google."
                )
            )

        usuario = resultado["usuario"]

        session.permanent = True

        self._guardar_sesion(
            usuario
        )

        session["auth_google"] = True

        return self._redirigir_por_rol()

    def _guardar_sesion(
        self,
        usuario
    ):

        session["usuario"] = {
            "id": (
                usuario.id
                if hasattr(usuario, "id")
                else usuario["id"]
            ),
            "nombre": (
                usuario.nombre
                if hasattr(usuario, "nombre")
                else usuario["nombre"]
            ),
            "apellido": (
                usuario.apellido
                if hasattr(usuario, "apellido")
                else usuario.get("apellido")
            ),
            "correo": (
                usuario.correo
                if hasattr(usuario, "correo")
                else usuario["correo"]
            ),
            "rol": (
                usuario.rol
                if hasattr(usuario, "rol")
                else usuario["rol"]
            ),
            "acepta_politica_no_reembolso": getattr(
                usuario,
                "acepta_politica_no_reembolso",
                True
            )
        }

        if session["usuario"]["rol"] == "cliente":

            session["favoritos"] = (
                self.service.favoritos(
                    session["usuario"]["id"]
                )
            )

        print(
            "Usuario autenticado:",
            session["usuario"]["correo"]
        )

    def _redirigir_por_rol(
        self,
        next_url=None
    ):

        rol = session["usuario"]["rol"]

        if rol == "admin":

            return redirect(
                url_for(
                    "dashboard.mostrar_panel"
                )
            )

        if rol == "guia":

            return redirect(
                url_for(
                    "guia.panel"
                )
            )

        if rol == "proveedor":

            return redirect(
                url_for(
                    "home.home"
                )
            )

        if (
            next_url
            and next_url.startswith("/")
            and not next_url.startswith("//")
        ):

            return redirect(
                next_url
            )

        return redirect(
            url_for(
                "home.home"
            )
        )