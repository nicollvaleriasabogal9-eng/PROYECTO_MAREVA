from config.conexion import Conexion
from models.cliente import Cliente
from werkzeug.security import generate_password_hash
from psycopg.errors import UniqueViolation
import secrets


class AuthRepository:

    def __init__(self):
        self.conexion = (
            Conexion().obtener_conexion()
        )

    def guardar_usuario(
        self,
        nombre,
        apellido,
        tipo_documento,
        numero_documento,
        telefono,
        codigo,
        correo,
        password,
        acepta_politica_no_reembolso=False
    ):

        cursor = self.conexion.cursor()

        password_hash = (
            generate_password_hash(
                password
            )
        )

        try:

            cursor.execute(
                """
                INSERT INTO cliente(
                    nombre,
                    apellido,
                    tipo_documento,
                    numero_documento,
                    telefono,
                    correo,
                    contrasena,
                    acepta_politica_no_reembolso,
                    fecha_aceptacion_politica,
                    version_politica
                )
                VALUES(
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    CURRENT_TIMESTAMP,
                    '1.0'
                )
                """,
                (
                    nombre,
                    apellido,
                    tipo_documento,
                    numero_documento,
                    telefono,
                    correo,
                    password_hash,
                    acepta_politica_no_reembolso
                )
            )

            self.conexion.commit()
            cursor.close()

            return {
                "ok": True
            }

        except UniqueViolation as e:

            self.conexion.rollback()
            cursor.close()

            mensaje = str(e)

            if "cliente_correo_key" in mensaje:

                return {
                    "ok": False,
                    "campo": "correo",
                    "error": (
                        "Ese correo ya está registrado."
                    )
                }

            if "cliente_numero_documento_key" in mensaje:

                return {
                    "ok": False,
                    "campo": "numero_documento",
                    "error": (
                        "Ese número de documento "
                        "ya está registrado."
                    )
                }

            return {
                "ok": False,
                "campo": None,
                "error": (
                    "Ya existe un usuario "
                    "con esos datos."
                )
            }

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR guardar_usuario:",
                repr(e)
            )

            return {
                "ok": False,
                "campo": None,
                "error": (
                    "No fue posible completar el registro. "
                    "Intenta de nuevo."
                )
            }

    def buscar_por_correo(
        self,
        correo
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT *
                FROM cliente
                WHERE correo = %s
                """,
                (correo,)
            )

            fila = cursor.fetchone()

            cursor.close()

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR buscar_por_correo:",
                repr(e)
            )

            return None

        if fila is None:
            return None

        return Cliente(
            fila[0],
            fila[1],
            fila[2],
            fila[3],
            fila[4],
            fila[5],
            fila[6],
            fila[7],
            fila[8],
            fila[9],
            fila[10],
            fila[11],
            fila[12],
            fila[13],
            fila[14],
            fila[15],
            fila[16],
            fila[17]
        )

    def estado_acceso_cliente(
        self,
        correo
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT
                id_cliente,
                estado,
                intentos_fallidos,
                bloqueado_hasta
            FROM cliente
            WHERE correo = %s
            """,
            (correo,)
        )

        fila = cursor.fetchone()

        cursor.close()

        return fila

    def registrar_intento_fallido(
        self,
        correo,
        bloquear_hasta=None
    ):

        cursor = self.conexion.cursor()

        if bloquear_hasta:

            cursor.execute(
                """
                UPDATE cliente
                SET
                    intentos_fallidos = 5,
                    bloqueado_hasta = %s
                WHERE correo = %s
                """,
                (
                    bloquear_hasta,
                    correo
                )
            )

        else:

            cursor.execute(
                """
                UPDATE cliente
                SET intentos_fallidos =
                    intentos_fallidos + 1
                WHERE correo = %s
                """,
                (correo,)
            )

        self.conexion.commit()
        cursor.close()

    def limpiar_intentos(
        self,
        correo
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            UPDATE cliente
            SET
                intentos_fallidos = 0,
                bloqueado_hasta = NULL
            WHERE correo = %s
            """,
            (correo,)
        )

        self.conexion.commit()
        cursor.close()

    def obtener_password_por_correo(
        self,
        correo
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT contrasena
                FROM cliente
                WHERE correo = %s
                """,
                (correo,)
            )

            fila = cursor.fetchone()

            cursor.close()

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR obtener_password_por_correo:",
                repr(e)
            )

            return None

        if fila is None:
            return None

        return fila[0]

    def obtener_todos_id_password(
        self
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT id_cliente, contrasena
                FROM cliente
                """
            )

            filas = cursor.fetchall()

            cursor.close()

            return filas

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR obtener_todos_id_password:",
                repr(e)
            )

            return []

    def buscar_guia_por_correo(
        self,
        correo
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    id_guia,
                    nombre,
                    apellido,
                    correo,
                    contrasena,
                    estado
                FROM guia_turistico
                WHERE correo = %s
                """,
                (correo,)
            )

            fila = cursor.fetchone()

            cursor.close()

            if fila is None:
                return None

            return {
                "id": fila[0],
                "nombre": fila[1],
                "apellido": fila[2],
                "correo": fila[3],
                "contrasena": fila[4],
                "estado": fila[5],
                "rol": "guia"
            }

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR buscar_guia_por_correo:",
                repr(e)
            )

            return None

    def obtener_guia_password_por_correo(
        self,
        correo
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT contrasena
                FROM guia_turistico
                WHERE correo = %s
                """,
                (correo,)
            )

            fila = cursor.fetchone()

            cursor.close()

            if fila is None:
                return None

            return fila[0]

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR obtener_guia_password_por_correo:",
                repr(e)
            )

            return None

    def buscar_proveedor_por_correo(
        self,
        correo
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    id_proveedor,
                    nombre,
                    correo,
                    contrasena,
                    estado
                FROM proveedor
                WHERE correo = %s
                """,
                (correo,)
            )

            fila = cursor.fetchone()

            cursor.close()

            if fila is None:
                return None

            return {
                "id": fila[0],
                "nombre": fila[1],
                "correo": fila[2],
                "contrasena": fila[3],
                "estado": fila[4],
                "rol": "proveedor"
            }

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR buscar_proveedor_por_correo:",
                repr(e)
            )

            return None

    def obtener_proveedor_password_por_correo(
        self,
        correo
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT contrasena
                FROM proveedor
                WHERE correo = %s
                """,
                (correo,)
            )

            fila = cursor.fetchone()

            cursor.close()

            if fila is None:
                return None

            return fila[0]

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR obtener_proveedor_password_por_correo:",
                repr(e)
            )

            return None

    def crear_cliente_google(
        self,
        nombre,
        apellido,
        correo,
        numero_documento
    ):

        cursor = self.conexion.cursor()

        password_hash = generate_password_hash(
            secrets.token_urlsafe(32)
        )

        try:

            cursor.execute(
                """
                INSERT INTO cliente(
                    nombre,
                    apellido,
                    tipo_documento,
                    numero_documento,
                    telefono,
                    correo,
                    contrasena,
                    rol,
                    acepta_politica_no_reembolso,
                    id_nivel
                )
                VALUES(
                    %s,
                    %s,
                    'GOOGLE',
                    %s,
                    NULL,
                    %s,
                    %s,
                    'cliente',
                    FALSE,
                    (
                        SELECT id_nivel
                        FROM nivel
                        ORDER BY
                            min_monto ASC,
                            min_reservas ASC,
                            id_nivel ASC
                        LIMIT 1
                    )
                )
                RETURNING id_cliente
                """,
                (
                    nombre,
                    apellido,
                    numero_documento,
                    correo,
                    password_hash
                )
            )

            id_cliente = cursor.fetchone()[0]

            self.conexion.commit()
            cursor.close()

            return {
                "ok": True,
                "id": id_cliente
            }

        except UniqueViolation as e:

            self.conexion.rollback()
            cursor.close()

            mensaje = str(e)

            if "cliente_correo_key" in mensaje:

                return {
                    "ok": False,
                    "error": (
                        "Ese correo ya está registrado."
                    )
                }

            if "cliente_numero_documento_key" in mensaje:

                return {
                    "ok": False,
                    "error": (
                        "Ya existe una cuenta de Google "
                        "con esos datos."
                    )
                }

            return {
                "ok": False,
                "error": (
                    "Ya existe un usuario "
                    "con esos datos."
                )
            }

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR crear_cliente_google:",
                repr(e)
            )

            return {
                "ok": False,
                "error": (
                    "No fue posible crear la cuenta "
                    "de Google en MAREVA."
                )
            }

    def obtener_favoritos_cliente(
        self,
        id_cliente
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT id_paquete
            FROM favoritos
            WHERE id_cliente = %s
            ORDER BY fecha_agregado DESC
            """,
            (id_cliente,)
        )

        ids = [
            fila[0]
            for fila in cursor.fetchall()
        ]

        cursor.close()

        return ids

    def actualizar_correo(
        self,
        id_cliente,
        correo
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                UPDATE cliente
                SET correo = %s
                WHERE id_cliente = %s
                """,
                (
                    correo,
                    id_cliente
                )
            )

            self.conexion.commit()

            actualizado = (
                cursor.rowcount > 0
            )

            cursor.close()

            return {
                "ok": actualizado
            }

        except UniqueViolation:

            self.conexion.rollback()
            cursor.close()

            return {
                "ok": False,
                "error": (
                    "Ese correo ya está registrado."
                )
            }

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR actualizar_correo:",
                repr(e)
            )

            return {
                "ok": False,
                "error": (
                    "No fue posible actualizar "
                    "el correo."
                )
            }

    def actualizar_password(
        self,
        id_cliente,
        password_hash
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                UPDATE cliente
                SET contrasena = %s
                WHERE id_cliente = %s
                """,
                (
                    password_hash,
                    id_cliente
                )
            )

            self.conexion.commit()

            actualizado = (
                cursor.rowcount > 0
            )

            cursor.close()

            return actualizado

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "ERROR actualizar_password:",
                repr(e)
            )

            return False

    def obtener_password_por_id(
        self,
        id_cliente
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT contrasena
            FROM cliente
            WHERE id_cliente = %s
            """,
            (id_cliente,)
        )

        fila = cursor.fetchone()

        cursor.close()

        return (
            fila[0]
            if fila
            else None
        )