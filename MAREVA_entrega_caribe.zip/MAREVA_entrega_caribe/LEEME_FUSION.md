# MAREVA — Proyecto unificado

Este proyecto combina el backend de Cesar/Sofia (el más completo: proveedores,
contratos, guías, dashboard, reportes, encuestas) con piezas del proyecto de
Nicoll/Laura que faltaban aquí, y con el estilo visual del proyecto en React
aplicado al CSS de Flask/Jinja.

## Cómo levantarlo

1. Crea la base de datos en Postgres y carga el script único:
   `psql -U tu_usuario -d tu_bd -f database/mareva_unificado.sql`
2. Copia `.env` y pon tus credenciales reales de Postgres.
3. `pip install -r requirements.txt`
4. `python backend/main.py`

Usuarios de prueba ya cargados por el script (contraseñas reales, ya
guardadas con hash):
- Admin: cesar@mareva.co / Admin_mareva01 (igual para andres@, laura@, sofia@, nicoll@mareva.co)
- Cliente: yadira@test.co / cliente_prueba
- Proveedor: reservas@lasamericas.co / Proveedor_mareva01 (igual para los otros 2 proveedores)
- Guía: andres.guia@mareva.co / Guia123 · valentina.guia@mareva.co / GuiaTuristica123

## Accesos de demostración visibles
- **Administrador:** `cesar@mareva.co` / `Admin_mareva01`
- **Guía turístico:** `andres.guia@mareva.co` / `Guia123`
- **Cliente:** `yadira@test.co` / `cliente_prueba`
- También quedan disponibles los demás admins y guías definidos en el SQL. Las contraseñas se almacenan con hash; las claves anteriores son únicamente credenciales de prueba para el entorno académico.

## Qué se corrigió al fusionar

- **SQL**: el script de Cesar tenía una coma faltante en `contrato` (no cargaba).
  Las contraseñas semilla estaban en texto plano pero el login compara hash
  → se regeneraron los hashes reales para que sí se pueda iniciar sesión.
- **Rutas rotas**: `/admin/destinos/...` llamaban a métodos que no existían en
  el controller. Se implementó el CRUD completo (listar, crear, editar,
  suspender, activar) con sus plantillas `admin/destinos.html` y
  `admin/form_destino.html`.
- **Plantilla faltante**: `cliente/destino_detalle.html` solo existía en el
  proyecto de Laura; se trajo aquí y se le agregó el campo `emoji` que
  necesitaba (se agregó `EMOJI_POR_CATEGORIA` en `models/paquete.py`).
- **CSS con nombre desalineado**: `base.html` pedía `gamificacion.css` pero el
  archivo se llamaba `gamificario.css`.
- **requirements.txt** tenía dos versiones de `psycopg` en conflicto — no
  instalaba. Se dejó una sola.
- **Estilo visual**: se remapeó la paleta de colores y tipografía de
  `frontend/static/css/styles.css` (y `dashboard.css`) a los tokens del
  proyecto en React (Manrope, navy/blue/aqua/coral, botones con gradiente
  coral, tarjetas más redondeadas). Como el CSS ya usaba variables, el resto
  de páginas (paquetes, login, destinos) heredan el look automáticamente.

## Probado en caliente (no solo revisado)

Se levantó la app contra un Postgres real y se probó: home, catálogo de
destinos, detalle de destino, catálogo y detalle de paquetes, login de admin,
panel de administración de destinos (antes roto), creación/edición/suspensión
de un destino, y registro + login de un cliente nuevo. Todo quedó
verificado guardando y leyendo correctamente en la base de datos.

## Pendiente / fuera de este alcance

- El proyecto en React con Redux es una app aparte (SPA); no se integró como
  código, solo se usó su hoja de estilos como referencia de diseño. Si en
  algún momento quieres una vista más "premium" tipo esa (búsqueda flotante,
  galería de imágenes, carrito lateral), es un trabajo aparte de maquetación
  sobre las plantillas Jinja existentes.
- `guia.css` y `reportes.css` se dejaron con sus colores de estado (verde/
  rojo/amarillo para éxito/error/advertencia) sin tocar, para no confundir
  esos indicadores.
- El módulo de favoritos ahora persiste en PostgreSQL para clientes autenticados y conserva una selección temporal en sesión para visitantes.
- Se agregó un comparador real de hasta 3 paquetes (`/comparar`) con selección desde el catálogo.
- La portada ahora funciona como escaparate de una app de viajes: buscador, paquetes destacados, acceso directo a “solo destinos”, favoritos y comparación.
- El login muestra accesos demo de Admin, Guía y Cliente para facilitar las pruebas.
- El registro incluye confirmación de contraseña, aceptación de términos y dirección.


## Actualización MAREVA Caribe — 06/09/2026
- La gamificación queda basada exclusivamente en **niveles**; se eliminaron tablas y vistas de insignias.
- Se eliminó la captura de **dirección** del cliente, proveedor y alojamiento. Se conserva ciudad cuando forma parte de la información operativa.
- El registro exige la aceptación de la **Política de No Reembolso**, con fecha y versión almacenadas en BD.
- La política se presenta en un modal largo y vuelve a solicitar aceptación específica durante la reserva cuando corresponde.
- Se aplicó una identidad visual Caribe MAREVA: morado profundo, mar/turquesa, arena, verde tropical y amarillo sol, con acentos coral y componentes redondeados.
- La política legal incluida es una redacción funcional para el proyecto académico; debe ser validada por asesoría jurídica colombiana antes de producción.

### Fuentes jurídicas consultadas
- Ministerio de Comercio, Industria y Turismo — Ley 300 de 1996: derechos del turista e incumplimiento de servicios turísticos.
- Ministerio de Comercio, Industria y Turismo — Guía legal de agencias de viajes: protección al consumidor, retracto y reglas especiales para servicios turísticos y transporte aéreo.
- Ministerio de Comercio, Industria y Turismo — Protección al turista y reclamaciones.
