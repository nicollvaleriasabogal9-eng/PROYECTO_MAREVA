# MAREVA — Entrega Caribe

Esta entrega contiene el proyecto completo de MAREVA con backend Flask, frontend Jinja/CSS/JS, imágenes, SQL de base de datos y documentación.

## Cambios principales

- Sistema de gamificación basado en **niveles**, sin insignias.
- Eliminación de campos de **dirección** del cliente, proveedor y alojamiento.
- Registro con aceptación obligatoria de **Política de No Reembolso**.
- Registro de fecha/hora y versión de la política aceptada en la BD.
- Política completa disponible en `docs/POLITICA_NO_REEMBOLSO_MAREVA.md` y dentro del registro mediante modal.
- Identidad visual Caribe MAREVA: morado, mar/turquesa, arena, verde tropical, amarillo sol y coral, usados como acentos para evitar saturación.
- Navegación reforzada con accesos visibles a destinos, paquetes, comparación, favoritos y niveles.

## Base de datos

- Fuente completa: `database/mareva_unificado.sql`
- Migración para una base existente: `database/migracion_caribe_2026.sql`

La migración elimina deliberadamente las tablas de insignias y los campos de dirección indicados. Haz respaldo antes de ejecutarla sobre una base con datos.

## Accesos de demostración

- Admin: `cesar@mareva.co` / `Admin_mareva01`
- Guía: `andres.guia@mareva.co` / `Guia123`
- Cliente: `yadira@test.co` / `cliente_prueba`

## Nota legal

La política incluida es una propuesta funcional para el prototipo. No debe considerarse asesoría jurídica ni un documento contractual definitivo sin revisión profesional en Colombia. La redacción evita presentar la regla de no reembolso como absoluta y conserva las excepciones que puedan resultar obligatorias.
