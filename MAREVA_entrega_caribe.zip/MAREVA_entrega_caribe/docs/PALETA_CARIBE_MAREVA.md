# Paleta visual Caribe MAREVA

La interfaz se inspira en el logo y en el lenguaje visual de plataformas de viajes modernas, pero sin copiar su identidad.

| Rol | Color | Uso |
|---|---|---|
| Morado profundo | `#2B0870` | Header, navegación, fondos premium |
| Morado MAREVA | `#4B1696` | Botones secundarios, estados activos |
| Azul mar | `#2D70D6` | Enlaces y acciones |
| Turquesa | `#16B9C5` | Detalles de mar y acentos |
| Verde tropical | `#28B77A` | Disponibilidad, éxito, naturaleza |
| Amarillo sol | `#FFD34D` | Promociones y detalles cálidos |
| Arena | `#FFF4DC` | Fondos suaves |
| Coral | `#FF6F61` | CTA principales y acentos |

La regla visual es usar el morado como estructura, mar/turquesa como profundidad, arena como descanso visual y amarillo/coral/verde únicamente como acentos.
