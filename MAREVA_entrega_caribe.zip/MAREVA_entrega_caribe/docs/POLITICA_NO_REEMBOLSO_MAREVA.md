# Política de No Reembolso — MAREVA

**Versión:** 1.0  
**Fecha de referencia del prototipo:** 6 de septiembre de 2026  
**Ámbito:** reservas de paquetes y experiencias turísticas publicadas en MAREVA.

> **Aviso:** este documento es una redacción funcional para el prototipo académico de MAREVA. Antes de utilizarlo como documento contractual definitivo, debe ser revisado y aprobado por asesoría jurídica en Colombia.

## 1. Objeto

Esta política informa de manera previa, clara y visible las condiciones económicas asociadas a las reservas de experiencias y paquetes turísticos publicados en MAREVA. Su finalidad es que el usuario conozca la regla general de no reembolso antes de crear su cuenta y, nuevamente, antes de confirmar una reserva cuando corresponda.

## 2. Regla general de no reembolso

Una vez que el usuario haya realizado el pago al proveedor correspondiente, la tarifa contratada se considera **no reembolsable**, salvo que el proveedor haya ofrecido expresamente una condición diferente o que exista un derecho de devolución, retracto, desistimiento, reversión, compensación u otra protección obligatoria conforme a la legislación colombiana aplicable.

La expresión “no reembolsable” no pretende excluir ni limitar derechos irrenunciables del consumidor. Cuando una norma especial o general otorgue un derecho de devolución o compensación, ese derecho prevalecerá en los términos que legalmente correspondan.

## 3. Información previa a la reserva

Antes de confirmar una reserva, MAREVA deberá mostrar al usuario, según la información disponible del paquete, el destino, fechas, precio, servicios incluidos, cupos, condiciones de personalización, proveedor y las condiciones particulares relevantes. El usuario deberá revisar dicha información antes de realizar el pago.

Las promociones y tarifas especiales podrán tener condiciones adicionales. Esas condiciones deberán estar visibles antes de la confirmación y no podrán presentarse de forma engañosa.

## 4. Reservas pendientes de pago

Mientras una reserva permanezca pendiente de pago, no existe un dinero pagado por devolver. Cuando la funcionalidad del sistema lo permita, el usuario podrá cancelar una reserva pendiente de pago conforme a las reglas de MAREVA y del paquete. Al cancelarla podrán liberarse los cupos asociados.

## 5. Incumplimiento del prestador turístico

La política de no reembolso no elimina las obligaciones del prestador cuando este incumple los servicios ofrecidos o pactados. La normativa turística colombiana contempla derechos del turista frente al incumplimiento total o parcial de los servicios, incluyendo, según el caso, la prestación de otro servicio de la misma calidad o el reembolso o compensación correspondiente.

## 6. Cancelación o modificación por parte del proveedor

Si el proveedor cancela, modifica sustancialmente o no puede prestar un servicio incluido en la reserva, MAREVA gestionará la situación de acuerdo con las condiciones del paquete, las obligaciones del proveedor y la normativa aplicable. Dependiendo del caso podrán existir alternativas, cambios, compensaciones o reembolsos.

## 7. No presentación del usuario

La no presentación del usuario o la decisión de no utilizar un servicio ya contratado puede generar las consecuencias económicas previstas para ese servicio. Las condiciones particulares deberán ser consultadas antes del pago.

## 8. Transporte aéreo

Cuando una reserva incluya transporte aéreo, pueden aplicar reglas especiales del sector aeronáutico, las condiciones de la tarifa adquirida y las reglas del transportador. Por ello, una tarifa aérea no debe tratarse automáticamente igual que los demás componentes del paquete.

## 9. Personalización y servicios extra

Si un paquete es personalizable, el usuario podrá encontrar componentes que pueden agregarse o retirarse. Antes de confirmar los cambios, MAREVA deberá mostrar los componentes incluidos, los eliminados, los servicios extra agregados y el precio final actualizado.

## 10. Reclamaciones

Si el usuario considera que un servicio no fue prestado conforme a lo ofrecido, deberá conservar la reserva, comprobantes de pago, comunicaciones y demás soportes, y realizar la reclamación directa ante el prestador o responsable correspondiente. Los consumidores de servicios turísticos cuentan además con mecanismos legales de protección en Colombia.

## 11. Aceptación durante el registro

Durante el registro, el usuario deberá marcar expresamente la casilla de aceptación de esta Política de No Reembolso. El sistema registra la aceptación, la fecha y hora y la versión de la política. Esta aceptación no reemplaza la aceptación específica que pueda requerirse antes de una reserva o pago.

## 12. Fuentes jurídicas consultadas

La redacción funcional toma como referencia:

- **Ley 300 de 1996 — Ley General de Turismo**, especialmente las reglas sobre derechos y obligaciones de los usuarios de servicios turísticos y sobre incumplimiento y no presentación.
- **Ley 1480 de 2011 — Estatuto del Consumidor**, en materia de información y protección del consumidor.
- **Guía Legal de los Prestadores de Servicios Turísticos — Ministerio de Comercio, Industria y Turismo**, en especial las explicaciones sobre protección al consumidor, retracto y reglas especiales para transporte aéreo.

### Nota jurídica importante

No existe una regla general que permita a una plataforma turística declarar que **todo** pago es siempre y en cualquier circunstancia “sin derecho a devolución”. La condición comercial de no reembolso debe convivir con los derechos que puedan ser obligatorios según la naturaleza del servicio, el incumplimiento, el medio de contratación, el transporte aéreo y las demás normas aplicables.
