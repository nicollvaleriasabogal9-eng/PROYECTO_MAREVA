BEGIN;

-- IMPORTANTE: hacer respaldo antes de ejecutar esta migración sobre una BD existente.
-- La eliminación de insignias es intencional porque MAREVA utilizará NIVELES como sistema de gamificación.

DROP TABLE IF EXISTS promocion_insignia CASCADE;
DROP TABLE IF EXISTS cliente_insignia CASCADE;
DROP TABLE IF EXISTS insignia CASCADE;

ALTER TABLE cliente DROP COLUMN IF EXISTS direccion;
ALTER TABLE proveedor DROP COLUMN IF EXISTS direccion;
ALTER TABLE alojamiento DROP COLUMN IF EXISTS direccion;

ALTER TABLE cliente
    ADD COLUMN IF NOT EXISTS acepta_politica_no_reembolso BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS fecha_aceptacion_politica TIMESTAMP,
    ADD COLUMN IF NOT EXISTS version_politica VARCHAR(20) NOT NULL DEFAULT '1.0';

COMMIT;
