BEGIN;

----- MÓDULO 1: GAMIFICACIÓN — NIVELES ---

CREATE TABLE nivel (
    id_nivel             SERIAL PRIMARY KEY,
    nombre               VARCHAR(50)   NOT NULL,
    min_monto            NUMERIC(12,2) NOT NULL DEFAULT 0,
    min_reservas         INT           NOT NULL DEFAULT 0,
    descripcion          TEXT,
    porcentaje_descuento NUMERIC(5,2)  DEFAULT 0
);

----- MÓDULO 2: CLIENTES---

CREATE TABLE cliente (
    id_cliente        SERIAL PRIMARY KEY,
    nombre            VARCHAR(50)  NOT NULL,
    apellido          VARCHAR(50)  NOT NULL,
    tipo_documento    VARCHAR(30)  NOT NULL,
    numero_documento  VARCHAR(30)  NOT NULL UNIQUE,
    telefono          VARCHAR(20),
    correo            VARCHAR(100) NOT NULL UNIQUE,
    contrasena        VARCHAR(255) NOT NULL,
    rol               VARCHAR(20)  NOT NULL DEFAULT 'cliente',
    codigo_referido   VARCHAR(20)  UNIQUE,
    fecha_registro    DATE         NOT NULL DEFAULT CURRENT_DATE,
    estado            BOOLEAN      NOT NULL DEFAULT TRUE,
    intentos_fallidos INT          NOT NULL DEFAULT 0,
    bloqueado_hasta   TIMESTAMP,
    acepta_politica_no_reembolso BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_aceptacion_politica TIMESTAMP,
    version_politica  VARCHAR(20) NOT NULL DEFAULT '1.0',
    id_nivel          INT REFERENCES nivel(id_nivel),
    CONSTRAINT chk_cliente_rol CHECK (rol IN ('admin', 'cliente', 'guia'))
);

--- Referidos entre clientes---
CREATE TABLE referido (
    id_referido         SERIAL PRIMARY KEY,
    fecha_referido      DATE        NOT NULL DEFAULT CURRENT_DATE,
    puntos_ganados      INT         NOT NULL DEFAULT 0,
    estado              VARCHAR(20) NOT NULL DEFAULT 'pendiente',
    id_referidor        INT NOT NULL REFERENCES cliente(id_cliente),
    id_referido_cliente INT NOT NULL REFERENCES cliente(id_cliente),
    UNIQUE (id_referidor, id_referido_cliente),
    CONSTRAINT chk_referido_estado    CHECK (estado IN ('pendiente','completado','cancelado')),
    CONSTRAINT chk_no_autoreferido    CHECK (id_referidor <> id_referido_cliente)
);

----- MÓDULO 3: DESTINOS---

CREATE TABLE destino (
    id_destino       SERIAL PRIMARY KEY,
    nombre_destino   VARCHAR(100) NOT NULL,
    departamento     VARCHAR(100),
    ciudad           VARCHAR(100),
    categoria        VARCHAR(50),
    descripcion      TEXT,
    atracciones      TEXT,
    docs_requeridos  TEXT,
    imagen_principal VARCHAR(255),
    estado           BOOLEAN NOT NULL DEFAULT TRUE
);


---MÓDULO 4: PROVEEDORES---

CREATE TABLE proveedor (
    id_proveedor      SERIAL PRIMARY KEY,
    nombre            VARCHAR(100) NOT NULL,
    nit               VARCHAR(30) UNIQUE,
    tipo_empresa      VARCHAR(50),
    descripcion       TEXT,
    ciudad            VARCHAR(100),
    telefono          VARCHAR(20),
    correo            VARCHAR(100) UNIQUE,
    contrasena        VARCHAR(255) NOT NULL,
    nombre_contacto   VARCHAR(100),
    telefono_contacto VARCHAR(20),
    correo_contacto   VARCHAR(100),
    estado            BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE metodo_pago_proveedor (
    id_metodo_proveedor SERIAL PRIMARY KEY,
    id_proveedor        INT NOT NULL REFERENCES proveedor(id_proveedor) ON DELETE CASCADE,
    tipo_metodo         VARCHAR(50)  NOT NULL,
    entidad             VARCHAR(100),
    titular             VARCHAR(150),
    numero_referencia   VARCHAR(100),
    instrucciones       TEXT,
    CONSTRAINT chk_tipo_metodo CHECK (
        tipo_metodo IN ('cuenta_bancaria','nequi','daviplata','efectivo','tarjeta','otro')
    )
);


--- MÓDULO 5: GUÍAS TURÍSTICOS---


CREATE TABLE guia_turistico (
    id_guia      SERIAL PRIMARY KEY,
    nombre       VARCHAR(50)  NOT NULL,
    apellido     VARCHAR(50)  NOT NULL,
    idiomas      VARCHAR(200),
    especialidad VARCHAR(200),
    telefono     VARCHAR(20),
    correo       VARCHAR(100),
    contrasena        VARCHAR(255) NOT NULL,
    estado       BOOLEAN NOT NULL DEFAULT TRUE
);

--- MÓDULO 6: SEGUROS---

CREATE TABLE tipo_seguro (
    id_tipo_seguro   SERIAL PRIMARY KEY,
    nombre           VARCHAR(100) NOT NULL,
    descripcion      TEXT,
    cobertura_general TEXT
);

CREATE TABLE seguro (
    id_seguro      SERIAL PRIMARY KEY,
    id_tipo_seguro INT NOT NULL REFERENCES tipo_seguro(id_tipo_seguro),
    nombre         VARCHAR(100)  NOT NULL,
    cobertura      TEXT          NOT NULL,
    precio         NUMERIC(10,2) NOT NULL DEFAULT 0,
    es_obligatorio BOOLEAN       NOT NULL DEFAULT FALSE,
    descripcion    TEXT,
    estado         BOOLEAN       NOT NULL DEFAULT TRUE
);

--- MÓDULO 7: SERVICIOS (Alojamiento, Alimentación, Transporte, Actividad)---

CREATE TABLE alojamiento (
    id_alojamiento   SERIAL PRIMARY KEY,
    nombre           VARCHAR(100) NOT NULL,
    tipo_alojamiento VARCHAR(50),
    ciudad           VARCHAR(100),
    servicios        TEXT,
    id_proveedor     INT REFERENCES proveedor(id_proveedor)
);

CREATE TABLE alimentacion (
    id_alimentacion SERIAL PRIMARY KEY,
    restaurante     VARCHAR(100),
    tipo_comida     VARCHAR(100),
    tipo_servicio   VARCHAR(50),
    incluye_bebidas BOOLEAN       NOT NULL DEFAULT FALSE,
    precio          NUMERIC(10,2),
    id_proveedor    INT REFERENCES proveedor(id_proveedor)
);

CREATE TABLE transporte (
    id_transporte SERIAL PRIMARY KEY,
    tipo          VARCHAR(50),
    empresa       VARCHAR(100),
    ruta          VARCHAR(200),
    capacidad     INT,
    hora_salida   TIME,
    hora_regreso  TIME,
    fecha_inicio  DATE,
    fecha_fin     DATE,
    id_proveedor  INT REFERENCES proveedor(id_proveedor)
);

CREATE TABLE actividad_turistica (
    id_actividad   SERIAL PRIMARY KEY,
    nombre         VARCHAR(100) NOT NULL,
    tipo           VARCHAR(100),
    duracion_horas NUMERIC(4,1),
    costo          NUMERIC(10,2),
    id_destino     INT REFERENCES destino(id_destino),
    id_guia        INT REFERENCES guia_turistico(id_guia),
    id_proveedor   INT REFERENCES proveedor(id_proveedor)
);

CREATE TABLE seguro_servicio (
    id_seguro_servicio SERIAL PRIMARY KEY,
    id_seguro          INT NOT NULL REFERENCES seguro(id_seguro) ON DELETE CASCADE,
    id_alojamiento     INT REFERENCES alojamiento(id_alojamiento)     ON DELETE CASCADE,
    id_alimentacion    INT REFERENCES alimentacion(id_alimentacion)   ON DELETE CASCADE,
    id_transporte      INT REFERENCES transporte(id_transporte)       ON DELETE CASCADE,
    id_actividad       INT REFERENCES actividad_turistica(id_actividad) ON DELETE CASCADE,
    CONSTRAINT chk_solo_un_servicio CHECK (
        (id_alojamiento  IS NOT NULL)::INT +
        (id_alimentacion IS NOT NULL)::INT +
        (id_transporte   IS NOT NULL)::INT +
        (id_actividad    IS NOT NULL)::INT = 1
    ),
    UNIQUE (id_seguro, id_alojamiento),
    UNIQUE (id_seguro, id_alimentacion),
    UNIQUE (id_seguro, id_transporte),
    UNIQUE (id_seguro, id_actividad)
);


--- MÓDULO 8: PAQUETES TURÍSTICOS---


CREATE TABLE paquete_turistico (
    id_paquete        SERIAL PRIMARY KEY,
    nombre            VARCHAR(100)  NOT NULL,
    slug              VARCHAR(100)  NOT NULL UNIQUE,
    imagen_url        VARCHAR(255),
    descripcion       TEXT,
    precio            NUMERIC(10,2) NOT NULL,
    duracion_dias     INT,
    duracion_noches   INT,
    cupos_totales     INT           NOT NULL DEFAULT 0,
    cupos_disponibles INT           NOT NULL DEFAULT 0,
    fecha_inicio      DATE,
    fecha_fin         DATE,
    imagen_principal  VARCHAR(255),
    personalizable    BOOLEAN       NOT NULL DEFAULT FALSE,
    estado            VARCHAR(20)   NOT NULL DEFAULT 'activo',
    id_destino        INT REFERENCES destino(id_destino),
    id_guia           INT REFERENCES guia_turistico(id_guia),
    emoji             VARCHAR(10) DEFAULT '🧳',

    CONSTRAINT chk_paquete_estado
        CHECK (estado IN ('activo','suspendido')),

    CONSTRAINT chk_cupos
        CHECK (cupos_disponibles <= cupos_totales)
);

-- Servicios que componen el paquete (tablas N:M)---
CREATE TABLE paquete_transporte (
    id_paquete    INT NOT NULL REFERENCES paquete_turistico(id_paquete) ON DELETE CASCADE,
    id_transporte INT NOT NULL REFERENCES transporte(id_transporte),
    PRIMARY KEY (id_paquete, id_transporte)
);

CREATE TABLE paquete_alojamiento (
    id_paquete     INT NOT NULL REFERENCES paquete_turistico(id_paquete) ON DELETE CASCADE,
    id_alojamiento INT NOT NULL REFERENCES alojamiento(id_alojamiento),
    PRIMARY KEY (id_paquete, id_alojamiento)
);

CREATE TABLE paquete_alimentacion (
    id_paquete      INT NOT NULL REFERENCES paquete_turistico(id_paquete) ON DELETE CASCADE,
    id_alimentacion INT NOT NULL REFERENCES alimentacion(id_alimentacion),
    PRIMARY KEY (id_paquete, id_alimentacion)
);

CREATE TABLE paquete_actividad (
    id_paquete   INT NOT NULL REFERENCES paquete_turistico(id_paquete) ON DELETE CASCADE,
    id_actividad INT NOT NULL REFERENCES actividad_turistica(id_actividad),
    PRIMARY KEY (id_paquete, id_actividad)
);

--- Servicios extras opcionales dentro del paquete---
CREATE TABLE servicio_extra (
    id_servicio_extra SERIAL PRIMARY KEY,
    nombre            VARCHAR(100)  NOT NULL,
    precio            NUMERIC(10,2) NOT NULL,
    descripcion       TEXT,
    estado            BOOLEAN       NOT NULL DEFAULT TRUE,
    id_paquete        INT NOT NULL REFERENCES paquete_turistico(id_paquete) ON DELETE CASCADE
);

CREATE TABLE contrato
(
    id_contrato              SERIAL PRIMARY KEY,
    id_proveedor             INTEGER NOT NULL,
    id_paquete               INTEGER NOT NULL,
    descripcion_terminos     TEXT NOT NULL,
    fecha_inicio             DATE,
    fecha_fin                DATE,
    condiciones_comerciales  TEXT,
    estado_contrato          VARCHAR(20) NOT NULL DEFAULT 'pendiente',
    fecha_creacion           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    respuesta_proveedor      VARCHAR(20),
    fecha_respuesta          TIMESTAMP,
    firma_proveedor          BOOLEAN NOT NULL DEFAULT FALSE,
    fecha_firma              TIMESTAMP,
    metodo_firma             VARCHAR(50),

    CONSTRAINT contrato_proveedor_fkey
        FOREIGN KEY (id_proveedor)
        REFERENCES proveedor(id_proveedor)
        ON DELETE CASCADE,

    CONSTRAINT contrato_paquete_fkey
        FOREIGN KEY (id_paquete)
        REFERENCES paquete_turistico(id_paquete)
        ON DELETE CASCADE,

    CONSTRAINT contrato_estado_check
        CHECK (
            estado_contrato IN (
                'pendiente',
                'aceptado',
                'rechazado',
                'vigente',
                'vencido'
            )
        ),

    CONSTRAINT contrato_respuesta_check
        CHECK (
            respuesta_proveedor IS NULL
            OR respuesta_proveedor IN ('aceptado', 'rechazado')
        ),

    CONSTRAINT contrato_fechas_check
        CHECK (
            fecha_fin IS NULL
            OR fecha_inicio IS NULL
            OR fecha_fin >= fecha_inicio
        )
);

CREATE TABLE documento
(
    id_documento       SERIAL PRIMARY KEY,
    id_contrato        INTEGER,
    id_proveedor       INTEGER NOT NULL,
    nombre_documento   VARCHAR(150) NOT NULL,
    tipo_documento     VARCHAR(50),
    url_documento      VARCHAR(500),
    fecha_carga        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado_documento   VARCHAR(20) NOT NULL DEFAULT 'pendiente',

    CONSTRAINT documento_contrato_fkey
        FOREIGN KEY (id_contrato)
        REFERENCES contrato(id_contrato)
        ON DELETE CASCADE,

    CONSTRAINT documento_proveedor_fkey
        FOREIGN KEY (id_proveedor)
        REFERENCES proveedor(id_proveedor)
        ON DELETE CASCADE,

    CONSTRAINT documento_estado_check
        CHECK (
            estado_documento IN (
                'pendiente',
                'aprobado',
                'rechazado'
            )
        )
);


--- MÓDULO 9: PROMOCIONES---


CREATE TABLE promocion (
    id_promocion   SERIAL PRIMARY KEY,
    codigo         VARCHAR(30)   NOT NULL UNIQUE,
    descuento      NUMERIC(5,2)  NOT NULL,
    descripcion    TEXT,
    fecha_inicio   DATE,
    fecha_fin      DATE,
    tipo_promocion VARCHAR(30),
    id_paquete     INT REFERENCES paquete_turistico(id_paquete),
    CONSTRAINT chk_descuento CHECK (descuento > 0 AND descuento <= 100)
);

--- Promoción disponible según nivel del cliente (N:M)---
CREATE TABLE promocion_nivel (
    id_promocion INT NOT NULL REFERENCES promocion(id_promocion) ON DELETE CASCADE,
    id_nivel     INT NOT NULL REFERENCES nivel(id_nivel)         ON DELETE CASCADE,
    PRIMARY KEY (id_promocion, id_nivel)
);

--- MÓDULO 10: RESERVAS---


CREATE TABLE reserva (
    id_reserva          SERIAL PRIMARY KEY,
    codigo_unico        VARCHAR(30)   NOT NULL UNIQUE,
    fecha_reserva       DATE          NOT NULL DEFAULT CURRENT_DATE,
    fecha_viaje         DATE,
    estado              VARCHAR(30)   NOT NULL DEFAULT 'solicitada',
    valor_referencial   NUMERIC(12,2),
    cant_adultos        INT           NOT NULL DEFAULT 1,
    cant_menores        INT           NOT NULL DEFAULT 0,
    observaciones       TEXT,
    acepta_no_reembolso BOOLEAN       NOT NULL DEFAULT FALSE,
    plan                 TEXT,
    alergias             TEXT,
    mascotas             BOOLEAN      NOT NULL DEFAULT FALSE,
    metodo_contacto     VARCHAR(30),
    guia_pdf             VARCHAR(255),
    id_cliente          INT NOT NULL
        REFERENCES cliente(id_cliente),
    id_paquete          INT NOT NULL
        REFERENCES paquete_turistico(id_paquete),
    CONSTRAINT chk_reserva_estado
        CHECK (
            estado IN ('solicitada', 'confirmada', 'en_proceso', 'completada', 'cancelada')
        ),
    CONSTRAINT chk_cant_adultos
        CHECK (cant_adultos >= 1),
    CONSTRAINT chk_cant_menores
        CHECK (cant_menores >= 0)
);

--- Seguro adicional opcional que el cliente agrega a su reserva---
CREATE TABLE reserva_seguro (
    id_reserva_seguro  SERIAL PRIMARY KEY,
    id_reserva         INT NOT NULL REFERENCES reserva(id_reserva)  ON DELETE CASCADE,
    id_seguro          INT NOT NULL REFERENCES seguro(id_seguro)     ON DELETE CASCADE,
    precio_aplicado    NUMERIC(10,2) NOT NULL,
    fecha_contratacion DATE          NOT NULL DEFAULT CURRENT_DATE,
    UNIQUE (id_reserva, id_seguro)
);

--- Servicios extra opcionales que el cliente agrega a su reserva---
CREATE TABLE reserva_servicio_extra (
    id_reserva        INT NOT NULL REFERENCES reserva(id_reserva)             ON DELETE CASCADE,
    id_servicio_extra INT NOT NULL REFERENCES servicio_extra(id_servicio_extra),
    PRIMARY KEY (id_reserva, id_servicio_extra)
);

--- Viajeros registrados en la reserva---
CREATE TABLE viajero_reserva (
    id_viajero       SERIAL PRIMARY KEY,
    nombre           VARCHAR(50) NOT NULL,
    apellido         VARCHAR(50) NOT NULL,
    tipo_documento   VARCHAR(30) NOT NULL,
    numero_documento VARCHAR(30) NOT NULL,
    id_reserva       INT NOT NULL REFERENCES reserva(id_reserva) ON DELETE CASCADE
);

--- Itinerario de traslados de la reserva---
CREATE TABLE itinerario_viaje (
    id_itinerario    SERIAL PRIMARY KEY,
    origen           VARCHAR(100),
    destino          VARCHAR(100),
    fecha_salida     DATE,
    fecha_regreso    DATE,
    hora_salida      TIME,
    hora_regreso     TIME,
    medio_transporte VARCHAR(50),
    id_reserva       INT NOT NULL REFERENCES reserva(id_reserva) ON DELETE CASCADE
);

--- Actividades diarias del itinerario de la reserva---
CREATE TABLE itinerario_actividad (
    id_itin_actividad  SERIAL PRIMARY KEY,
    dia                INT,
    hora_inicio        TIME,
    lugar              VARCHAR(200),
    descripcion        TEXT,
    costos_adicionales NUMERIC(10,2) DEFAULT 0,
    id_actividad       INT REFERENCES actividad_turistica(id_actividad),
    id_reserva         INT NOT NULL REFERENCES reserva(id_reserva) ON DELETE CASCADE
);

--- MÓDULO 11: FUNCIONALIDADES DEL CLIENTE---


CREATE TABLE favoritos (
    id_favorito    SERIAL PRIMARY KEY,
    fecha_agregado DATE NOT NULL DEFAULT CURRENT_DATE,
    id_cliente     INT NOT NULL REFERENCES cliente(id_cliente)         ON DELETE CASCADE,
    id_paquete     INT NOT NULL REFERENCES paquete_turistico(id_paquete) ON DELETE CASCADE,
    UNIQUE (id_cliente, id_paquete)
);

CREATE TABLE lista_suenos (
    id_sueno            SERIAL PRIMARY KEY,
    fecha_inicio_ahorro DATE,
    meta_semanal        NUMERIC(10,2),
    meta_mensual        NUMERIC(10,2),
    id_cliente          INT NOT NULL REFERENCES cliente(id_cliente)         ON DELETE CASCADE,
    id_paquete          INT NOT NULL REFERENCES paquete_turistico(id_paquete) ON DELETE CASCADE,
    UNIQUE (id_cliente, id_paquete)
);

CREATE TABLE historial_busqueda (
    id_busqueda     SERIAL PRIMARY KEY,
    destino_buscado VARCHAR(100),
    filtros         JSONB,
    fecha_busqueda  TIMESTAMP NOT NULL DEFAULT NOW(),
    id_cliente      INT NOT NULL REFERENCES cliente(id_cliente) ON DELETE CASCADE
);

CREATE TABLE notificacion (
    id_notificacion SERIAL PRIMARY KEY,
    tipo            VARCHAR(50),
    mensaje         TEXT,
    fecha           TIMESTAMP NOT NULL DEFAULT NOW(),
    leida           BOOLEAN   NOT NULL DEFAULT FALSE,
    id_cliente      INT NOT NULL REFERENCES cliente(id_cliente) ON DELETE CASCADE
);


--- MÓDULO 12: ENCUESTAS DE SATISFACCIÓN ---

CREATE TABLE encuesta_pregunta (
    id_pregunta    SERIAL PRIMARY KEY,
    texto          TEXT        NOT NULL,
    tipo_respuesta VARCHAR(50) NOT NULL,
    orden          INT         NOT NULL,
    estado         BOOLEAN     NOT NULL DEFAULT TRUE
);

--- Una fila por respuesta (pregunta + reserva + cliente)---
CREATE TABLE encuesta_respuesta (
    id_respuesta      SERIAL PRIMARY KEY,
    id_pregunta       INT NOT NULL REFERENCES encuesta_pregunta(id_pregunta) ON DELETE CASCADE,
    id_reserva        INT NOT NULL REFERENCES reserva(id_reserva)            ON DELETE CASCADE,
    id_cliente        INT NOT NULL REFERENCES cliente(id_cliente)            ON DELETE CASCADE,
    respuesta_texto   TEXT,
    respuesta_numero  INT,
    fecha             TIMESTAMP NOT NULL DEFAULT NOW(),
    UNIQUE (id_pregunta, id_reserva, id_cliente)
);


--- MÓDULO 13: ADMINISTRACIÓN Y AUDITORÍA---


CREATE TABLE auditoria_admin (
    id_auditoria SERIAL PRIMARY KEY,
    accion       VARCHAR(100) NOT NULL,
    descripcion  TEXT,
    fecha        TIMESTAMP NOT NULL DEFAULT NOW(),
    id_admin     INT NOT NULL REFERENCES cliente(id_cliente)
);

--- ÍNDICES---


--- Cliente---
CREATE INDEX idx_cliente_correo      ON cliente(correo);
CREATE INDEX idx_cliente_documento   ON cliente(numero_documento);
CREATE INDEX idx_cliente_nivel       ON cliente(id_nivel);

--- Reserva---
CREATE INDEX idx_reserva_cliente     ON reserva(id_cliente);
CREATE INDEX idx_reserva_paquete     ON reserva(id_paquete);
CREATE INDEX idx_reserva_estado      ON reserva(estado);
CREATE INDEX idx_reserva_fecha_viaje ON reserva(fecha_viaje);

--- Paquete ---
CREATE INDEX idx_paquete_destino     ON paquete_turistico(id_destino);
CREATE INDEX idx_paquete_estado      ON paquete_turistico(estado);
CREATE INDEX idx_paquete_fecha       ON paquete_turistico(fecha_inicio);

--- Seguro ---
CREATE INDEX idx_seguro_servicio     ON seguro_servicio(id_seguro);
CREATE INDEX idx_reserva_seguro      ON reserva_seguro(id_reserva);

--- Proveedor ---
CREATE INDEX idx_metodo_proveedor    ON metodo_pago_proveedor(id_proveedor);

--- Funcionalidades cliente ---
CREATE INDEX idx_historial_cliente   ON historial_busqueda(id_cliente);
CREATE INDEX idx_notif_cliente       ON notificacion(id_cliente);
CREATE INDEX idx_favoritos_cliente   ON favoritos(id_cliente);

--- Promoción ---
CREATE INDEX idx_promocion_codigo    ON promocion(codigo);

--- Auditoría ---
CREATE INDEX idx_auditoria_admin     ON auditoria_admin(id_admin);


--- DATOS INICIALES ---

--- Niveles ---
INSERT INTO nivel (nombre, min_monto, min_reservas, descripcion, porcentaje_descuento) VALUES
('Explorador',    0,        0,  'Nivel inicial para nuevos viajeros',   0.00),
('Aventurero',    2000000,  2,  'Viajeros con experiencia',             5.00),
('Viajero Elite', 6000000,  5,  'Acceso a promociones exclusivas',     10.00),
('Embajador',     15000000, 10, 'El nivel más alto de MAREVA',         15.00);

--- Admins y cliente de prueba ---
-- NOTA: las contraseñas se guardan con hash (werkzeug scrypt), tal como las verifica
-- services/auth_services.py. Contraseña real para iniciar sesión con cualquier admin: Admin_mareva01
-- Contraseña real de Yadira (cliente de prueba): cliente_prueba
INSERT INTO cliente (nombre, apellido, tipo_documento, numero_documento, telefono, correo, contrasena, rol, codigo_referido, acepta_politica_no_reembolso, fecha_aceptacion_politica, version_politica) VALUES
('Cesar',  'Uzcategui', 'CC', '1000000001', '3100000001', 'cesar@mareva.co',  'scrypt:32768:8:1$OfezC5PlkEjHkACB$d216d80ef624d29146bbc75def4f94e7735245b886e198200cc8ea8503670ffc494d6f71faa458d3720ca6462b5af1cc1b9cc7b0668ee23e8d987a504b314a02', 'admin',   NULL, TRUE, CURRENT_TIMESTAMP, '1.0'),
('Andres', 'Aroca',     'CC', '1000000002', '3100000002', 'andres@mareva.co', 'scrypt:32768:8:1$OfezC5PlkEjHkACB$d216d80ef624d29146bbc75def4f94e7735245b886e198200cc8ea8503670ffc494d6f71faa458d3720ca6462b5af1cc1b9cc7b0668ee23e8d987a504b314a02', 'admin',   NULL, TRUE, CURRENT_TIMESTAMP, '1.0'),
('Laura',  'Rubiano',   'CC', '1000000003', '3100000003', 'laura@mareva.co',  'scrypt:32768:8:1$OfezC5PlkEjHkACB$d216d80ef624d29146bbc75def4f94e7735245b886e198200cc8ea8503670ffc494d6f71faa458d3720ca6462b5af1cc1b9cc7b0668ee23e8d987a504b314a02', 'admin',   NULL, TRUE, CURRENT_TIMESTAMP, '1.0'),
('Sofia',  'Munevar',   'CC', '1000000004', '3100000004', 'sofia@mareva.co',  'scrypt:32768:8:1$OfezC5PlkEjHkACB$d216d80ef624d29146bbc75def4f94e7735245b886e198200cc8ea8503670ffc494d6f71faa458d3720ca6462b5af1cc1b9cc7b0668ee23e8d987a504b314a02', 'admin',   NULL, TRUE, CURRENT_TIMESTAMP, '1.0'),
('Nicoll', 'Sabogal',   'CC', '1000000005', '3100000005', 'nicoll@mareva.co', 'scrypt:32768:8:1$OfezC5PlkEjHkACB$d216d80ef624d29146bbc75def4f94e7735245b886e198200cc8ea8503670ffc494d6f71faa458d3720ca6462b5af1cc1b9cc7b0668ee23e8d987a504b314a02', 'admin',   NULL, TRUE, CURRENT_TIMESTAMP, '1.0'),
('Yadira', 'Narvaez',   'CC', '2000000001', '3200000001', 'yadira@test.co',   'scrypt:32768:8:1$OsPW9JDKU8BF6uy1$c12dc8e295c68587bcc6ff01fcfd1357c394d46c95a19957ec6c2f84b771ef91b9a2191af9a552289ff05fc3301822519acf4c3c1a536efc88f71ee52886e235', 'cliente', 'YN20261', TRUE, CURRENT_TIMESTAMP, '1.0');

--- Destinos (20 destinos para los 20 paquetes) ---
INSERT INTO destino (nombre_destino, departamento, ciudad, categoria, descripcion, atracciones, imagen_principal, estado) VALUES
('Cartagena de Indias', 'Bolívar',    'Cartagena',    'playa',    'Ciudad amurallada Patrimonio de la Humanidad con playas caribeñas.',    'Ciudad Amurallada, Islas del Rosario, Castillo de San Felipe, Bocagrande',  'img/destinos/cartagena_indias.jpeg',        TRUE),
('Medellín',            'Antioquia',  'Medellín',     'ciudad',   'La ciudad de la eterna primavera, innovadora y cultural.',             'El Poblado, Metro Cable, Pueblito Paisa, Museo de Antioquia',              'img/destinos/medellin.jpeg',         TRUE),
('Guatapé',             'Antioquia',  'Guatapé',      'aventura', 'Pueblo colorido con la imponente Piedra del Peñol.',                   'La Piedra del Peñol, Embalse de Guatapé, Zócalos pintados',                'img/destinos/guatape.jpeg',          TRUE),
('San Andrés',          'San Andrés', 'San Andrés',   'playa',    'El mar de los siete colores en el Caribe colombiano.',                 'Hoyo Soplador, Johnny Cay, La Piscinita, El Acuario',                      'img/destinos/san_andres.jpeg',       TRUE),
('Parque Tayrona',      'Magdalena',  'Santa Marta',  'playa',    'Naturaleza salvaje: selva tropical y playas vírgenes.',                'Cabo San Juan, Playa Cristal, Arrecifes, Pueblito',                        'img/destinos/tayrona.jpeg',          TRUE),
('Valle del Cocora',    'Quindío',    'Salento',      'montaña',  'Hogar de las palmas de cera, árbol nacional de Colombia.',             'Palmas de Cera, Salento, Finca El Ocaso, Mirador',                         'img/destinos/cocora.jpeg',    TRUE),
('Barichara',           'Santander',  'Barichara',    'cultural', 'El pueblo más bonito de Colombia, arquitectura colonial.',             'Catedral de la Inmaculada, Camino Real, Capilla de Santa Bárbara',         'img/destinos/barichara.jpg',        TRUE),
('Leticia',             'Amazonas',   'Leticia',      'aventura', 'Puerta de entrada a la Amazonía colombiana.',                          'Parque Amacayacu, Isla de los Micos, Reserva Tanimboca',                   'img/destinos/leticia.jpeg',          TRUE),
('Caño Cristales',      'Meta',       'La Macarena',  'aventura', 'El río más hermoso del mundo, famoso por sus colores únicos.',         'Río Caño Cristales, Pozos naturales, Senderismo, Miradores',               'img/destinos/caño_cristales.jpeg',   TRUE),
('Eje Cafetero',        'Quindío',    'Armenia',      'cultural', 'Paisaje Cultural Cafetero, Patrimonio de la Humanidad.',               'Fincas cafeteras, Parque del Café, Pueblos patrimonio, Jeep willys',       'img/destinos/eje_cafetero.jpeg',     TRUE),
('Nuquí',               'Chocó',      'Nuquí',        'playa',    'Paraíso del Pacífico colombiano, avistamiento de ballenas jorobadas.', 'Playas vírgenes, Avistamiento ballenas, Manglares, Termas',                'img/destinos/nuqui.jpeg',            TRUE),
('Barichara Colonial',  'Santander',  'Barichara',    'cultural', 'Arquitectura colonial de piedra y el Camino Real hacia Guane.',        'Catedral Inmaculada, Capilla de Jesús, Camino Real, Guane',                'img/destinos/barichara_colonial.jpg',TRUE),
('Las Lajas',           'Nariño',     'Ipiales',      'cultural', 'Basílica neogótica construida sobre un cañón, ícono religioso.',       'Basílica Las Lajas, Puente, Cascadas, Laguna La Cocha',                    'img/destinos/lajas.jpeg',        TRUE),
('Villa de Leyva',      'Boyacá',     'Villa de Leyva','cultural','Plaza empedrada más grande de Colombia, arquitectura colonial.',        'Plaza Mayor, Museo del Desierto, Pozos Azules, Ráquira',                   'img/destinos/leyva.jpeg',   TRUE),
('Cañón del Chicamocha','Santander',  'San Gil',      'aventura', 'Capital colombiana de los deportes extremos y paisajes épicos.',       'Teleférico, Rafting, Parapente, Parque Chicamocha',                        'img/destinos/cañon_chicamocha.jpeg',       TRUE),
('Mompox',              'Bolívar',    'Mompox',       'cultural', 'Ciudad Patrimonio de la Humanidad a orillas del río Magdalena.',       'Calle Real, Iglesias coloniales, Orfebrería, Festival de Jazz',             'img/destinos/mompox.jpeg',           TRUE),
('Sierra Nevada',       'Magdalena',  'Santa Marta',  'aventura', 'La montaña costera más alta del mundo y territorios indígenas.',       'Ciudad Perdida, Comunidades Kogi, Caminatas, Biodiversidad',               'img/destinos/sierra_nevada.jpeg',    TRUE),
('Tolú y Coveñas',      'Sucre',      'Tolú',         'playa',    'Playas tranquilas del Caribe colombiano, ideal para el descanso.',     'Playas Tolú, Islas de San Bernardo, Motonáutica, Manglar',                 'img/destinos/tolu.jpeg',     TRUE),
('Isla Gorgona',        'Cauca',      'Guapi',        'aventura', 'Parque Nacional Natural, antigua prisión y reserva marina única.',     'Buceo, Avistamiento ballenas, Senderismo, Biodiversidad marina',            'img/destinos/gorgona.jpeg',          TRUE),
('Capurganá',           'Chocó',      'Acandí',       'playa',    'Pueblo caribeño sin carreteras, paraíso de buceadores.',              'Playa La Caleta, Sapzurro, Arrecifes de coral, Senderismo',                'img/destinos/capurgana.jpeg',        TRUE);

--- Proveedores---
-- Contraseña real para iniciar sesión como cualquier proveedor: Proveedor_mareva01
INSERT INTO proveedor (nombre, nit, tipo_empresa, descripcion, ciudad, telefono, correo, contrasena, nombre_contacto, telefono_contacto) 
VALUES
('Hotel Las Américas', '800100200-1', 'Hotel', 'Hotel 5 estrellas en Cartagena', 'Cartagena', '6056543210', 'reservas@lasamericas.co', 'scrypt:32768:8:1$Y48DfJ4449NTuVQY$5c2981bb49d79dc53471b4e38017e7d255024511e18f8e6ea9d6739e9d6076fc8da20d32cb9cc40dddcb67cc79aea84f5e944193c36e2252a3b649bf52500da0', 'María Torres', '3001234567'),
('Avianca', '860002964-4', 'Aerolínea', 'Aerolínea nacional', 'Bogotá', '018000953434', 'grupos@avianca.com', 'scrypt:32768:8:1$Y48DfJ4449NTuVQY$5c2981bb49d79dc53471b4e38017e7d255024511e18f8e6ea9d6739e9d6076fc8da20d32cb9cc40dddcb67cc79aea84f5e944193c36e2252a3b649bf52500da0', 'Carlos Reyes', '3009876543'),
('CocoraTours', '900567890-3', 'Operador', 'Tours en el Quindío', 'Salento', '3145678901', 'info@cocoratours.co', 'scrypt:32768:8:1$Y48DfJ4449NTuVQY$5c2981bb49d79dc53471b4e38017e7d255024511e18f8e6ea9d6739e9d6076fc8da20d32cb9cc40dddcb67cc79aea84f5e944193c36e2252a3b649bf52500da0', 'Juliana Ríos', '3145678901');

--- Métodos de pago de proveedores ---
INSERT INTO metodo_pago_proveedor (id_proveedor, tipo_metodo, entidad, titular, numero_referencia, instrucciones) VALUES
(1, 'cuenta_bancaria', 'Bancolombia', 'Hotel Las Americas SAS', '12345678901', 'Transferir y enviar comprobante al correo del proveedor'),
(2, 'nequi',           'Nequi',       'CocoraTours',            '3001234567',  NULL),
(3, 'daviplata',       'Daviplata',   'CocoraTours',            '3209876543',  NULL);

--- Guías turísticos ---
-- Contraseña real de Andrés: Guia123 · Valentina: GuiaTuristica123 · Miguel: (ya venía hasheada en el original)
INSERT INTO guia_turistico (nombre, apellido, idiomas, especialidad, telefono, correo, contrasena, estado) VALUES
('Andrés',    'Herrera',  'Español, Inglés',           'Cartagena histórica y playas',  '3100001111', 'andres.guia@mareva.co', 'scrypt:32768:8:1$DyUDJeiqrqIuCpOb$c8e99c7e7eae986e4f6d2a06188601687d96ef43f38ed10b1b20d509281d86ecc902d75b7e08e9e3fa89ba25a5488612376dd97555c73a42c92a5a40967a8576',    TRUE),
('Valentina', 'López',    'Español, Inglés, Francés',  'Ecoturismo y naturaleza',       '3100002222', 'valentina.guia@mareva.co', 'scrypt:32768:8:1$BmwNjfSVYTonnYPl$05a81a5f442d6ef99062a3bab28179e8759d28727f20d5639d0c0da82319c4de3dab02c1075708d912f3bbb36f0030e287088a39228453a5bda98cd01ffe92c3', TRUE),
('Miguel',    'Castillo', 'Español',                   'Aventura y deportes extremos',  '3100003333', 'miguel.guia@mareva.co', 'scrypt:32768:8:1$AELZ8i2lbW4gWGaS$c93d8a0d0ce87f2c85e74f63337cb6d60ead433feddece2e6a1311fdb52d633596f8d755fb690f34d34a2b7e1344066ea5a3978567b5d0509b827ca2905d387b',   TRUE);

--- Tipos de seguro ---
INSERT INTO tipo_seguro (nombre, descripcion, cobertura_general) VALUES
('Responsabilidad Civil', 'Seguro obligatorio por ley para prestadores de servicios turísticos',   'Cubre daños a terceros dentro de las instalaciones o durante el servicio'),
('Asistencia Médica',     'Seguro opcional de salud para el viajero',                             'Cubre emergencias médicas, hospitalización y asistencia en viaje'),
('Cancelación y Equipaje','Seguro opcional contra imprevistos del viaje',                          'Cubre cancelaciones, pérdida o daño de equipaje');

--- Seguros específicos ---
INSERT INTO seguro (id_tipo_seguro, nombre, cobertura, precio, es_obligatorio, descripcion, estado) VALUES
(1, 'RC Alojamiento',     'Accidentes dentro del alojamiento hasta $50.000.000',  0,      TRUE,  'Obligatorio — incluido en el costo del alojamiento',  TRUE),
(1, 'RC Transporte',      'Accidentes durante el traslado hasta $50.000.000',     0,      TRUE,  'Obligatorio — incluido en el costo del transporte',   TRUE),
(1, 'RC Actividad',       'Accidentes durante la actividad hasta $30.000.000',    0,      TRUE,  'Obligatorio — incluido en el costo de la actividad',  TRUE),
(2, 'Seguro Médico Básico','Emergencias médicas y hospitalización hasta $80.000.000', 120000, FALSE, 'Recomendado para viajes nacionales',                TRUE),
(2, 'Seguro Médico Completo','Médico, dental y evacuación hasta $200.000.000',    280000, FALSE, 'Cobertura amplia recomendada',                        TRUE),
(3, 'Seguro Premium',     'Cancelación, equipaje y médico hasta $500.000.000',    520000, FALSE, 'Máxima protección para tu viaje',                     TRUE);

--- Paquetes turísticos (20 paquetes)---
INSERT INTO paquete_turistico (nombre,slug,imagen_url,descripcion,precio,duracion_dias,duracion_noches,cupos_totales,cupos_disponibles,fecha_inicio,fecha_fin,imagen_principal,personalizable,estado,id_destino,id_guia) 
VALUES
('Cartagena Mágica','cartagena-magica','img/paquetes/Cartagena.jpeg','Descubre la ciudad amurallada con playas privadas e historia colonial.', 1850000, 5, 4, 20, 14,'2026-07-01', '2026-07-05','img/paquetes/Cartagena.jpeg',TRUE, 'activo', 1, 1),
('Medellín Innovadora','medellin-innovadora','img/paquetes/Medellin.jpeg','Conoce la ciudad más transformadora de América Latina.',1200000, 4, 3, 25, 20,'2026-07-10', '2026-07-13','img/paquetes/Medellin.jpeg',FALSE, 'activo', 2, 2),
('Guatapé Extremo','guatape-extremo','img/paquetes/Guatape.jpeg','Adrenalina pura: sube la Piedra del Peñol y navega el embalse.',890000, 3, 2, 15, 12,'2026-07-15', '2026-07-17','img/paquetes/Guatape.jpeg',TRUE, 'activo', 3, 3),
('San Andrés Todo Incluido','san-andres-todo-incluido','img/paquetes/SanAndres.jpeg','El mar de los siete colores con todo incluido en resort 5 estrellas.',3200000, 7, 6, 30, 18,'2026-08-01', '2026-08-07','img/paquetes/SanAndres.jpeg',FALSE, 'activo', 4, 1),
('Tayrona Salvaje','tayrona-salvaje','img/paquetes/Tayrona.jpeg','Selva, playas vírgenes y ecosistemas únicos en el Parque Tayrona.',1450000, 5, 4, 12, 8,'2026-08-10', '2026-08-14','img/paquetes/Tayrona.jpeg',TRUE, 'activo', 5, 2),
('Valle del Cocora Místico','valle-del-cocora-mistico','img/paquetes/Cocora.jpeg','Caminata entre palmas de cera y fincas cafeteras del Quindío.',980000, 3, 2, 20, 15,'2026-09-01', '2026-09-03','img/paquetes/Cocora.jpeg',FALSE, 'activo', 6, 3),
('Amazonas Aventura','amazonas-aventura','img/paquetes/Amazonas.jpeg','Explora la selva amazónica y conoce comunidades indígenas.',2750000, 6, 5, 18, 14,'2026-09-10', '2026-09-15','img/paquetes/Amazonas.jpeg',TRUE, 'activo', 8, 1),
('Desierto de la Tatacoa','desierto-de-la-tatacoa','img/paquetes/Desierto.jpeg','Observación astronómica y recorridos por paisajes únicos.',750000, 3, 2, 20, 16,'2026-09-20', '2026-09-22','img/paquetes/Desierto.jpeg',FALSE, 'activo', 8, 2),
('Caño Cristales Premium','cano-cristales-premium','img/paquetes/Caño.jpeg','Visita el río más hermoso del mundo con guía especializado.',2950000, 5, 4, 15, 10,'2026-10-01', '2026-10-05','img/paquetes/Caño.jpeg',TRUE, 'activo', 9, 3),
('Eje Cafetero Tradicional','eje-cafetero-tradicional','img/paquetes/EjeCafetero.jpeg','Recorrido por fincas cafeteras y pueblos patrimonio.',1350000, 4, 3, 25, 18,'2026-10-10', '2026-10-13','img/paquetes/EjeCafetero.jpeg',FALSE, 'activo', 10, 1),
('Nuquí Ecoturismo','nuqui-ecoturismo','img/paquetes/Nuqui.jpeg','Avistamiento de ballenas y playas vírgenes del Pacífico.',2400000, 5, 4, 16, 12,'2026-10-20', '2026-10-24','img/paquetes/Nuqui.jpeg',TRUE, 'activo', 11, 2),
('Barichara Colonial','barichara-colonial','img/paquetes/Barichara.jpg','Conoce uno de los pueblos más bellos de Colombia.',890000, 3, 2, 20, 17,'2026-11-01', '2026-11-03','img/paquetes/Barichara.jpg',FALSE, 'activo', 12, 3),
('Santuario Las Lajas','santuario-las-lajas','img/paquetes/Santuario.jpeg','Recorrido religioso y cultural por Nariño.',680000, 3, 2, 22, 19,'2026-11-08', '2026-11-10','img/paquetes/Santuario.jpeg',FALSE, 'activo', 13, 1),
('Boyacá Histórica','boyaca-historica','img/paquetes/BOYaca.jpeg','Villa de Leyva, Ráquira y monumentos históricos.',980000, 4, 3, 24, 20,'2026-11-15', '2026-11-18','img/paquetes/BOYaca.jpeg',TRUE, 'activo', 14, 2),
('Cañón del Chicamocha','canon-del-chicamocha','img/paquetes/CañonChica.jpeg','Deportes extremos y paisajes espectaculares.',1150000, 4, 3, 18, 13,'2026-11-25', '2026-11-28','img/paquetes/CañonChica.jpeg',TRUE, 'activo', 15, 3),
('Mompox Patrimonial','mompox-patrimonial','img/paquetes/Mompox.jpg','Historia, arquitectura colonial y cultura ribereña.',1250000, 4, 3, 20, 16,'2026-12-01', '2026-12-04','img/paquetes/Mompox.jpg',FALSE, 'activo', 16, 1),
('Sierra Nevada Ancestral','sierra-nevada-ancestral','img/paquetes/CierraNevada.jpeg','Conexión con comunidades indígenas y naturaleza.',2100000, 5, 4, 14, 10,'2026-12-10', '2026-12-14','img/paquetes/CierraNevada.jpeg',TRUE, 'activo', 17, 2),
('Tolú y Coveñas Relax','tolu-y-covenas-relax','img/paquetes/Tolu.jpeg','Playas tranquilas y actividades acuáticas.',1100000, 4, 3, 26, 21,'2026-12-18', '2026-12-21','img/paquetes/Tolu.jpeg',FALSE, 'activo', 18, 3),
('Isla Gorgona Explorer','isla-gorgona-explorer','img/paquetes/Isla.jpeg','Naturaleza, senderismo y biodiversidad marina.',2800000, 5, 4, 12, 8,'2027-01-10', '2027-01-14','img/paquetes/Isla.jpeg',TRUE, 'activo', 19, 1),
('Capurganá Paraíso','capurgana-paraiso','img/paquetes/Capurgana.jpeg','Playas cristalinas y ecoturismo en el Caribe colombiano.',1900000, 5, 4, 18, 13,'2027-01-20', '2027-01-24','img/paquetes/Capurgana.jpeg',TRUE, 'activo', 20, 2);

--- Servicios extra por paquete---
INSERT INTO servicio_extra (nombre, precio, descripcion, estado, id_paquete) VALUES
('Snorkel en Islas del Rosario',   180000, 'Equipo incluido, 3 horas',            TRUE, 1),
('Foto profesional en la Muralla', 120000, 'Sesión de 1 hora con fotógrafo',      TRUE, 1),
('Kayak en el embalse',             95000, 'Kayak doble 2 horas',                 TRUE, 3),
('Rappel en La Piedra',            140000, 'Equipo y seguro de escalada',          TRUE, 3),
('Buceo certificado',              350000, 'Bautismo de buceo 2 inmersiones',      TRUE, 5),
('Senderismo nocturno',            120000, 'Guía nocturno 4 horas',               TRUE, 5);

--- Promociones ---
INSERT INTO promocion (codigo, descuento, descripcion, fecha_inicio, fecha_fin, tipo_promocion, id_paquete) VALUES
('VERANO10',  10.00, '10% de descuento temporada de verano', '2026-06-01', '2026-07-31', 'temporal', 1),
('PAREJA20',  20.00, '20% para parejas en San Andrés',       '2026-07-01', '2026-08-31', 'especial', 4),
('MOCHILA15', 15.00, '15% para viajeros aventureros',        '2026-07-01', '2026-09-30', 'temporal', 5);

--- Preguntas de encuesta ---
INSERT INTO encuesta_pregunta (texto, tipo_respuesta, orden, estado) VALUES
('¿Cómo calificarías la calidad general del paquete?',       'calificacion', 1, TRUE),
('¿Qué tan satisfecho estás con el servicio del proveedor?', 'calificacion', 2, TRUE),
('¿El proceso de reserva en MAREVA fue fácil y claro?',      'calificacion', 3, TRUE),
('¿Recomendarías MAREVA a un amigo o familiar?',             'calificacion', 4, TRUE),
('Cuéntanos qué fue lo mejor de tu experiencia:',            'texto',        5, TRUE),
('¿Qué podríamos mejorar?',                                  'texto',        6, TRUE);

COMMIT;
