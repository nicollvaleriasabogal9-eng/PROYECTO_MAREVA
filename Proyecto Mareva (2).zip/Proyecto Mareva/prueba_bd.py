﻿from config.conexion import Conexion

c = Conexion().obtener_conexion()
cur = c.cursor()

try:
    print("========================================")
    print("PRUEBA DE INSERCION")
    print("========================================")

    cur.execute("""
        SELECT id_paquete, nombre, precio, cupos_disponibles
        FROM paquete_turistico
        ORDER BY id_paquete
        LIMIT 5
    """)

    print("PAQUETES:")
    for fila in cur.fetchall():
        print(fila)

    cur.execute("""
        SELECT column_name, data_type
        FROM information_schema.columns
        WHERE table_name = 'reserva'
        ORDER BY ordinal_position
    """)

    print()
    print("COLUMNAS RESERVA:")
    for fila in cur.fetchall():
        print(fila)

except Exception as e:
    print("ERROR:")
    print(repr(e))
    c.rollback()

finally:
    cur.close()
    c.close()
