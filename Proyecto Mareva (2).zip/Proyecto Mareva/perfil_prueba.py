﻿import os
from flask import Flask, render_template

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "frontend", "templates"),
    static_folder=os.path.join(BASE_DIR, "frontend", "static")
)


@app.route("/")
def inicio():
    usuario = {
        "nombre": "Sofía",
        "apellido": "Rubiano",
        "correo": "sofia@gmail.com",
        "nivel": "Aventurero",
        "insignias": [
            "Primer viaje",
            "Exploradora"
        ],
        "ultima_reserva": {
            "id_reserva": 1,
            "nombre_paquete": "Cartagena Mágica",
            "destino": "Cartagena",
            "fecha_inicio": "2026-08-31",
            "fecha_regreso": "2026-09-01",
            "adultos": 1,
            "menores": 0
        }
    }

    return render_template(
        "cliente/perfil.html",
        usuario=usuario
    )


@app.route("/paquetes")
def paquetes():
    return "#"


@app.route("/login")
def login():
    return "#"


@app.route("/registro")
def registro():
    return "#"


@app.route("/logout")
def logout():
    return "#"


@app.route("/destinos")
def destinos():
    return "#"


@app.route("/niveles")
def niveles():
    return "#"


@app.route("/insignias")
def insignias():
    return "#"


@app.route("/perfil")
def perfil():
    return "#"


@app.route("/reserva/<slug>")
def reserva(slug):
    return "#"


@app.route("/confirmar-reserva")
def confirmar_reserva():
    return "#"


@app.route("/api/reserva/<int:id_reserva>/fecha", endpoint="reserva.editar_fecha")
def editar_fecha(id_reserva):
    return "#"


if __name__ == "__main__":
    app.run(
        debug=True,
        host="127.0.0.1",
        port=5001
    )

