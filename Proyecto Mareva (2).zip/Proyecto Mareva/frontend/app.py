﻿import sys
import os

# ==========================================================
# RUTAS DEL PROYECTO
# ==========================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

BACKEND_DIR = os.path.join(
    BASE_DIR,
    "backend"
)

if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)


# ==========================================================
# FLASK
# ==========================================================

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash
)


# ==========================================================
# CONEXIÓN A BASE DE DATOS
# ==========================================================

from config.conexion import Conexion


# ==========================================================
# BLUEPRINTS
# ==========================================================

from routes.paquetes_routes import paquetes_bp
from routes.reserva_routes import reserva_bp


# ==========================================================
# CREAR APLICACIÓN
# ==========================================================

app = Flask(
    __name__,
    template_folder=os.path.join(
        os.path.dirname(
            os.path.abspath(__file__)
        ),
        "templates"
    ),
    static_folder=os.path.join(
        os.path.dirname(
            os.path.abspath(__file__)
        ),
        "static"
    )
)


# ==========================================================
# CONFIGURACIÓN
# ==========================================================

app.secret_key = "mareva_secret_2026"


# ==========================================================
# REGISTRAR BLUEPRINTS
# ==========================================================

app.register_blueprint(paquetes_bp)
app.register_blueprint(reserva_bp)


# ==========================================================
# INICIO
# ==========================================================

@app.route("/")
def inicio():

    return render_template(
        "principal/index.html"
    )


# ==========================================================
# DESTINOS
# ==========================================================

@app.route("/destinos")
def destinos():

    return render_template(
        "cliente/destinos.html"
    )


# ==========================================================
# NIVELES
# ==========================================================

@app.route("/niveles")
def niveles():

    usuario = session.get("usuario", {})

    return render_template(
        "cliente/niveles.html",
        usuario=usuario
    )


# ==========================================================
# INSIGNIAS
# ==========================================================

@app.route("/insignias")
def insignias():

    usuario = session.get(
        "usuario",
        {}
    )

    if "insignias" not in usuario:
        usuario["insignias"] = []

    session["usuario"] = usuario

    return render_template(
        "cliente/insignias.html",
        usuario=usuario
    )


# ==========================================================
# PERFIL
# ==========================================================

@app.route("/perfil")
def perfil():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    if not id_usuario:

        return render_template(
            "cliente/perfil.html",
            usuario=usuario,
            error=(
                "Tu sesión no contiene "
                "el identificador del usuario."
            )
        )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()

        # ==================================================
        # DATOS ACTUALES DEL USUARIO
        # ==================================================

        cursor.execute(
            """
            SELECT
                u.id_usuario,
                u.nombre,
                u.apellido,
                u.tipo_documento,
                u.numero_documento,
                u.telefono,
                u.correo,
                u.rol,
                u.codigo_referido,
                u.acepta_terminos,
                u.estado,
                u.fecha_registro,
                u.id_nivel,
                n.nombre AS nombre_nivel,
                n.min_monto,
                n.min_reservas,
                n.descripcion,
                n.porcentaje_descuento

            FROM usuario u

            LEFT JOIN nivel n
                ON u.id_nivel = n.id_nivel

            WHERE u.id_usuario = %s
            """,
            (id_usuario,)
        )

        usuario_db = cursor.fetchone()

        if usuario_db:

            (
                uid,
                nombre,
                apellido,
                tipo_documento,
                numero_documento,
                telefono,
                correo,
                rol,
                codigo_referido,
                acepta_terminos,
                estado,
                fecha_registro,
                id_nivel,
                nombre_nivel,
                min_monto,
                min_reservas,
                descripcion_nivel,
                porcentaje_descuento
            ) = usuario_db

            usuario.update({

                "id_usuario": uid,
                "nombre": nombre,
                "apellido": apellido,
                "tipo_documento": tipo_documento,
                "numero_documento": numero_documento,
                "telefono": telefono,
                "correo": correo,
                "rol": rol,
                "codigo_referido": codigo_referido,
                "acepta_terminos": acepta_terminos,
                "estado": estado,
                "fecha_registro": fecha_registro,
                "id_nivel": id_nivel,
                "nivel": nombre_nivel or "Explorador",
                "descripcion_nivel": descripcion_nivel,
                "porcentaje_descuento": float(
                    porcentaje_descuento or 0
                )
            })


        # ==================================================
        # ESTADÍSTICAS DEL USUARIO
        # ==================================================

        cursor.execute(
            """
            SELECT
                COUNT(*),
                COALESCE(SUM(monto_total), 0)

            FROM reserva

            WHERE id_usuario = %s
              AND estado <> 'Cancelada'
            """,
            (id_usuario,)
        )

        estadisticas = cursor.fetchone()

        total_reservas = (
            estadisticas[0]
            if estadisticas
            else 0
        )

        monto_total = float(
            estadisticas[1]
            if estadisticas
            else 0
        )

        usuario["total_reservas"] = total_reservas
        usuario["monto_total_reservas"] = monto_total


        # ==================================================
        # ÚLTIMA RESERVA
        # ==================================================

        cursor.execute(
            """
            SELECT
                r.id_reserva,
                r.codigo_reserva,
                r.id_usuario,
                r.id_paquete,
                r.fecha_reserva,
                r.fecha_viaje,
                r.cantidad_adultos,
                r.cantidad_menores,
                r.monto_total,
                r.metodo_pago_informativo,
                r.politica_no_reembolso_aceptada,
                r.estado,
                r.justificacion_cambio,
                p.nombre AS nombre_paquete,
                p.fecha_inicio,
                p.fecha_fin,
                d.nombre_destino,
                d.ciudad

            FROM reserva r

            LEFT JOIN paquete_turistico p
                ON r.id_paquete = p.id_paquete

            LEFT JOIN destino d
                ON p.id_destino = d.id_destino

            WHERE r.id_usuario = %s

            ORDER BY r.id_reserva DESC

            LIMIT 1
            """,
            (id_usuario,)
        )

        reserva_db = cursor.fetchone()


        if reserva_db:

            (
                id_reserva,
                codigo_reserva,
                id_usuario_reserva,
                id_paquete,
                fecha_reserva,
                fecha_viaje,
                cantidad_adultos,
                cantidad_menores,
                monto_total_reserva,
                metodo_pago,
                politica_no_reembolso,
                estado,
                justificacion_cambio,
                nombre_paquete,
                fecha_inicio,
                fecha_fin,
                nombre_destino,
                ciudad
            ) = reserva_db

            usuario["ultima_reserva"] = {

                "id_reserva":
                    id_reserva,

                "codigo_reserva":
                    codigo_reserva,

                "id_usuario":
                    id_usuario_reserva,

                "id_paquete":
                    id_paquete,

                "fecha_reserva":
                    fecha_reserva,

                "fecha_viaje":
                    fecha_viaje,

                "cantidad_adultos":
                    cantidad_adultos,

                "cantidad_menores":
                    cantidad_menores,

                "monto_total":
                    float(
                        monto_total_reserva or 0
                    ),

                "metodo_pago":
                    metodo_pago,

                "politica_no_reembolso":
                    politica_no_reembolso,

                "estado":
                    estado,

                "justificacion_cambio":
                    justificacion_cambio,

                "nombre_paquete":
                    nombre_paquete,

                "destino":
                    nombre_destino,

                "ciudad":
                    ciudad,

                "fecha_inicio":
                    fecha_inicio,

                "fecha_fin":
                    fecha_fin,

                "adultos":
                    cantidad_adultos,

                "menores":
                    cantidad_menores,

                "fecha_regreso":
                    fecha_fin
            }

        else:

            usuario.pop(
                "ultima_reserva",
                None
            )


        # ==================================================
        # INSIGNIAS
        # ==================================================

        if "insignias" not in usuario:
            usuario["insignias"] = []


        # ==================================================
        # ACTUALIZAR SESIÓN
        # ==================================================

        session["usuario"] = usuario


        return render_template(
            "cliente/perfil.html",
            usuario=usuario
        )


    except Exception as e:

        print(
            "========================================"
        )

        print(
            "❌ ERROR CARGANDO PERFIL:"
        )

        print(
            str(e)
        )

        print(
            "========================================"
        )

        return render_template(
            "cliente/perfil.html",
            usuario=usuario,
            error=(
                "No se pudieron cargar "
                "tus datos."
            )
        )


    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()


# ==========================================================
# EDITAR PERFIL
# ==========================================================

@app.route(
    "/perfil/editar",
    methods=["GET", "POST"]
)
def editar_perfil():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    if not id_usuario:

        return redirect(
            url_for("login")
        )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()


        if request.method == "POST":

            nombre = request.form.get(
                "nombre",
                ""
            ).strip()

            apellido = request.form.get(
                "apellido",
                ""
            ).strip()

            telefono = request.form.get(
                "telefono",
                ""
            ).strip()

            correo = request.form.get(
                "correo",
                ""
            ).strip()


            if (
                not nombre
                or not apellido
                or not telefono
                or not correo
            ):

                return render_template(
                    "cliente/editar_perfil.html",
                    usuario=usuario,
                    error=(
                        "Todos los campos "
                        "son obligatorios."
                    )
                )


            # ==============================================
            # VERIFICAR CORREO
            # ==============================================

            cursor.execute(
                """
                SELECT id_usuario
                FROM usuario
                WHERE correo = %s
                  AND id_usuario <> %s
                """,
                (
                    correo,
                    id_usuario
                )
            )

            correo_existente = (
                cursor.fetchone()
            )

            if correo_existente:

                return render_template(
                    "cliente/editar_perfil.html",
                    usuario=usuario,
                    error=(
                        "Ese correo ya está "
                        "registrado."
                    )
                )


            # ==============================================
            # ACTUALIZAR
            # ==============================================

            cursor.execute(
                """
                UPDATE usuario

                SET
                    nombre = %s,
                    apellido = %s,
                    telefono = %s,
                    correo = %s

                WHERE id_usuario = %s
                """,
                (
                    nombre,
                    apellido,
                    telefono,
                    correo,
                    id_usuario
                )
            )

            conexion.commit()


            # ==============================================
            # ACTUALIZAR SESIÓN
            # ==============================================

            usuario["nombre"] = nombre
            usuario["apellido"] = apellido
            usuario["telefono"] = telefono
            usuario["correo"] = correo

            session["usuario"] = usuario

            return redirect(
                url_for("perfil")
            )


        # ==============================================
        # MOSTRAR DATOS ACTUALES
        # ==============================================

        cursor.execute(
            """
            SELECT
                nombre,
                apellido,
                telefono,
                correo,
                tipo_documento,
                numero_documento

            FROM usuario

            WHERE id_usuario = %s
            """,
            (id_usuario,)
        )

        datos = cursor.fetchone()


        if datos:

            usuario_edicion = {

                "id_usuario":
                    id_usuario,

                "nombre":
                    datos[0],

                "apellido":
                    datos[1],

                "telefono":
                    datos[2],

                "correo":
                    datos[3],

                "tipo_documento":
                    datos[4],

                "numero_documento":
                    datos[5]
            }

        else:

            usuario_edicion = usuario


        return render_template(
            "cliente/editar_perfil.html",
            usuario=usuario_edicion
        )


    except Exception as e:

        if conexion:
            conexion.rollback()

        print(
            "❌ ERROR EDITANDO PERFIL:",
            str(e)
        )

        return render_template(
            "cliente/editar_perfil.html",
            usuario=usuario,
            error=(
                "No se pudieron actualizar "
                "tus datos."
            )
        )


    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()


# ==========================================================
# MIS RESERVAS
# ==========================================================

@app.route("/mis-reservas")
def mis_reservas():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    if not id_usuario:

        return redirect(
            url_for("login")
        )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()

        cursor.execute(
            """
            SELECT
                r.id_reserva,
                r.codigo_reserva,
                r.fecha_reserva,
                r.fecha_viaje,
                r.cantidad_adultos,
                r.cantidad_menores,
                r.monto_total,
                r.metodo_pago_informativo,
                r.politica_no_reembolso_aceptada,
                r.estado,
                r.justificacion_cambio,

                p.id_paquete,
                p.nombre AS nombre_paquete,
                p.imagen_url,
                p.fecha_inicio,
                p.fecha_fin,

                d.nombre_destino,
                d.ciudad,
                d.departamento

            FROM reserva r

            LEFT JOIN paquete_turistico p
                ON r.id_paquete = p.id_paquete

            LEFT JOIN destino d
                ON p.id_destino = d.id_destino

            WHERE r.id_usuario = %s

            ORDER BY r.id_reserva DESC
            """,
            (id_usuario,)
        )

        reservas_db = cursor.fetchall()

        reservas = []

        for fila in reservas_db:

            reservas.append({

                "id_reserva":
                    fila[0],

                "codigo_reserva":
                    fila[1],

                "fecha_reserva":
                    fila[2],

                "fecha_viaje":
                    fila[3],

                "cantidad_adultos":
                    fila[4] or 0,

                "cantidad_menores":
                    fila[5] or 0,

                "monto_total":
                    float(fila[6] or 0),

                "metodo_pago":
                    fila[7],

                "politica_no_reembolso":
                    fila[8],

                "estado":
                    fila[9],

                "justificacion_cambio":
                    fila[10],

                "id_paquete":
                    fila[11],

                "nombre_paquete":
                    fila[12] or "Paquete de viaje",

                "imagen_url":
                    fila[13],

                "fecha_inicio":
                    fila[14],

                "fecha_fin":
                    fila[15],

                "destino":
                    fila[16],

                "ciudad":
                    fila[17],

                "departamento":
                    fila[18]
            })


        return render_template(
            "cliente/mis_reservas.html",
            usuario=usuario,
            reservas=reservas
        )


    except Exception as e:

        print(
            "❌ ERROR CARGANDO MIS RESERVAS:",
            str(e)
        )

        return render_template(
            "cliente/mis_reservas.html",
            usuario=usuario,
            reservas=[],
            error=(
                "No se pudieron cargar "
                "tus reservas."
            )
        )


    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()


# ==========================================================
# FAVORITOS
# ==========================================================

@app.route("/favoritos")
def favoritos():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()

        cursor.execute(
            """
            SELECT
                p.id_paquete,
                p.nombre,
                p.slug,
                p.descripcion,
                p.precio,
                p.duracion_dias,
                p.duracion_noches,
                p.imagen_url,
                p.imagen_principal,
                p.fecha_inicio,
                p.fecha_fin,
                d.nombre_destino,
                d.ciudad,
                d.departamento,
                lf.fecha_agregado

            FROM lista_favoritos lf

            INNER JOIN paquete_turistico p
                ON lf.id_paquete = p.id_paquete

            INNER JOIN destino d
                ON p.id_destino = d.id_destino

            WHERE lf.id_usuario = %s

            ORDER BY lf.fecha_agregado DESC
            """,
            (id_usuario,)
        )

        filas = cursor.fetchall()

        favoritos_lista = []

        for fila in filas:

            favoritos_lista.append({

                "id_paquete":
                    fila[0],

                "nombre":
                    fila[1],

                "slug":
                    fila[2],

                "descripcion":
                    fila[3],

                "precio":
                    float(fila[4] or 0),

                "duracion_dias":
                    fila[5],

                "duracion_noches":
                    fila[6],

                "imagen_url":
                    fila[7],

                "imagen_principal":
                    fila[8],

                "fecha_inicio":
                    fila[9],

                "fecha_fin":
                    fila[10],

                "destino":
                    fila[11],

                "ciudad":
                    fila[12],

                "departamento":
                    fila[13],

                "fecha_agregado":
                    fila[14]
            })


        return render_template(
            "cliente/favoritos.html",
            usuario=usuario,
            favoritos=favoritos_lista
        )


    except Exception as e:

        print(
            "❌ ERROR CARGANDO FAVORITOS:",
            str(e)
        )

        return render_template(
            "cliente/favoritos.html",
            usuario=usuario,
            favoritos=[],
            error=(
                "No se pudieron cargar "
                "tus favoritos."
            )
        )


    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()


# ==========================================================
# AGREGAR FAVORITO
# ==========================================================

@app.route(
    "/favoritos/agregar/<int:id_paquete>",
    methods=["POST"]
)
def agregar_favorito(id_paquete):

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()

        cursor.execute(
            """
            INSERT INTO lista_favoritos
            (
                id_usuario,
                id_paquete
            )

            VALUES
            (
                %s,
                %s
            )

            ON CONFLICT
            (
                id_usuario,
                id_paquete
            )

            DO NOTHING
            """,
            (
                id_usuario,
                id_paquete
            )
        )

        conexion.commit()

        return redirect(
            request.referrer
            or url_for("favoritos")
        )


    except Exception as e:

        if conexion:
            conexion.rollback()

        print(
            "❌ ERROR AGREGANDO FAVORITO:",
            str(e)
        )

        return redirect(
            request.referrer
            or url_for("favoritos")
        )


    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()


# ==========================================================
# QUITAR FAVORITO
# ==========================================================

@app.route(
    "/favoritos/quitar/<int:id_paquete>",
    methods=["POST"]
)
def quitar_favorito(id_paquete):

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()

        cursor.execute(
            """
            DELETE FROM lista_favoritos

            WHERE id_usuario = %s
              AND id_paquete = %s
            """,
            (
                id_usuario,
                id_paquete
            )
        )

        conexion.commit()

        return redirect(
            request.referrer
            or url_for("favoritos")
        )


    except Exception as e:

        if conexion:
            conexion.rollback()

        print(
            "❌ ERROR QUITANDO FAVORITO:",
            str(e)
        )

        return redirect(
            request.referrer
            or url_for("favoritos")
        )


    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()


# ==========================================================
# API - COMPROBAR FAVORITO
# ==========================================================

@app.route(
    "/api/favoritos/<int:id_paquete>"
)
def comprobar_favorito(id_paquete):

    usuario = session.get("usuario")

    if not usuario:

        return {
            "favorito": False
        }

    id_usuario = usuario.get(
        "id_usuario"
    )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()

        cursor.execute(
            """
            SELECT 1

            FROM lista_favoritos

            WHERE id_usuario = %s
              AND id_paquete = %s

            LIMIT 1
            """,
            (
                id_usuario,
                id_paquete
            )
        )

        resultado = cursor.fetchone()

        return {
            "favorito": resultado is not None
        }


    except Exception as e:

        print(
            "❌ ERROR COMPROBANDO FAVORITO:",
            str(e)
        )

        return {
            "favorito": False
        }


    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()


# ==========================================================
# NOTIFICACIONES
# ==========================================================

@app.route("/notificaciones")
def notificaciones():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()


        # ==================================================
        # INTENTAR ESTRUCTURA CON NOTIFICACIONES
        # ==================================================

        try:

            cursor.execute(
                """
                SELECT
                    *
                FROM notificaciones
                WHERE id_usuario = %s
                ORDER BY id_notificacion DESC
                """,
                (id_usuario,)
            )

            filas = cursor.fetchall()

            columnas = [
                desc[0]
                for desc in cursor.description
            ]

            notificaciones_lista = []

            for fila in filas:

                item = dict(
                    zip(
                        columnas,
                        fila
                    )
                )

                notificaciones_lista.append(
                    item
                )


        except Exception:

            conexion.rollback()

            notificaciones_lista = []


        return render_template(
            "cliente/notificaciones.html",
            usuario=usuario,
            notificaciones=notificaciones_lista
        )


    except Exception as e:

        print(
            "❌ ERROR CARGANDO NOTIFICACIONES:",
            str(e)
        )

        return render_template(
            "cliente/notificaciones.html",
            usuario=usuario,
            notificaciones=[],
            error=(
                "No se pudieron cargar "
                "las notificaciones."
            )
        )


    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()


# ==========================================================
# MARCAR NOTIFICACIÓN COMO LEÍDA
# ==========================================================

@app.route(
    "/notificaciones/<int:id_notificacion>/leer",
    methods=["POST"]
)
def marcar_notificacion_leida(
    id_notificacion
):

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()

        cursor.execute(
            """
            UPDATE notificaciones

            SET leida = TRUE

            WHERE id_notificacion = %s
              AND id_usuario = %s
            """,
            (
                id_notificacion,
                id_usuario
            )
        )

        conexion.commit()

    except Exception as e:

        if conexion:
            conexion.rollback()

        print(
            "❌ ERROR MARCANDO NOTIFICACIÓN:",
            str(e)
        )

    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()

    return redirect(
        request.referrer
        or url_for("notificaciones")
    )


# ==========================================================
# MARCAR TODAS COMO LEÍDAS
# ==========================================================

@app.route(
    "/notificaciones/leer-todas",
    methods=["POST"]
)
def marcar_todas_notificaciones():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    conexion = None
    cursor = None

    try:

        conexion = (
            Conexion()
            .obtener_conexion()
        )

        cursor = conexion.cursor()

        cursor.execute(
            """
            UPDATE notificaciones

            SET leida = TRUE

            WHERE id_usuario = %s
            """,
            (id_usuario,)
        )

        conexion.commit()

    except Exception as e:

        if conexion:
            conexion.rollback()

        print(
            "❌ ERROR MARCANDO NOTIFICACIONES:",
            str(e)
        )

    finally:

        if cursor:
            cursor.close()

        if conexion:
            conexion.close()

    return redirect(
        url_for("notificaciones")
    )


# ==========================================================
# LOGIN
# ==========================================================

@app.route(
    "/login",
    methods=["GET", "POST"]
)
def login():

    if request.method == "POST":

        correo = request.form.get(
            "correo",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        ).strip()

        if not correo or not password:

            return render_template(
                "principal/login.html",
                error=(
                    "Debes ingresar "
                    "correo y contraseña."
                )
            )

        conexion = None
        cursor = None

        try:

            conexion = (
                Conexion()
                .obtener_conexion()
            )

            cursor = conexion.cursor()

            cursor.execute(
                """
                SELECT
                    id_usuario,
                    nombre,
                    apellido,
                    correo,
                    contrasena,
                    rol,
                    estado,
                    id_nivel,
                    codigo_referido

                FROM usuario

                WHERE correo = %s
                """,
                (correo,)
            )

            usuario_db = cursor.fetchone()

            if not usuario_db:

                return render_template(
                    "principal/login.html",
                    error=(
                        "Correo o contraseña "
                        "incorrectos."
                    )
                )

            (
                id_usuario,
                nombre,
                apellido,
                correo_db,
                contrasena_db,
                rol,
                estado,
                id_nivel,
                codigo_referido
            ) = usuario_db


            if password != contrasena_db:

                return render_template(
                    "principal/login.html",
                    error=(
                        "Correo o contraseña "
                        "incorrectos."
                    )
                )


            if estado != "activo":

                return render_template(
                    "principal/login.html",
                    error=(
                        "Este usuario se encuentra "
                        "inactivo."
                    )
                )


            # ==============================================
            # OBTENER NIVEL
            # ==============================================

            cursor.execute(
                """
                SELECT nombre
                FROM nivel
                WHERE id_nivel = %s
                """,
                (id_nivel,)
            )

            nivel_db = cursor.fetchone()

            nombre_nivel = (
                nivel_db[0]
                if nivel_db
                else "Explorador"
            )


            session.clear()

            session["usuario"] = {

                "id_usuario":
                    id_usuario,

                "nombre":
                    nombre,

                "apellido":
                    apellido,

                "correo":
                    correo_db,

                "rol":
                    rol,

                "id_nivel":
                    id_nivel,

                "nivel":
                    nombre_nivel,

                "codigo_referido":
                    codigo_referido,

                "insignias":
                    []
            }


            print(
                "========================================"
            )

            print(
                "✅ LOGIN CORRECTO"
            )

            print(
                session["usuario"]
            )

            print(
                "========================================"
            )


            return redirect(
                url_for("perfil")
            )


        except Exception as e:

            print(
                "❌ ERROR EN LOGIN:",
                str(e)
            )

            return render_template(
                "principal/login.html",
                error=(
                    "Ocurrió un error "
                    "al iniciar sesión."
                )
            )


        finally:

            if cursor:
                cursor.close()

            if conexion:
                conexion.close()


    return render_template(
        "principal/login.html"
    )


# ==========================================================
# REGISTRO
# ==========================================================

@app.route(
    "/registro",
    methods=["GET", "POST"]
)
def registro():

    if request.method == "POST":

        nombre = request.form.get(
            "nombre",
            ""
        ).strip()

        apellido = request.form.get(
            "apellido",
            ""
        ).strip()

        correo = request.form.get(
            "correo",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        ).strip()

        confirmar = request.form.get(
            "confirmar",
            ""
        ).strip()


        if password != confirmar:

            return render_template(
                "principal/registro.html",
                error=(
                    "Las contraseñas "
                    "no coinciden."
                )
            )


        if (
            not nombre
            or not apellido
            or not correo
            or not password
        ):

            return render_template(
                "principal/registro.html",
                error=(
                    "Todos los campos "
                    "son obligatorios."
                )
            )


        conexion = None
        cursor = None

        try:

            conexion = (
                Conexion()
                .obtener_conexion()
            )

            cursor = conexion.cursor()


            # ==============================================
            # VERIFICAR CORREO
            # ==============================================

            cursor.execute(
                """
                SELECT id_usuario

                FROM usuario

                WHERE correo = %s
                """,
                (correo,)
            )

            usuario_existente = (
                cursor.fetchone()
            )

            if usuario_existente:

                return render_template(
                    "principal/registro.html",
                    error=(
                        "Ya existe un usuario "
                        "con ese correo."
                    )
                )


            # ==============================================
            # GENERAR CÓDIGO DE REFERIDO
            # ==============================================

            codigo_referido = (
                nombre[:3]
                + apellido[:3]
                + str(
                    os.urandom(2).hex()
                )
            ).upper()


            # ==============================================
            # CREAR USUARIO
            # ==============================================

            cursor.execute(
                """
                INSERT INTO usuario
                (
                    nombre,
                    apellido,
                    correo,
                    contrasena,
                    rol,
                    estado,
                    codigo_referido
                )

                VALUES
                (
                    %s,
                    %s,
                    %s,
                    %s,
                    'cliente',
                    'activo',
                    %s
                )

                RETURNING id_usuario
                """,
                (
                    nombre,
                    apellido,
                    correo,
                    password,
                    codigo_referido
                )
            )

            nuevo_id = cursor.fetchone()[0]

            conexion.commit()


            session.clear()

            session["usuario"] = {

                "id_usuario":
                    nuevo_id,

                "nombre":
                    nombre,

                "apellido":
                    apellido,

                "correo":
                    correo,

                "rol":
                    "cliente",

                "nivel":
                    "Explorador",

                "codigo_referido":
                    codigo_referido,

                "insignias":
                    []
            }


            print(
                "========================================"
            )

            print(
                "✅ USUARIO REGISTRADO"
            )

            print(
                session["usuario"]
            )

            print(
                "========================================"
            )


            return redirect(
                url_for("perfil")
            )


        except Exception as e:

            if conexion:
                conexion.rollback()

            print(
                "❌ ERROR EN REGISTRO:",
                str(e)
            )

            return render_template(
                "principal/registro.html",
                error=(
                    "No se pudo completar "
                    "el registro."
                )
            )


        finally:

            if cursor:
                cursor.close()

            if conexion:
                conexion.close()


    return render_template(
        "principal/registro.html"
    )


# ==========================================================
# CERRAR SESIÓN
# ==========================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("inicio")
    )


# ==========================================================
# EJECUTAR APLICACIÓN
# ==========================================================

if __name__ == "__main__":

    app.run(
        debug=True
    )