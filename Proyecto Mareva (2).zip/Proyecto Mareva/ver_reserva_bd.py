import sys

sys.path.insert(0, ".\\backend")

from config.conexion import Conexion


conexion = None
cursor = None

try:

    conexion = Conexion().obtener_conexion()
    cursor = conexion.cursor()

    cursor.execute(
        """
        SELECT
            id_reserva,
            codigo_reserva,
            id_usuario,
            id_paquete,
            fecha_reserva,
            cantidad_adultos,
            cantidad_menores,
            monto_total,
            estado
        FROM reserva
        WHERE id_usuario = %s
        ORDER BY id_reserva DESC
        """,
        (1,)
    )

    reservas = cursor.fetchall()

    print()
    print("========================================")
    print("RESERVAS DEL USUARIO 1")
    print("========================================")

    if not reservas:

        print("NO HAY RESERVAS EN LA BASE DE DATOS.")

    else:

        for reserva in reservas:
            print(reserva)

    print("========================================")

except Exception as e:

    print()
    print("========================================")
    print("ERROR:")
    print(str(e))
    print("========================================")

finally:

    if cursor:
        cursor.close()

    if conexion:
        conexion.close()