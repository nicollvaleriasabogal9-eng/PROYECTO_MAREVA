﻿from config.conexion import Conexion

c = Conexion().obtener_conexion()
cur = c.cursor()

print("========================================")
print("PRUEBA DIRECTA DE RESERVA")
print("========================================")

cur.execute("""
    SELECT
        r.id_reserva,
        r.codigo_reserva,
        r.id_usuario,
        r.id_paquete,
        r.fecha_reserva,
        r.cantidad_adultos,
        r.cantidad_menores,
        r.monto_total,
        r.estado,
        p.nombre
    FROM reserva r
    LEFT JOIN paquete_turistico p
        ON r.id_paquete = p.id_paquete
    WHERE r.id_usuario = %s
    ORDER BY r.id_reserva DESC
""", (1,))

reservas = cur.fetchall()

print("RESERVAS ENCONTRADAS:", len(reservas))

for reserva in reservas:
    print(reserva)

print("========================================")

cur.close()
c.close()
