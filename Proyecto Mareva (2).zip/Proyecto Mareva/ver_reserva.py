﻿from config.conexion import Conexion

conexion = Conexion().obtener_conexion()
cursor = conexion.cursor()

cursor.execute("""
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_name = 'reserva'
    ORDER BY ordinal_position
""")

print("\nCOLUMNAS DE RESERVA:")
for columna in cursor.fetchall():
    print(columna)

cursor.close()
conexion.close()
