﻿from config.conexion import Conexion

c = Conexion().obtener_conexion()
cur = c.cursor()

cur.execute("SELECT current_database(), current_user, inet_server_addr(), inet_server_port()")
print("========================================")
print("CONEXION REAL DEL PROYECTO")
print("========================================")
print(cur.fetchone())

cur.execute("SELECT COUNT(*) FROM reserva")
print("TOTAL RESERVAS:", cur.fetchone()[0])

cur.close()
c.close()
