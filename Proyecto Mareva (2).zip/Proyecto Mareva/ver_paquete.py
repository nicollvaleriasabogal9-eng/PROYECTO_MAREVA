import sys
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BACKEND_DIR = os.path.join(BASE_DIR, "backend")

sys.path.insert(0, BACKEND_DIR)

from config.conexion import Conexion

conexion = Conexion().obtener_conexion()
cursor = conexion.cursor()

print("\n========== TABLAS ==========\n")

cursor.execute("""
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = 'public'
    ORDER BY table_name
""")

for fila in cursor.fetchall():
    print(fila[0])

print("\n========== COLUMNAS DE PAQUETE_TURISTICO ==========\n")

cursor.execute("""
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'paquete_turistico'
    ORDER BY ordinal_position
""")

columnas = cursor.fetchall()

if columnas:
    for columna in columnas:
        print(columna)
else:
    print("NO SE ENCONTRO LA TABLA paquete_turistico")

cursor.close()
conexion.close()