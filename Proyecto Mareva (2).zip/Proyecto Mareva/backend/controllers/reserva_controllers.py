﻿from datetime import date

from flask import (
    request,
    session,
    redirect,
    url_for,
    render_template,
    jsonify
)

from services.reserva_services import ReservaService
from services.paquete_services import PaqueteService


class ReservaController:

    def __init__(self):

        self.service = ReservaService()

        self.paquete_service = PaqueteService()

    # ==========================================================
    # MOSTRAR FORMULARIO
    # ==========================================================

    def mostrar_formulario(self, slug):

        paquete = self.paquete_service.obtener_detalle(
            slug
        )

        if not paquete:

            return redirect(
                url_for("paquetes.lista")
            )

        return render_template(
            "cliente/reserva.html",
            paquete=paquete
        )

    # ==========================================================
    # DISPONIBILIDAD
    # ==========================================================

    def disponibilidad_json(self, id_paquete):

        data = self.paquete_service.obtener_disponibilidad(
            id_paquete
        )

        if not data:

            return jsonify({
                "error": "Paquete no encontrado"
            }), 404

        return jsonify(data), 200

    # ==========================================================
    # CONFIRMAR RESERVA
    # ==========================================================

    def confirmar(self):

        usuario = session.get("usuario")

        if not usuario:

            return redirect(
                url_for("login")
            )

        id_usuario = usuario.get(
            "id_usuario"
        )

        if not id_usuario:

            return render_template(
                "cliente/reserva.html",
                paquete=None,
                error=(
                    "Tu sesión no contiene "
                    "el identificador del usuario."
                )
            )

        # ------------------------------------------------------
        # OBTENER PAQUETE
        # ------------------------------------------------------

        slug = request.form.get(
            "paquete"
        )

        paquete = self.paquete_service.obtener_detalle(
            slug
        )

        if not paquete:

            return redirect(
                url_for("paquetes.lista")
            )

        # ------------------------------------------------------
        # ADULTOS Y MENORES
        # ------------------------------------------------------

        try:

            adultos = int(
                request.form.get(
                    "adultos",
                    1
                )
            )

            menores = int(
                request.form.get(
                    "menores",
                    0
                )
            )

        except (ValueError, TypeError):

            adultos = 1
            menores = 0

        if adultos < 1:

            adultos = 1

        if menores < 0:

            menores = 0

        total_personas = (
            adultos +
            menores
        )

        # ======================================================
        # VALIDAR FECHA DEL VIAJE
        # ======================================================

        fecha_viaje = (
            request.form.get(
                "fecha_inicio"
            )
            or None
        )

        # ------------------------------------------------------
        # FECHA OBLIGATORIA
        # ------------------------------------------------------

        if not fecha_viaje:

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                error=(
                    "Debes seleccionar "
                    "una fecha para el viaje."
                )
            )

        # ------------------------------------------------------
        # CONVERTIR FECHA
        # ------------------------------------------------------

        try:

            fecha_seleccionada = date.fromisoformat(
                fecha_viaje
            )

        except ValueError:

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                error=(
                    "La fecha seleccionada "
                    "no es válida."
                )
            )

        # ------------------------------------------------------
        # FECHA ACTUAL
        # ------------------------------------------------------

        hoy = date.today()

        # ------------------------------------------------------
        # NO PERMITIR FECHAS PASADAS
        # ------------------------------------------------------

        if fecha_seleccionada < hoy:

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                error=(
                    "No puedes reservar una fecha "
                    "anterior a hoy."
                )
            )

        # ------------------------------------------------------
        # VALIDAR FECHA DE INICIO DEL PAQUETE
        # ------------------------------------------------------

        if paquete.get("fecha_inicio"):

            try:

                fecha_inicio_paquete = date.fromisoformat(
                    str(
                        paquete["fecha_inicio"]
                    )
                )

            except ValueError:

                fecha_inicio_paquete = None

            if (
                fecha_inicio_paquete
                and fecha_seleccionada
                < fecha_inicio_paquete
            ):

                return render_template(
                    "cliente/reserva.html",
                    paquete=paquete,
                    error=(
                        "La fecha elegida es anterior "
                        "al inicio del paquete."
                    )
                )

        # ------------------------------------------------------
        # VALIDAR FECHA FINAL DEL PAQUETE
        # ------------------------------------------------------

        if paquete.get("fecha_fin"):

            try:

                fecha_fin_paquete = date.fromisoformat(
                    str(
                        paquete["fecha_fin"]
                    )
                )

            except ValueError:

                fecha_fin_paquete = None

            if (
                fecha_fin_paquete
                and fecha_seleccionada
                > fecha_fin_paquete
            ):

                return render_template(
                    "cliente/reserva.html",
                    paquete=paquete,
                    error=(
                        "La fecha elegida es posterior "
                        "al final del paquete."
                    )
                )

        # ======================================================
        # MÉTODO DE PAGO
        # ======================================================

        metodo_pago = request.form.get(
            "metodo_pago",
            "Correo electrónico"
        )

        # ======================================================
        # POLÍTICA DE NO REEMBOLSO
        # ======================================================

        politica_no_reembolso = (
            request.form.get(
                "politica_no_reembolso"
            ) == "on"
        )

        # ======================================================
        # SERVICIOS EXTRA
        # ======================================================

        extras_raw = request.form.getlist(
            "extras"
        )

        extras_ids = []

        for extra in extras_raw:

            if extra.isdigit():

                extras_ids.append(
                    int(extra)
                )

        # ======================================================
        # VIAJEROS
        # ======================================================

        viajeros = self._leer_viajeros(
            total_personas,
            menores
        )

        # ======================================================
        # PRECIO
        # ======================================================

        try:

            precio_final = float(
                paquete.get(
                    "precio_final",
                    paquete.get(
                        "precio",
                        0
                    )
                )
            )

        except (
            ValueError,
            TypeError
        ):

            precio_final = 0

        # ======================================================
        # TOTAL
        # ======================================================

        monto_total = (
            precio_final *
            total_personas
        )

        # ======================================================
        # CREAR RESERVA
        # ======================================================

        resultado = self.service.confirmar_reserva(

            id_usuario=id_usuario,

            id_paquete=paquete["id_paquete"],

            cantidad_adultos=adultos,

            cantidad_menores=menores,

            fecha_viaje=fecha_viaje,

            metodo_pago_informativo=metodo_pago,

            politica_no_reembolso_aceptada=(
                politica_no_reembolso
            ),

            extras_ids=extras_ids,

            viajeros=viajeros,

            monto_total=monto_total
        )

        # ======================================================
        # ERROR
        # ======================================================

        if not resultado.get("ok"):

            return render_template(
                "cliente/reserva.html",
                paquete=paquete,
                error=resultado.get(
                    "error",
                    "No fue posible crear la reserva."
                )
            )

        # ======================================================
        # GUARDAR ÚLTIMA RESERVA
        # ======================================================

        session["ultima_reserva_codigo"] = (
            resultado["codigo_unico"]
        )

        session["ultima_reserva_id"] = (
            resultado["id_reserva"]
        )

        # ======================================================
        # IR AL PERFIL
        # ======================================================

        return redirect(
            url_for("perfil")
        )

    # ==========================================================
    # MIS RESERVAS
    # ==========================================================

    def mis_reservas(self):

        usuario = session.get("usuario")

        if not usuario:

            return redirect(
                url_for("login")
            )

        id_usuario = usuario.get(
            "id_usuario"
        )

        if not id_usuario:

            return redirect(
                url_for("login")
            )

        reservas = self.service.obtener_reservas_cliente(
            id_usuario
        )

        return render_template(
            "cliente/mis_reservas.html",
            reservas=reservas
        )

    # ==========================================================
    # ÚLTIMA RESERVA
    # ==========================================================

    def obtener_ultima_reserva(self):

        usuario = session.get("usuario")

        if not usuario:

            return redirect(
                url_for("login")
            )

        id_usuario = usuario.get(
            "id_usuario"
        )

        if not id_usuario:

            return jsonify({
                "error": (
                    "La sesión no contiene "
                    "id_usuario."
                )
            }), 401

        reserva = self.service.obtener_ultima_reserva(
            id_usuario
        )

        return jsonify(
            reserva if reserva else {}
        )

    # ==========================================================
    # MOSTRAR EDITAR FECHA
    # ==========================================================

    def mostrar_editar_fecha(
        self,
        id_reserva
    ):

        usuario = session.get("usuario")

        if not usuario:

            return redirect(
                url_for("login")
            )

        id_usuario = usuario.get(
            "id_usuario"
        )

        if not id_usuario:

            return redirect(
                url_for("login")
            )

        reserva = self.service.obtener_reserva_cliente(
            id_reserva=id_reserva,
            id_cliente=id_usuario
        )

        if not reserva:

            return redirect(
                url_for("perfil")
            )

        return render_template(
            "cliente/editar_fecha.html",
            reserva=reserva
        )

    # ==========================================================
    # EDITAR FECHA
    # ==========================================================

    def editar_fecha(
        self,
        id_reserva
    ):

        usuario = session.get("usuario")

        if not usuario:

            return redirect(
                url_for("login")
            )

        id_usuario = usuario.get(
            "id_usuario"
        )

        if not id_usuario:

            return jsonify({
                "ok": False,
                "error": (
                    "La sesión no contiene "
                    "id_usuario."
                )
            }), 401

        nueva_fecha = request.form.get(
            "fecha_viaje"
        )

        if not nueva_fecha:

            return jsonify({
                "ok": False,
                "error": (
                    "Debes seleccionar "
                    "una fecha."
                )
            }), 400

        # ------------------------------------------------------
        # VALIDAR FORMATO DE FECHA
        # ------------------------------------------------------

        try:

            fecha_seleccionada = date.fromisoformat(
                nueva_fecha
            )

        except ValueError:

            return jsonify({
                "ok": False,
                "error": (
                    "La fecha seleccionada "
                    "no es válida."
                )
            }), 400

        # ------------------------------------------------------
        # NO PERMITIR FECHAS PASADAS
        # ------------------------------------------------------

        if fecha_seleccionada < date.today():

            return jsonify({
                "ok": False,
                "error": (
                    "No puedes seleccionar "
                    "una fecha anterior a hoy."
                )
            }), 400

        # ------------------------------------------------------
        # ACTUALIZAR
        # ------------------------------------------------------

        actualizado = self.service.actualizar_fecha(

            id_reserva=id_reserva,

            id_cliente=id_usuario,

            nueva_fecha=nueva_fecha
        )

        if not actualizado:

            reserva = self.service.obtener_reserva_cliente(
                id_reserva=id_reserva,
                id_cliente=id_usuario
            )

            return render_template(
                "cliente/editar_fecha.html",
                reserva=reserva,
                error=(
                    "No fue posible actualizar "
                    "la fecha. Verifica que esté "
                    "dentro del rango disponible "
                    "del paquete."
                )
            )

        session["mensaje_reserva"] = (
            "La fecha de tu reserva fue "
            "actualizada correctamente."
        )

        return redirect(
            url_for("reserva.mis_reservas")
        )

    # ==========================================================
    # CANCELAR RESERVA
    # ==========================================================

    def cancelar_reserva(
        self,
        id_reserva
    ):

        usuario = session.get("usuario")

        if not usuario:

            return redirect(
                url_for("login")
            )

        id_usuario = usuario.get(
            "id_usuario"
        )

        if not id_usuario:

            return jsonify({
                "ok": False,
                "error": (
                    "La sesión no contiene "
                    "id_usuario."
                )
            }), 401

        resultado = self.service.cancelar_reserva(

            id_reserva=id_reserva,

            id_cliente=id_usuario
        )

        if not resultado.get("ok"):

            return jsonify(
                resultado
            ), 400

        return jsonify(
            resultado
        ), 200

    # ==========================================================
    # LEER VIAJEROS
    # ==========================================================

    def _leer_viajeros(
        self,
        total_personas,
        cantidad_menores
    ):

        viajeros = []

        for i in range(total_personas):

            nombre = request.form.get(
                f"viajero_nombre_{i}",
                ""
            ).strip()

            apellido = request.form.get(
                f"viajero_apellido_{i}",
                ""
            ).strip()

            tipo_documento = request.form.get(
                f"viajero_tipo_doc_{i}",
                "CC"
            ).strip()

            numero_documento = request.form.get(
                f"viajero_num_doc_{i}",
                ""
            ).strip()

            if not nombre:

                continue

            nombre_completo = (
                f"{nombre} {apellido}"
            ).strip()

            es_menor = (
                i >= (
                    total_personas -
                    cantidad_menores
                )
            )

            viajeros.append({

                "nombre_completo":
                    nombre_completo,

                "tipo_documento":
                    tipo_documento,

                "numero_documento":
                    numero_documento,

                "es_menor":
                    es_menor

            })

        return viajeros

