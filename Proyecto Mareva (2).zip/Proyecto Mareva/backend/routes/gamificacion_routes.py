from flask import (
    Blueprint,
    session,
    redirect,
    url_for,
    render_template
)

from services.gamificacion_service import (
    GamificacionService
)


gamificacion_bp = Blueprint(
    "gamificacion",
    __name__
)


@gamificacion_bp.route(
    "/niveles"
)
def niveles():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    service = GamificacionService()

    progreso = service.calcular(
        usuario["id_usuario"]
    )

    return render_template(
        "cliente/niveles.html",
        usuario=usuario,
        progreso=progreso
    )


@gamificacion_bp.route(
    "/insignias"
)
def insignias():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    service = GamificacionService()

    progreso = service.calcular(
        usuario["id_usuario"]
    )

    return render_template(
        "cliente/insignias.html",
        usuario=usuario,
        progreso=progreso
    )