from flask import (
    Blueprint,
    session,
    redirect,
    url_for,
    jsonify,
    render_template
)

from services.favorito_service import FavoritoService


favoritos_bp = Blueprint(
    "favoritos",
    __name__
)


def obtener_service():

    return FavoritoService()


@favoritos_bp.route(
    "/favoritos",
    methods=["GET"]
)
def favoritos():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario.get(
        "id_usuario"
    )

    service = obtener_service()

    lista = service.listar(
        id_usuario
    )

    return render_template(
        "cliente/favoritos.html",
        usuario=usuario,
        favoritos=lista
    )


@favoritos_bp.route(
    "/api/favoritos/<int:id_paquete>",
    methods=["POST"]
)
def alternar_favorito(id_paquete):

    usuario = session.get("usuario")

    if not usuario:

        return jsonify(
            {
                "ok": False,
                "mensaje": "Debes iniciar sesión."
            }
        ), 401

    id_usuario = usuario.get(
        "id_usuario"
    )

    service = obtener_service()

    favorito = service.alternar(
        id_usuario,
        id_paquete
    )

    return jsonify(
        {
            "ok": True,
            "favorito": favorito,
            "mensaje": (
                "Paquete agregado a favoritos."
                if favorito
                else
                "Paquete eliminado de favoritos."
            )
        }
    )