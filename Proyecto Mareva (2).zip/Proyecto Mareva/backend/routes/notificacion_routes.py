from flask import (
    Blueprint,
    session,
    redirect,
    url_for,
    jsonify,
    render_template
)

from services.notificacion_service import (
    NotificacionService
)


notificaciones_bp = Blueprint(
    "notificaciones",
    __name__
)


def obtener_service():

    return NotificacionService()


@notificaciones_bp.route(
    "/notificaciones"
)
def notificaciones():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    id_usuario = usuario["id_usuario"]

    service = obtener_service()

    lista = service.listar(
        id_usuario
    )

    return render_template(
        "cliente/notificaciones.html",
        usuario=usuario,
        notificaciones=lista
    )


@notificaciones_bp.route(
    "/api/notificaciones/<int:id_notificacion>/leer",
    methods=["POST"]
)
def marcar_leida(id_notificacion):

    usuario = session.get("usuario")

    if not usuario:

        return jsonify(
            {
                "ok": False
            }
        ), 401

    service = obtener_service()

    service.marcar_leida(
        usuario["id_usuario"],
        id_notificacion
    )

    return jsonify(
        {
            "ok": True
        }
    )


@notificaciones_bp.route(
    "/api/notificaciones/leer-todas",
    methods=["POST"]
)
def marcar_todas():

    usuario = session.get("usuario")

    if not usuario:

        return jsonify(
            {
                "ok": False
            }
        ), 401

    service = obtener_service()

    service.marcar_todas(
        usuario["id_usuario"]
    )

    return jsonify(
        {
            "ok": True
        }
    )


@notificaciones_bp.route(
    "/api/notificaciones/no-leidas"
)
def cantidad_no_leidas():

    usuario = session.get("usuario")

    if not usuario:

        return jsonify(
            {
                "cantidad": 0
            }
        )

    service = obtener_service()

    cantidad = service.no_leidas(
        usuario["id_usuario"]
    )

    return jsonify(
        {
            "cantidad": cantidad
        }
    )