from flask import (
    Blueprint,
    session,
    redirect,
    url_for,
    render_template,
    request
)

from repositories.perfil_repository import (
    PerfilRepository
)


perfil_bp = Blueprint(
    "perfil_nuevo",
    __name__
)


@perfil_bp.route(
    "/perfil-editar",
    methods=["GET", "POST"]
)
def editar():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    repo = PerfilRepository()

    if request.method == "POST":

        datos = {

            "nombre":
                request.form.get(
                    "nombre",
                    ""
                ).strip(),

            "apellido":
                request.form.get(
                    "apellido",
                    ""
                ).strip(),

            "telefono":
                request.form.get(
                    "telefono",
                    ""
                ).strip(),

            "correo":
                request.form.get(
                    "correo",
                    ""
                ).strip()
        }

        if not all(datos.values()):

            perfil = repo.obtener(
                usuario["id_usuario"]
            )

            return render_template(
                "cliente/editar_perfil.html",
                usuario=usuario,
                perfil=perfil,
                error="Todos los campos son obligatorios."
            )

        repo.actualizar(
            usuario["id_usuario"],
            datos
        )

        usuario.update(datos)

        session["usuario"] = usuario

        return redirect(
            url_for("perfil")
        )

    perfil = repo.obtener(
        usuario["id_usuario"]
    )

    return render_template(
        "cliente/editar_perfil.html",
        usuario=usuario,
        perfil=perfil
    )