# ==========================================================
# backend/routes/referidos_routes.py
# ==========================================================

from flask import (
    Blueprint,
    session,
    redirect,
    url_for,
    render_template,
    request
)

from services.referido_service import (
    ReferidoService
)


referidos_bp = Blueprint(
    "referidos",
    __name__
)


@referidos_bp.route(
    "/referidos",
    methods=["GET", "POST"]
)
def referidos():

    usuario = session.get("usuario")

    if not usuario:

        return redirect(
            url_for("login")
        )

    service = ReferidoService()

    mensaje = None
    error = None

    if request.method == "POST":

        codigo = request.form.get(
            "codigo",
            ""
        ).strip().upper()

        correcto, resultado = (
            service.aplicar_codigo(
                usuario["id_usuario"],
                codigo
            )
        )

        if correcto:

            mensaje = resultado

        else:

            error = resultado

    codigo = service.obtener_codigo(
        usuario["id_usuario"]
    )

    return render_template(
        "cliente/referidos.html",
        usuario=usuario,
        codigo_referido=codigo,
        mensaje=mensaje,
        error=error
    )