﻿from flask import Blueprint, session, redirect, url_for

from controllers.reserva_controllers import ReservaController


reserva_bp = Blueprint(
    "reserva",
    __name__
)


def obtener_controller():
    return ReservaController()


# ==========================================================
# MOSTRAR FORMULARIO DE RESERVA
# ==========================================================

@reserva_bp.route(
    "/reserva/<slug>",
    methods=["GET"]
)
def mostrar_formulario(slug):

    if "usuario" not in session:

        return redirect(
            url_for(
                "login",
                next=f"/reserva/{slug}"
            )
        )

    controller = obtener_controller()

    return controller.mostrar_formulario(
        slug
    )


# ==========================================================
# DISPONIBILIDAD
# ==========================================================

@reserva_bp.route(
    "/api/paquetes/<int:id_paquete>/disponibilidad",
    methods=["GET"]
)
def disponibilidad(id_paquete):

    controller = obtener_controller()

    return controller.disponibilidad_json(
        id_paquete
    )


# ==========================================================
# CONFIRMAR RESERVA
# ==========================================================

@reserva_bp.route(
    "/confirmar-reserva",
    methods=["POST"]
)
def confirmar():

    controller = obtener_controller()

    return controller.confirmar()


# ==========================================================
# MIS RESERVAS
# ==========================================================

@reserva_bp.route(
    "/mis-reservas",
    methods=["GET"]
)
def mis_reservas():

    if "usuario" not in session:

        return redirect(
            url_for("login")
        )

    controller = obtener_controller()

    return controller.mis_reservas()


# ==========================================================
# ÚLTIMA RESERVA
# ==========================================================

@reserva_bp.route(
    "/api/reserva/ultima",
    methods=["GET"]
)
def obtener_ultima_reserva():

    if "usuario" not in session:

        return redirect(
            url_for("login")
        )

    controller = obtener_controller()

    return controller.obtener_ultima_reserva()


# ==========================================================
# MOSTRAR EDITAR FECHA
# ==========================================================

@reserva_bp.route(
    "/reserva/<int:id_reserva>/editar-fecha",
    methods=["GET"]
)
def mostrar_editar_fecha(id_reserva):

    if "usuario" not in session:

        return redirect(
            url_for("login")
        )

    controller = obtener_controller()

    return controller.mostrar_editar_fecha(
        id_reserva
    )


# ==========================================================
# GUARDAR NUEVA FECHA
# ==========================================================

@reserva_bp.route(
    "/api/reserva/<int:id_reserva>/fecha",
    methods=["POST"]
)
def editar_fecha(id_reserva):

    if "usuario" not in session:

        return redirect(
            url_for("login")
        )

    controller = obtener_controller()

    return controller.editar_fecha(
        id_reserva
    )


# ==========================================================
# CANCELAR RESERVA
# ==========================================================

@reserva_bp.route(
    "/api/reserva/<int:id_reserva>/cancelar",
    methods=["POST"]
)
def cancelar_reserva(id_reserva):

    if "usuario" not in session:

        return redirect(
            url_for("login")
        )

    controller = obtener_controller()

    return controller.cancelar_reserva(
        id_reserva
    )

