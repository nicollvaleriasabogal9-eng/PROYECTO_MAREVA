﻿# ==========================================================
# CAMBIO EN paquetes_routes.py
# ==========================================================

from flask import (
    Blueprint,
    render_template,
    abort,
    session
)

from services.paquete_services import (
    PaqueteService
)

from services.favorito_service import (
    FavoritoService
)


paquetes_bp = Blueprint(
    "paquetes",
    __name__
)


def obtener_service():

    return PaqueteService()


@paquetes_bp.route(
    "/paquetes"
)
def lista():

    service = obtener_service()

    paquetes = service.listar_activos()

    usuario = session.get(
        "usuario"
    )

    favoritos = set()

    if usuario:

        favorito_service = (
            FavoritoService()
        )

        favoritos_data = (
            favorito_service.listar(
                usuario["id_usuario"]
            )
        )

        favoritos = {
            item["id_paquete"]
            for item in favoritos_data
        }

    for paquete in paquetes:

        paquete["es_favorito"] = (
            paquete["id_paquete"]
            in favoritos
        )

    return render_template(
        "cliente/paquetes.html",
        paquetes=paquetes,
        usuario=usuario
    )


@paquetes_bp.route(
    "/paquetes/<slug>"
)
def detalle(slug):

    service = obtener_service()

    paquete = service.obtener_detalle(
        slug
    )

    if not paquete:

        abort(404)

    usuario = session.get(
        "usuario"
    )

    es_favorito = False

    if usuario:

        favorito_service = (
            FavoritoService()
        )

        es_favorito = (
            favorito_service.es_favorito(
                usuario["id_usuario"],
                paquete["id_paquete"]
            )
        )

    paquete["es_favorito"] = (
        es_favorito
    )

    return render_template(
        "cliente/detalle_paquete.html",
        paquete=paquete,
        usuario=usuario
    )