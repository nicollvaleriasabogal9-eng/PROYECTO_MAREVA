from config.conexion import Conexion


class NotificacionRepository:

    def __init__(self):

        self.conexion = (
            Conexion()
            .obtener_conexion()
        )

    def obtener_por_usuario(
        self,
        id_usuario
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT
                id_notificacion,
                titulo,
                mensaje,
                tipo,
                leida,
                fecha_creacion
            FROM notificacion
            WHERE id_usuario = %s
            ORDER BY fecha_creacion DESC
            """,
            (id_usuario,)
        )

        filas = cursor.fetchall()

        cursor.close()

        return [
            {
                "id_notificacion": fila[0],
                "titulo": fila[1],
                "mensaje": fila[2],
                "tipo": fila[3],
                "leida": fila[4],
                "fecha_creacion": fila[5]
            }
            for fila in filas
        ]

    def contar_no_leidas(
        self,
        id_usuario
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT COUNT(*)
            FROM notificacion
            WHERE id_usuario = %s
              AND leida = FALSE
            """,
            (id_usuario,)
        )

        cantidad = cursor.fetchone()[0]

        cursor.close()

        return cantidad

    def marcar_leida(
        self,
        id_usuario,
        id_notificacion
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                UPDATE notificacion
                SET leida = TRUE
                WHERE id_notificacion = %s
                  AND id_usuario = %s
                """,
                (
                    id_notificacion,
                    id_usuario
                )
            )

            actualizado = (
                cursor.rowcount > 0
            )

            self.conexion.commit()

            return actualizado

        except Exception:

            self.conexion.rollback()

            raise

        finally:

            cursor.close()

    def marcar_todas_leidas(
        self,
        id_usuario
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                UPDATE notificacion
                SET leida = TRUE
                WHERE id_usuario = %s
                  AND leida = FALSE
                """,
                (id_usuario,)
            )

            self.conexion.commit()

        except Exception:

            self.conexion.rollback()

            raise

        finally:

            cursor.close()

    def crear(
        self,
        id_usuario,
        titulo,
        mensaje,
        tipo="general"
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO notificacion
                (
                    id_usuario,
                    titulo,
                    mensaje,
                    tipo
                )
                VALUES
                (
                    %s,
                    %s,
                    %s,
                    %s
                )
                """,
                (
                    id_usuario,
                    titulo,
                    mensaje,
                    tipo
                )
            )

            self.conexion.commit()

        except Exception:

            self.conexion.rollback()

            raise

        finally:

            cursor.close()