from config.conexion import Conexion


class GamificacionRepository:

    def __init__(self):

        self.conexion = (
            Conexion()
            .obtener_conexion()
        )

    def obtener_estadisticas(
        self,
        id_usuario
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT
                COUNT(*) FILTER (
                    WHERE r.estado = 'Confirmada'
                ) AS reservas,

                COALESCE(
                    SUM(
                        r.monto_total
                    ) FILTER (
                        WHERE r.estado = 'Confirmada'
                    ),
                    0
                ) AS monto

            FROM reserva r

            WHERE r.id_usuario = %s
            """,
            (id_usuario,)
        )

        fila = cursor.fetchone()

        cursor.close()

        return {
            "reservas": fila[0] or 0,
            "monto": float(fila[1] or 0)
        }

    def obtener_niveles(self):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT
                id_nivel,
                nombre,
                min_monto,
                min_reservas,
                descripcion,
                porcentaje_descuento
            FROM nivel
            ORDER BY min_monto, min_reservas
            """
        )

        filas = cursor.fetchall()

        cursor.close()

        return [
            {
                "id_nivel": fila[0],
                "nombre": fila[1],
                "min_monto": float(fila[2]),
                "min_reservas": fila[3],
                "descripcion": fila[4],
                "porcentaje_descuento": float(fila[5])
            }
            for fila in filas
        ]

    def obtener_insignias(
        self,
        id_usuario
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT
                i.id_insignia,
                i.nombre,
                i.descripcion,
                i.criterio,
                i.valor_criterio,
                i.estado,
                ui.fecha_obtenida
            FROM insignia i

            LEFT JOIN usuario_insignia ui
                ON ui.id_insignia = i.id_insignia
               AND ui.id_usuario = %s

            WHERE i.estado = TRUE

            ORDER BY i.id_insignia
            """,
            (id_usuario,)
        )

        filas = cursor.fetchall()

        cursor.close()

        return [
            {
                "id_insignia": fila[0],
                "nombre": fila[1],
                "descripcion": fila[2],
                "criterio": fila[3],
                "valor_criterio": fila[4],
                "estado": fila[5],
                "obtenida": fila[6] is not None,
                "fecha_obtenida": fila[6]
            }
            for fila in filas
        ]

    def asignar_insignia(
        self,
        id_usuario,
        id_insignia
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO usuario_insignia
                (
                    id_usuario,
                    id_insignia
                )
                VALUES
                (
                    %s,
                    %s
                )
                ON CONFLICT DO NOTHING
                """,
                (
                    id_usuario,
                    id_insignia
                )
            )

            agregado = (
                cursor.rowcount > 0
            )

            self.conexion.commit()

            return agregado

        except Exception:

            self.conexion.rollback()

            raise

        finally:

            cursor.close()

    def actualizar_nivel(
        self,
        id_usuario,
        id_nivel
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                UPDATE usuario
                SET id_nivel = %s
                WHERE id_usuario = %s
                """,
                (
                    id_nivel,
                    id_usuario
                )
            )

            self.conexion.commit()

        except Exception:

            self.conexion.rollback()

            raise

        finally:

            cursor.close()