from config.conexion import Conexion
import random
import string


class ReservaRepository:

    def __init__(self):
        self.conexion = Conexion().obtener_conexion()

    # ==========================================================
    # CREAR RESERVA
    # ==========================================================

    def crear_reserva(
        self,
        id_cliente,
        id_paquete,
        cant_adultos,
        cant_menores,
        fecha_viaje,
        observaciones="",
        metodo_contacto="Correo electrónico",
        monto_total=None,
        politica_no_reembolso=False
    ):

        cursor = self.conexion.cursor()
        codigo_reserva = self._generar_codigo()

        try:

            cursor.execute(
                """
                SELECT precio, cupos_disponibles
                FROM paquete_turistico
                WHERE id_paquete = %s
                FOR UPDATE
                """,
                (id_paquete,)
            )

            paquete = cursor.fetchone()

            if not paquete:
                self.conexion.rollback()
                return {
                    "ok": False,
                    "error": "El paquete seleccionado no existe."
                }

            precio = float(paquete[0])
            cupos_disponibles = int(paquete[1])

            total_personas = (
                int(cant_adultos) +
                int(cant_menores)
            )

            if total_personas <= 0:
                self.conexion.rollback()
                return {
                    "ok": False,
                    "error": "Debe existir al menos un viajero."
                }

            if total_personas > cupos_disponibles:
                self.conexion.rollback()
                return {
                    "ok": False,
                    "error": "No hay cupos suficientes disponibles para este paquete."
                }

            if monto_total is None:
                monto_total = precio * total_personas
            else:
                monto_total = float(monto_total)

            cursor.execute(
                """
                INSERT INTO reserva
                (
                    codigo_reserva,
                    id_usuario,
                    id_paquete,
                    fecha_reserva,
                    fecha_viaje,
                    cantidad_adultos,
                    cantidad_menores,
                    monto_total,
                    metodo_pago_informativo,
                    politica_no_reembolso_aceptada,
                    estado
                )
                VALUES
                (
                    %s,
                    %s,
                    %s,
                    CURRENT_DATE,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    %s,
                    'Pendiente de pago'
                )
                RETURNING id_reserva
                """,
                (
                    codigo_reserva,
                    id_cliente,
                    id_paquete,
                    fecha_viaje,
                    cant_adultos,
                    cant_menores,
                    monto_total,
                    metodo_contacto,
                    politica_no_reembolso
                )
            )

            resultado = cursor.fetchone()

            if not resultado:
                self.conexion.rollback()
                return {
                    "ok": False,
                    "error": "No se pudo crear la reserva."
                }

            id_reserva = resultado[0]

            cursor.execute(
                """
                UPDATE paquete_turistico
                SET cupos_disponibles =
                    cupos_disponibles - %s
                WHERE id_paquete = %s
                """,
                (
                    total_personas,
                    id_paquete
                )
            )

            self.conexion.commit()

            return {
                "ok": True,
                "id_reserva": id_reserva,
                "codigo_unico": codigo_reserva,
                "codigo_reserva": codigo_reserva,
                "monto_total": monto_total
            }

        except Exception as e:

            self.conexion.rollback()

            print("❌ ERROR AL CREAR RESERVA:", str(e))

            return {
                "ok": False,
                "error": "No fue posible procesar la reserva. Intenta de nuevo."
            }

        finally:
            cursor.close()

    # ==========================================================
    # AGREGAR SERVICIOS EXTRA
    # ==========================================================

    def agregar_servicios_extra(
        self,
        id_reserva,
        ids_servicios_extra
    ):

        if not ids_servicios_extra:
            return

        cursor = self.conexion.cursor()

        try:

            for id_extra in ids_servicios_extra:

                cursor.execute(
                    """
                    SELECT precio
                    FROM servicio_extra
                    WHERE id_servicio_extra = %s
                    AND estado = TRUE
                    """,
                    (id_extra,)
                )

                extra = cursor.fetchone()

                if extra:

                    cursor.execute(
                        """
                        INSERT INTO reserva_personalizacion
                        (
                            id_reserva,
                            id_servicio_extra_agregado,
                            precio_ajustado
                        )
                        VALUES
                        (%s, %s, %s)
                        """,
                        (
                            id_reserva,
                            id_extra,
                            extra[0]
                        )
                    )

            self.conexion.commit()

        except Exception as e:

            self.conexion.rollback()
            print("❌ Error agregando servicios extra:", str(e))
            raise

        finally:
            cursor.close()

    # ==========================================================
    # AGREGAR VIAJEROS
    # ==========================================================

    def agregar_viajeros(
        self,
        id_reserva,
        viajeros
    ):

        if not viajeros:
            return

        cursor = self.conexion.cursor()

        try:

            for viajero in viajeros:

                nombre_completo = (
                    viajero.get(
                        "nombre_completo",
                        ""
                    ).strip()
                )

                if not nombre_completo:
                    continue

                cursor.execute(
                    """
                    INSERT INTO viajero
                    (
                        id_reserva,
                        nombre_completo,
                        tipo_documento,
                        numero_documento,
                        es_menor
                    )
                    VALUES
                    (%s, %s, %s, %s, %s)
                    """,
                    (
                        id_reserva,
                        nombre_completo,
                        viajero.get(
                            "tipo_documento",
                            "CC"
                        ),
                        viajero.get(
                            "numero_documento",
                            ""
                        ),
                        viajero.get(
                            "es_menor",
                            False
                        )
                    )
                )

            self.conexion.commit()

        except Exception as e:

            self.conexion.rollback()
            print("❌ Error agregando viajeros:", str(e))
            raise

        finally:
            cursor.close()

    # ==========================================================
    # OBTENER TODAS LAS RESERVAS DEL CLIENTE
    # ==========================================================

    def obtener_reservas_cliente(
        self,
        id_cliente
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    r.id_reserva,
                    r.codigo_reserva,
                    r.fecha_reserva,
                    r.fecha_viaje,
                    r.estado,
                    r.id_paquete,
                    r.cantidad_adultos,
                    r.cantidad_menores,
                    r.monto_total,
                    r.metodo_pago_informativo,
                    r.politica_no_reembolso_aceptada,
                    r.justificacion_cambio,

                    p.nombre,
                    p.imagen_url,
                    p.fecha_inicio,
                    p.fecha_fin

                FROM reserva r

                JOIN paquete_turistico p
                    ON p.id_paquete = r.id_paquete

                WHERE r.id_usuario = %s

                ORDER BY r.id_reserva DESC
                """,
                (id_cliente,)
            )

            filas = cursor.fetchall()

            reservas = []

            for fila in filas:

                reservas.append({

                    "id_reserva": fila[0],

                    "codigo_reserva": fila[1],

                    "codigo_unico": fila[1],

                    "fecha_reserva": fila[2],

                    "fecha_viaje": fila[3],

                    "estado": fila[4],

                    "id_paquete": fila[5],

                    "cantidad_adultos": fila[6],

                    "cantidad_menores": fila[7],

                    "cant_adultos": fila[6],

                    "cant_menores": fila[7],

                    "adultos": fila[6],

                    "menores": fila[7],

                    "monto_total": float(
                        fila[8] or 0
                    ),

                    "metodo_pago": fila[9],

                    "metodo_pago_informativo": fila[9],

                    "politica_no_reembolso": fila[10],

                    "politica_no_reembolso_aceptada": fila[10],

                    "justificacion_cambio": fila[11],

                    "nombre_paquete": fila[12],

                    "paquete_nombre": fila[12],

                    "paquete_imagen": fila[13],

                    "imagen_url": fila[13],

                    "fecha_inicio": fila[14],

                    "fecha_fin": fila[15],

                    "destino": fila[12],

                    "fecha_regreso": fila[15]
                })

            return reservas

        except Exception as e:

            print(
                "❌ ERROR OBTENIENDO RESERVAS:",
                str(e)
            )

            return []

        finally:
            cursor.close()

    # ==========================================================
    # OBTENER ÚLTIMA RESERVA
    # ==========================================================

    def obtener_ultima_reserva_cliente(
        self,
        id_cliente
    ):

        reservas = self.obtener_reservas_cliente(
            id_cliente
        )

        if not reservas:
            return None

        return reservas[0]

    # ==========================================================
    # OBTENER UNA RESERVA ESPECÍFICA
    # ==========================================================

    def obtener_reserva_cliente(
        self,
        id_reserva,
        id_cliente
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    r.id_reserva,
                    r.codigo_reserva,
                    r.id_usuario,
                    r.id_paquete,
                    r.fecha_reserva,
                    r.fecha_viaje,
                    r.cantidad_adultos,
                    r.cantidad_menores,
                    r.monto_total,
                    r.metodo_pago_informativo,
                    r.politica_no_reembolso_aceptada,
                    r.estado,
                    r.justificacion_cambio,

                    p.nombre,
                    p.imagen_url,
                    p.fecha_inicio,
                    p.fecha_fin

                FROM reserva r

                JOIN paquete_turistico p
                    ON p.id_paquete = r.id_paquete

                WHERE r.id_reserva = %s
                AND r.id_usuario = %s

                LIMIT 1
                """,
                (
                    id_reserva,
                    id_cliente
                )
            )

            fila = cursor.fetchone()

            if not fila:
                return None

            return {

                "id_reserva": fila[0],

                "codigo_reserva": fila[1],

                "codigo_unico": fila[1],

                "id_usuario": fila[2],

                "id_paquete": fila[3],

                "fecha_reserva": fila[4],

                "fecha_viaje": fila[5],

                "cantidad_adultos": fila[6],

                "cantidad_menores": fila[7],

                "cant_adultos": fila[6],

                "cant_menores": fila[7],

                "adultos": fila[6],

                "menores": fila[7],

                "monto_total": float(
                    fila[8] or 0
                ),

                "metodo_pago": fila[9],

                "metodo_pago_informativo": fila[9],

                "politica_no_reembolso": fila[10],

                "politica_no_reembolso_aceptada": fila[10],

                "estado": fila[11],

                "justificacion_cambio": fila[12],

                "nombre_paquete": fila[13],

                "paquete_nombre": fila[13],

                "paquete_imagen": fila[14],

                "imagen_url": fila[14],

                "fecha_inicio": fila[15],

                "fecha_fin": fila[16],

                "destino": fila[13],

                "fecha_regreso": fila[16]
            }

        except Exception as e:

            print(
                "❌ ERROR OBTENIENDO RESERVA:",
                str(e)
            )

            return None

        finally:
            cursor.close()

    # ==========================================================
    # ACTUALIZAR FECHA
    # ==========================================================

    def actualizar_fecha(
        self,
        id_reserva,
        id_cliente,
        nueva_fecha
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    r.estado,
                    p.fecha_inicio,
                    p.fecha_fin
                FROM reserva r

                JOIN paquete_turistico p
                    ON p.id_paquete = r.id_paquete

                WHERE r.id_reserva = %s
                AND r.id_usuario = %s

                FOR UPDATE
                """,
                (
                    id_reserva,
                    id_cliente
                )
            )

            reserva = cursor.fetchone()

            if not reserva:
                self.conexion.rollback()
                return False

            estado = reserva[0]
            fecha_inicio = reserva[1]
            fecha_fin = reserva[2]

            if str(estado).lower() == "cancelada":
                self.conexion.rollback()
                return False

            if fecha_inicio:
                if str(nueva_fecha) < str(fecha_inicio):
                    self.conexion.rollback()
                    return False

            if fecha_fin:
                if str(nueva_fecha) > str(fecha_fin):
                    self.conexion.rollback()
                    return False

            cursor.execute(
                """
                UPDATE reserva
                SET fecha_viaje = %s
                WHERE id_reserva = %s
                AND id_usuario = %s
                AND estado <> 'Cancelada'
                """,
                (
                    nueva_fecha,
                    id_reserva,
                    id_cliente
                )
            )

            actualizado = cursor.rowcount > 0

            if actualizado:
                self.conexion.commit()
            else:
                self.conexion.rollback()

            return actualizado

        except Exception as e:

            self.conexion.rollback()

            print(
                "❌ ERROR AL ACTUALIZAR FECHA:",
                str(e)
            )

            return False

        finally:
            cursor.close()

    # ==========================================================
    # CANCELAR RESERVA
    # ==========================================================

    def cancelar_reserva(
        self,
        id_reserva,
        id_cliente
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    r.id_paquete,
                    r.cantidad_adultos,
                    r.cantidad_menores,
                    r.estado

                FROM reserva r

                WHERE r.id_reserva = %s
                AND r.id_usuario = %s

                FOR UPDATE
                """,
                (
                    id_reserva,
                    id_cliente
                )
            )

            reserva = cursor.fetchone()

            if not reserva:

                self.conexion.rollback()

                return {
                    "ok": False,
                    "error": "La reserva no existe."
                }

            id_paquete = reserva[0]

            cantidad_adultos = int(
                reserva[1] or 0
            )

            cantidad_menores = int(
                reserva[2] or 0
            )

            estado = reserva[3]

            if str(estado).lower() == "cancelada":

                self.conexion.rollback()

                return {
                    "ok": False,
                    "error": "Esta reserva ya está cancelada."
                }

            total_personas = (
                cantidad_adultos +
                cantidad_menores
            )

            cursor.execute(
                """
                UPDATE reserva

                SET estado = 'Cancelada'

                WHERE id_reserva = %s
                AND id_usuario = %s
                AND estado <> 'Cancelada'
                """,
                (
                    id_reserva,
                    id_cliente
                )
            )

            if cursor.rowcount == 0:

                self.conexion.rollback()

                return {
                    "ok": False,
                    "error": "No fue posible cancelar la reserva."
                }

            cursor.execute(
                """
                UPDATE paquete_turistico

                SET cupos_disponibles =
                    cupos_disponibles + %s

                WHERE id_paquete = %s
                """,
                (
                    total_personas,
                    id_paquete
                )
            )

            self.conexion.commit()

            return {
                "ok": True,
                "mensaje": "La reserva fue cancelada correctamente."
            }

        except Exception as e:

            self.conexion.rollback()

            print(
                "❌ ERROR AL CANCELAR RESERVA:",
                str(e)
            )

            return {
                "ok": False,
                "error": "No fue posible cancelar la reserva."
            }

        finally:
            cursor.close()

    # ==========================================================
    # GENERAR CÓDIGO
    # ==========================================================

    @staticmethod
    def _generar_codigo():

        return (
            "MRV-"
            +
            "".join(
                random.choices(
                    string.ascii_uppercase +
                    string.digits,
                    k=8
                )
            )
        )

