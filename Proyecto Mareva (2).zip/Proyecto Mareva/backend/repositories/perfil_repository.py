from config.conexion import Conexion


class PerfilRepository:

    def __init__(self):

        self.conexion = (
            Conexion()
            .obtener_conexion()
        )

    def obtener(
        self,
        id_usuario
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT
                u.id_usuario,
                u.nombre,
                u.apellido,
                u.tipo_documento,
                u.numero_documento,
                u.telefono,
                u.correo,
                u.codigo_referido,
                u.estado,
                n.nombre,
                n.porcentaje_descuento
            FROM usuario u

            LEFT JOIN nivel n
                ON n.id_nivel = u.id_nivel

            WHERE u.id_usuario = %s
            """,
            (id_usuario,)
        )

        fila = cursor.fetchone()

        cursor.close()

        if not fila:

            return None

        return {
            "id_usuario": fila[0],
            "nombre": fila[1],
            "apellido": fila[2],
            "tipo_documento": fila[3],
            "numero_documento": fila[4],
            "telefono": fila[5],
            "correo": fila[6],
            "codigo_referido": fila[7],
            "estado": fila[8],
            "nivel": fila[9] or "Explorador",
            "descuento": float(fila[10] or 0)
        }

    def actualizar(
        self,
        id_usuario,
        datos
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                UPDATE usuario
                SET
                    nombre = %s,
                    apellido = %s,
                    telefono = %s,
                    correo = %s
                WHERE id_usuario = %s
                """,
                (
                    datos["nombre"],
                    datos["apellido"],
                    datos["telefono"],
                    datos["correo"],
                    id_usuario
                )
            )

            actualizado = (
                cursor.rowcount > 0
            )

            self.conexion.commit()

            return actualizado

        except Exception:

            self.conexion.rollback()

            raise

        finally:

            cursor.close()