from config.conexion import Conexion


class FavoritoRepository:

    def __init__(self):
        self.conexion = Conexion().obtener_conexion()

    def es_favorito(self, id_usuario, id_paquete):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT 1
            FROM lista_favoritos
            WHERE id_usuario = %s
              AND id_paquete = %s
            """,
            (
                id_usuario,
                id_paquete
            )
        )

        resultado = cursor.fetchone()

        cursor.close()

        return resultado is not None

    def agregar(self, id_usuario, id_paquete):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO lista_favoritos
                (
                    id_usuario,
                    id_paquete
                )
                VALUES
                (
                    %s,
                    %s
                )
                ON CONFLICT
                (
                    id_usuario,
                    id_paquete
                )
                DO NOTHING
                """,
                (
                    id_usuario,
                    id_paquete
                )
            )

            self.conexion.commit()

        except Exception:

            self.conexion.rollback()

            raise

        finally:

            cursor.close()

    def eliminar(self, id_usuario, id_paquete):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                DELETE FROM lista_favoritos
                WHERE id_usuario = %s
                  AND id_paquete = %s
                """,
                (
                    id_usuario,
                    id_paquete
                )
            )

            eliminado = cursor.rowcount > 0

            self.conexion.commit()

            return eliminado

        except Exception:

            self.conexion.rollback()

            raise

        finally:

            cursor.close()

    def alternar(self, id_usuario, id_paquete):

        if self.es_favorito(
            id_usuario,
            id_paquete
        ):

            self.eliminar(
                id_usuario,
                id_paquete
            )

            return False

        self.agregar(
            id_usuario,
            id_paquete
        )

        return True

    def obtener_por_usuario(self, id_usuario):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT
                p.id_paquete,
                p.nombre,
                p.slug,
                p.descripcion,
                p.precio,
                p.imagen_url,
                p.imagen_principal,
                p.estado,
                p.cupos_disponibles,
                d.nombre_destino,
                d.ciudad,
                d.departamento,
                lf.fecha_agregado
            FROM lista_favoritos lf

            INNER JOIN paquete_turistico p
                ON p.id_paquete = lf.id_paquete

            INNER JOIN destino d
                ON d.id_destino = p.id_destino

            WHERE lf.id_usuario = %s

            ORDER BY lf.fecha_agregado DESC
            """,
            (id_usuario,)
        )

        filas = cursor.fetchall()

        cursor.close()

        favoritos = []

        for fila in filas:

            estado = str(
                fila[7]
            ).lower()

            if estado == "activo":

                if fila[8] and fila[8] > 0:
                    disponibilidad = "Disponible"
                else:
                    disponibilidad = "Agotado"

            else:

                disponibilidad = "Desactivado"

            favoritos.append(
                {
                    "id_paquete": fila[0],
                    "nombre": fila[1],
                    "slug": fila[2],
                    "descripcion": fila[3],
                    "precio": float(fila[4]),
                    "imagen_url": fila[5],
                    "imagen_principal": fila[6],
                    "estado": fila[7],
                    "cupos_disponibles": fila[8],
                    "nombre_destino": fila[9],
                    "ciudad": fila[10],
                    "departamento": fila[11],
                    "fecha_agregado": fila[12],
                    "disponibilidad": disponibilidad
                }
            )

        return favoritos