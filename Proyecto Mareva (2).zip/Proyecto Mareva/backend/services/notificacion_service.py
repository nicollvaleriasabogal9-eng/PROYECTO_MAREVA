from repositories.notificacion_repository import (
    NotificacionRepository
)


class NotificacionService:

    def __init__(self):

        self.repo = (
            NotificacionRepository()
        )

    def listar(self, id_usuario):

        return self.repo.obtener_por_usuario(
            id_usuario
        )

    def no_leidas(self, id_usuario):

        return self.repo.contar_no_leidas(
            id_usuario
        )

    def marcar_leida(
        self,
        id_usuario,
        id_notificacion
    ):

        return self.repo.marcar_leida(
            id_usuario,
            id_notificacion
        )

    def marcar_todas(
        self,
        id_usuario
    ):

        return self.repo.marcar_todas_leidas(
            id_usuario
        )