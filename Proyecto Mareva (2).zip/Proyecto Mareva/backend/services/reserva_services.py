from repositories.reserva_repository import ReservaRepository


class ReservaService:

    def __init__(self):
        self.repo = ReservaRepository()

    # ==========================================================
    # CONFIRMAR RESERVA
    # ==========================================================

    def confirmar_reserva(
        self,
        id_usuario,
        id_paquete,
        cantidad_adultos,
        cantidad_menores,
        fecha_viaje,
        metodo_pago_informativo,
        politica_no_reembolso_aceptada,
        extras_ids,
        viajeros,
        monto_total
    ):

        if not politica_no_reembolso_aceptada:
            return {
                "ok": False,
                "error": "Debes aceptar la política de no reembolso para continuar con la reserva."
            }

        try:
            cantidad_adultos = int(cantidad_adultos)
        except (ValueError, TypeError):
            cantidad_adultos = 1

        if cantidad_adultos < 1:
            return {
                "ok": False,
                "error": "Debe haber al menos un adulto en la reserva."
            }

        try:
            cantidad_menores = int(cantidad_menores)
        except (ValueError, TypeError):
            cantidad_menores = 0

        if cantidad_menores < 0:
            cantidad_menores = 0

        if not fecha_viaje:
            return {
                "ok": False,
                "error": "Debes seleccionar una fecha para el viaje."
            }

        try:
            monto_total = float(monto_total)
        except (ValueError, TypeError):
            monto_total = 0

        if monto_total < 0:
            return {
                "ok": False,
                "error": "El monto total no puede ser negativo."
            }

        resultado = self.repo.crear_reserva(

            id_cliente=id_usuario,

            id_paquete=id_paquete,

            cant_adultos=cantidad_adultos,

            cant_menores=cantidad_menores,

            fecha_viaje=fecha_viaje,

            observaciones="",

            metodo_contacto=metodo_pago_informativo,

            monto_total=monto_total,

            politica_no_reembolso=politica_no_reembolso_aceptada
        )

        if not resultado.get("ok"):
            return resultado

        if extras_ids:
            self.repo.agregar_servicios_extra(
                resultado["id_reserva"],
                extras_ids
            )

        if viajeros:
            self.repo.agregar_viajeros(
                resultado["id_reserva"],
                viajeros
            )

        resultado["monto_total"] = monto_total

        return resultado

    # ==========================================================
    # TODAS LAS RESERVAS
    # ==========================================================

    def obtener_reservas_cliente(
        self,
        id_cliente
    ):

        return self.repo.obtener_reservas_cliente(
            id_cliente
        )

    # ==========================================================
    # ÚLTIMA RESERVA
    # ==========================================================

    def obtener_ultima_reserva(
        self,
        id_cliente
    ):

        return self.repo.obtener_ultima_reserva_cliente(
            id_cliente
        )

    # ==========================================================
    # RESERVA ESPECÍFICA
    # ==========================================================

    def obtener_reserva_cliente(
        self,
        id_reserva,
        id_cliente
    ):

        return self.repo.obtener_reserva_cliente(
            id_reserva=id_reserva,
            id_cliente=id_cliente
        )

    # ==========================================================
    # EDITAR FECHA
    # ==========================================================

    def actualizar_fecha(
        self,
        id_reserva,
        id_cliente,
        nueva_fecha
    ):

        if not nueva_fecha:
            return False

        return self.repo.actualizar_fecha(
            id_reserva=id_reserva,
            id_cliente=id_cliente,
            nueva_fecha=nueva_fecha
        )

    # ==========================================================
    # CANCELAR RESERVA
    # ==========================================================

    def cancelar_reserva(
        self,
        id_reserva,
        id_cliente
    ):

        return self.repo.cancelar_reserva(
            id_reserva=id_reserva,
            id_cliente=id_cliente
        )

