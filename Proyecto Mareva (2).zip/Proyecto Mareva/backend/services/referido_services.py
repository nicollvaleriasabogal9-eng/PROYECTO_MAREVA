# ==========================================================
# backend/services/referido_service.py
# ==========================================================

from config.conexion import Conexion


class ReferidoService:

    def __init__(self):

        self.conexion = (
            Conexion()
            .obtener_conexion()
        )

    def obtener_codigo(
        self,
        id_usuario
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT codigo_referido
            FROM usuario
            WHERE id_usuario = %s
            """,
            (id_usuario,)
        )

        fila = cursor.fetchone()

        cursor.close()

        return fila[0] if fila else None

    def aplicar_codigo(
        self,
        id_usuario,
        codigo
    ):

        cursor = self.conexion.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    id_usuario
                FROM usuario
                WHERE codigo_referido = %s
                  AND id_usuario <> %s
                """,
                (
                    codigo,
                    id_usuario
                )
            )

            referido = cursor.fetchone()

            if not referido:

                return False, "Código no válido."

            id_referidor = referido[0]

            cursor.execute(
                """
                SELECT referido_por
                FROM usuario
                WHERE id_usuario = %s
                """,
                (id_usuario,)
            )

            actual = cursor.fetchone()

            if actual and actual[0]:

                return False, "Ya utilizaste un código."

            cursor.execute(
                """
                UPDATE usuario
                SET referido_por = %s
                WHERE id_usuario = %s
                """,
                (
                    id_referidor,
                    id_usuario
                )
            )

            cursor.execute(
                """
                UPDATE usuario
                SET puntos_referido =
                    COALESCE(puntos_referido, 0)
                    + 100
                WHERE id_usuario = %s
                """,
                (id_referidor,)
            )

            cursor.execute(
                """
                INSERT INTO notificacion
                (
                    id_usuario,
                    titulo,
                    mensaje,
                    tipo
                )
                VALUES
                (
                    %s,
                    'Nuevo referido',
                    'Has ganado 100 puntos por referir a un nuevo usuario.',
                    'referido'
                )
                """,
                (id_referidor,)
            )

            self.conexion.commit()

            return True, "Código aplicado correctamente."

        except Exception:

            self.conexion.rollback()

            raise

        finally:

            cursor.close()