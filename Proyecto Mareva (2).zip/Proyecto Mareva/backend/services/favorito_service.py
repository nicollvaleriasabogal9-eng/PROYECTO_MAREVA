from repositories.favorito_repository import FavoritoRepository


class FavoritoService:

    def __init__(self):
        self.repo = FavoritoRepository()

    def alternar(self, id_usuario, id_paquete):

        return self.repo.alternar(
            id_usuario,
            id_paquete
        )

    def es_favorito(
        self,
        id_usuario,
        id_paquete
    ):

        return self.repo.es_favorito(
            id_usuario,
            id_paquete
        )

    def listar(self, id_usuario):

        return self.repo.obtener_por_usuario(
            id_usuario
        )