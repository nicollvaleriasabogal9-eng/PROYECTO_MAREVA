﻿from repositories.reserva_repository import ReservaRepository

repo = ReservaRepository()

resultado = repo.crear_reserva(
    id_cliente=1,
    id_paquete=1,
    cant_adultos=1,
    cant_menores=0,
    fecha_viaje="2026-09-15",
    observaciones="PRUEBA",
    metodo_contacto="Pendiente"
)

print("========================================")
print("RESULTADO DE CREAR RESERVA")
print("========================================")
print(resultado)
