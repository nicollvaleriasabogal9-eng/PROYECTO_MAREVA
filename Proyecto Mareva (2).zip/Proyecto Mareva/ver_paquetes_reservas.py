﻿from config.conexion import Conexion

c = Conexion().obtener_conexion()
cur = c.cursor()

print("========================================")
print("RESERVAS + PAQUETE ASIGNADO")
print("========================================")

cur.execute("""
    SELECT
        r.id_reserva,
        r.codigo_reserva,
        r.id_usuario,
        r.id_paquete,
        p.nombre,
        r.fecha_reserva,
        r.monto_total
    FROM reserva r
    LEFT JOIN paquete_turistico p
        ON p.id_paquete = r.id_paquete
    ORDER BY r.id_reserva DESC
""")

for fila in cur.fetchall():
    print(fila)

print("========================================")
print("PAQUETES DISPONIBLES")
print("========================================")

cur.execute("""
    SELECT
        id_paquete,
        nombre,
        precio,
        fecha_inicio,
        fecha_fin
    FROM paquete_turistico
    ORDER BY id_paquete
""")

for fila in cur.fetchall():
    print(fila)

cur.close()
c.close()
