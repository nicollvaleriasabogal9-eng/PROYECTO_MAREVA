from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/saludo/<nombre>/<int:edad>')
def saludo(nombre, edad):
    return render_template('index.html', nombre=nombre, edad=edad)

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)