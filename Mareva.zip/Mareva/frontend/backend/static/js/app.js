// ==============================
// MAREVA - SISTEMA COMPLETO
// ==============================

// ------------------------------
// UTILIDAD: obtener cards
// ------------------------------
function getCards() {
  return document.querySelectorAll(".card");
}

// ------------------------------
// FILTRO PRINCIPAL (CATEGORÍA)
// ------------------------------
function filtrarPaquetes(categoria) {
  const cards = getCards();
  const botones = document.querySelectorAll(".filtro-btn");

  botones.forEach(btn => btn.classList.remove("active"));

  document
    .querySelector(`[onclick="filtrarPaquetes('${categoria}')"]`)
    ?.classList.add("active");

  cards.forEach(card => {
    const cat = card.dataset.categoria;

    card.style.display =
      categoria === "todos" || cat === categoria ? "block" : "none";
  });

  actualizarContador();
}
function normalizar(str) {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}
// ------------------------------
// BUSCADOR
// ------------------------------
function buscarPaquete(event) {
  event.preventDefault();

const text = normalizar(document.getElementById("searchInput")?.value || "");

  // Si estamos en index, redirigir a paquetes con el query
  const enIndex = !document.getElementById("paquetesGrid");
  if (enIndex) {
    window.location.href = `/paquetes?q=${encodeURIComponent(text)}`;
    return;
  }

  // Si estamos en paquetes, filtrar cards
  const cards = getCards();
  cards.forEach(card => {
    const title = card.querySelector(".card__title")?.innerText.toLowerCase() || "";
    card.style.display = title.includes(text) ? "block" : "none";
  });

  actualizarContador();
}

function actualizarContador(valor) {
  if (valor === undefined) {
    const cards = getCards();
    valor = Array.from(cards).filter(
      c => c.style.display !== "none"
    ).length;
  }

  const el = document.getElementById("totalPaquetes");
  if (el) el.textContent = valor;

  const noResultados = document.getElementById("noResultados");
  if (noResultados) {
    noResultados.hidden = valor !== 0;
  }
}


document.addEventListener("DOMContentLoaded", () => {
});