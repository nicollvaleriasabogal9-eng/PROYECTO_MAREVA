// ===================================
// MAREVA - PAQUETES.JS LIMPIO
// ===================================


// ------------------------------
// 1. FILTROS PRINCIPALES (UN SOLO SISTEMA)
// ------------------------------
function normalizar(str) {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

function aplicarFiltros() {
  const texto = normalizar(document.getElementById("searchInput")?.value || "");
  const categoria = document.getElementById("categoria")?.value || "todos";
  const precio = parseInt(document.getElementById("precioRange")?.value || 9999999);

  const cards = document.querySelectorAll(".card[data-categoria]");
  let visibles = 0;

  cards.forEach(card => {
    const titulo = normalizar(card.querySelector(".card__title")?.textContent || "");
    const desc = normalizar(card.querySelector(".card__desc")?.textContent || "");
    const cat = card.dataset.categoria;
    const precioCard = parseInt(card.dataset.precio || "0");

    const matchTexto = texto === "" || titulo.includes(texto) || desc.includes(texto);
    const matchCat = categoria === "todos" || cat === categoria;
    const matchPrecio = precioCard <= precio;

    const mostrar = matchTexto && matchCat && matchPrecio;
    card.style.display = mostrar ? "block" : "none";
    if (mostrar) visibles++;
  });

  // Contador de resultados
  const contador = document.getElementById("totalPaquetes");
  if (contador) contador.textContent = visibles;

  // Mensaje sin resultados
  const noResultados = document.getElementById("noResultados");
  if (noResultados) noResultados.hidden = visibles !== 0;
}


// ------------------------------
// 2. BUSCADOR (DISPARA EL FILTRO GENERAL)
// ------------------------------
function buscarPaquete(event) {
  if (event) event.preventDefault();
  aplicarFiltros();
}


// ------------------------------
// 3. FILTRO DESDE URL (?q=)
// ------------------------------
function filtrarPorQuery() {
  const params = new URLSearchParams(window.location.search);
  const query = params.get("q");

  if (!query) return;

  const input = document.getElementById("searchInput");
  if (input) input.value = query;

  aplicarFiltros();
}


// ------------------------------
// 4. SLIDER DE PRECIO
// ------------------------------
function actualizarPrecio(valor) {
  const label = document.getElementById("precioValor");

  if (label) {
    label.textContent = "$" + Number(valor).toLocaleString("es-CO");
  }

  aplicarFiltros();
}


// ------------------------------
// 5. RESERVA (SIMULADO)
// ------------------------------
function reservarPaquete(nombre) {
  if (!nombre) return;

  alert(`🧳 Reserva iniciada para: ${nombre}`);

  window.location.href = `/reserva?paquete=${encodeURIComponent(nombre)}`;
}


// ------------------------------
// 6. VER DETALLE
// ------------------------------
function verDetalle(nombre) {
  if (!nombre) return;

  window.location.href = `/detalle?nombre=${encodeURIComponent(nombre)}`;
}


// ------------------------------
// 7. INIT (CARGA AUTOMÁTICA)
// ------------------------------
document.addEventListener("DOMContentLoaded", () => {
  // Leer ?q= de la URL y pre-llenar el buscador
  const params = new URLSearchParams(window.location.search);
  const q = params.get("q");
  if (q) {
    const input = document.getElementById("searchInput");
    if (input) input.value = q;
  }

  aplicarFiltros();
});