import sys
import os


sys.path.append(os.path.join(os.path.dirname(__file__), ".."))

from repositories.auth_repository import AuthRepository
from config.conexion import Conexion
from werkzeug.security import generate_password_hash


def migrar():
    repo = AuthRepository()
    conexion = Conexion().obtener_conexion()
    cursor = conexion.cursor()

    usuarios = repo.obtener_todos_id_password()

    actualizados = 0

    for id_usuario, contrasena in usuarios:
        ya_es_hash = contrasena.startswith("pbkdf2:") or contrasena.startswith("scrypt:")

        if not ya_es_hash:
            nuevo_hash = generate_password_hash(contrasena)

            cursor.execute(
                "UPDATE cliente SET contrasena = %s WHERE id = %s",
                (nuevo_hash, id_usuario)
            )
            actualizados += 1

    conexion.commit()
    cursor.close()

    print(f"Contraseñas migradas: {actualizados} de {len(usuarios)}")


if __name__ == "__main__":
    migrar()