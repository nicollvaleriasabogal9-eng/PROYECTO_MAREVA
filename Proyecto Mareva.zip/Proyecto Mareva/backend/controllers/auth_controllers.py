from flask import redirect, url_for, request, render_template, session
from services.auth_services import AuthServices
import re
import phonenumbers


class AuthController:

    def __init__(self):
        self.service = AuthServices()


    def registrar_usuario(self):

        nombre = " ".join(request.form.get("nombre", "").split())
        apellido = " ".join(request.form.get("apellido", "").split())
        tipo = request.form.get("tipo", "").strip()
        numero = request.form.get("numero", "").strip()
        telefono = request.form.get("telefono", "").strip()
        codigo = request.form.get("codigo", "").strip()
        correo = request.form.get("correo", "").strip().lower()
        password = request.form.get("password", "")


        if not re.fullmatch(r"[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,50}", nombre):
            return render_template("principal/registro.html",
            error="El nombre solo puede contener letras.")


        if not re.fullmatch(r"[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,50}", apellido):
            return render_template("principal/registro.html",
            error="El apellido solo puede contener letras.")


        tipos = ["CC","TI","CE","PA","PEP","PPT","RC"]

        if tipo not in tipos:
            return render_template("principal/registro.html",
            error="Seleccione un documento válido.")


        reglas_documento = {
            "CC": r"\d{6,10}",
            "TI": r"\d{10}",
            "CE": r"\d{6,7}",
            "PA": r"[A-Za-z0-9]{6,12}"
        }


        if tipo in reglas_documento and not re.fullmatch(reglas_documento[tipo], numero):
            return render_template(
                "principal/registro.html",
                error="El número de documento no es válido."
            )


        # VALIDAR TELEFONO 

        try:

            if not telefono.startswith("+"):
                return render_template(
                    "principal/registro.html",
                    error="Ingrese un teléfono válido."
                )


            numero_tel = phonenumbers.parse(
                telefono,
                None
            )


            if not phonenumbers.is_valid_number(numero_tel):
                return render_template(
                    "principal/registro.html",
                    error="El teléfono no es válido para el país seleccionado."
                )


        except phonenumbers.NumberParseException:

            return render_template(
                "principal/registro.html",
                error="Ingrese un teléfono válido."
            )


        # CODIGO REFERIDO

        if codigo and not re.fullmatch(r"[A-Za-z0-9]{1,20}", codigo):
            return render_template(
                "principal/registro.html",
                error="Código de referido inválido."
            )


        # CORREO

        correo_valido = r"^[a-zA-Z0-9._%+-]+@(gmail|outlook|hotmail|live|yahoo)\.(com|es|co)$"

        if not re.fullmatch(correo_valido, correo):
            return render_template(
                "principal/registro.html",
                error="Solo se permiten correos Gmail, Outlook, Hotmail/Live o Yahoo."
            )


        # PASSWORD

        if len(password) < 8:
            return render_template(
                "principal/registro.html",
                error="La contraseña debe tener mínimo 8 caracteres."
            )


        usuario = self.service.registrar_usuario(
            nombre,
            apellido,
            tipo,
            numero,
            telefono,
            codigo,
            correo,
            password
        )


        if usuario:
            return render_template(
                "principal/login.html",
                mensaje="Registro exitoso. Ahora inicia sesión."
            )


        return render_template(
            "principal/registro.html",
            error="No fue posible registrar el usuario."
        )



    def iniciar_sesion(self):

        correo = request.form.get("correo","").strip()
        password = request.form.get("password","")


        usuario = self.service.iniciar_sesion(
            correo,
            password
        )


        if usuario is None:
            return render_template(
                "principal/login.html",
                error="Correo o contraseña incorrectos."
            )


        session["usuario"] = {
            "id": usuario.id,
            "nombre": usuario.nombre,
            "apellido": usuario.apellido,
            "correo": usuario.correo,
            "rol": usuario.rol
        }


        return redirect(
            url_for("home.home")
        )   