from config.conexion import Conexion
import random
import string


class ReservaRepository:

    def __init__(self):
        self.conexion = Conexion().obtener_conexion()

    # ==========================================================
    # CREAR RESERVA
    # ==========================================================

    def crear_reserva(
        self,
        id_cliente,
        id_paquete,
        cant_adultos,
        cant_menores,
        fecha_viaje,
        observaciones,
        metodo_contacto
    ):

        cursor = self.conexion.cursor()
        codigo_reserva = self._generar_codigo()

        try:

            cursor.execute(
                """
                SELECT precio
                FROM paquete_turistico
                WHERE id_paquete = %s
                """,
                (id_paquete,)
            )

            paquete = cursor.fetchone()

            if not paquete:
                cursor.close()

                return {
                    "ok": False,
                    "error": "El paquete seleccionado no existe."
                }

            precio = float(paquete[0])

            total_personas = (
                cant_adultos + cant_menores
            )

            monto_total = (
                precio * total_personas
            )

            # --------------------------------------------------
            # VERIFICAR CUPOS
            # --------------------------------------------------

            cursor.execute(
                """
                SELECT cupos_disponibles
                FROM paquete_turistico
                WHERE id_paquete = %s
                FOR UPDATE
                """,
                (id_paquete,)
            )

            cupos = cursor.fetchone()

            if not cupos:

                self.conexion.rollback()
                cursor.close()

                return {
                    "ok": False,
                    "error": (
                        "No fue posible consultar "
                        "los cupos disponibles."
                    )
                }

            cupos_disponibles = cupos[0]

            if total_personas > cupos_disponibles:

                self.conexion.rollback()
                cursor.close()

                return {
                    "ok": False,
                    "error": (
                        "No hay cupos suficientes disponibles "
                        "para este paquete."
                    )
                }

            # --------------------------------------------------
            # CREAR RESERVA
            # --------------------------------------------------

            cursor.execute(
                """
                INSERT INTO reserva
                    (
                        codigo_reserva,
                        id_usuario,
                        id_paquete,
                        fecha_viaje,
                        cantidad_adultos,
                        cantidad_menores,
                        monto_total,
                        metodo_pago_informativo,
                        estado
                    )
                VALUES
                    (
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        %s,
                        'Pendiente de pago'
                    )
                RETURNING id_reserva
                """,
                (
                    codigo_reserva,
                    id_cliente,
                    id_paquete,
                    fecha_viaje,
                    cant_adultos,
                    cant_menores,
                    monto_total,
                    metodo_contacto
                )
            )

            id_reserva = cursor.fetchone()[0]

            # --------------------------------------------------
            # DESCONTAR CUPOS
            # --------------------------------------------------

            cursor.execute(
                """
                UPDATE paquete_turistico
                SET cupos_disponibles =
                    cupos_disponibles - %s
                WHERE id_paquete = %s
                """,
                (
                    total_personas,
                    id_paquete
                )
            )

            self.conexion.commit()
            cursor.close()

            return {
                "ok": True,
                "id_reserva": id_reserva,
                "codigo_unico": codigo_reserva,
                "codigo_reserva": codigo_reserva,
                "monto_total": monto_total
            }

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "Error al crear reserva:",
                str(e)
            )

            return {
                "ok": False,
                "error": (
                    "No fue posible procesar la reserva. "
                    "Intenta de nuevo."
                )
            }

    # ==========================================================
    # AGREGAR SERVICIOS EXTRA
    # ==========================================================

    def agregar_servicios_extra(
        self,
        id_reserva,
        ids_servicios_extra
    ):

        if not ids_servicios_extra:
            return

        cursor = self.conexion.cursor()

        try:

            for id_extra in ids_servicios_extra:

                cursor.execute(
                    """
                    SELECT precio
                    FROM servicio_extra
                    WHERE id_servicio_extra = %s
                      AND estado = TRUE
                    """,
                    (id_extra,)
                )

                if cursor.fetchone():

                    cursor.execute(
                        """
                        INSERT INTO reserva_personalizacion
                            (
                                id_reserva,
                                id_servicio_extra_agregado,
                                precio_ajustado
                            )
                        VALUES
                            (%s, %s, %s)
                        """,
                        (
                            id_reserva,
                            id_extra,
                            0
                        )
                    )

            self.conexion.commit()

        except Exception:

            self.conexion.rollback()
            raise

        finally:

            cursor.close()

    # ==========================================================
    # AGREGAR VIAJEROS
    # ==========================================================

    def agregar_viajeros(
        self,
        id_reserva,
        viajeros
    ):

        if not viajeros:
            return

        cursor = self.conexion.cursor()

        try:

            for viajero in viajeros:

                nombre_completo = (
                    viajero.get(
                        "nombre_completo",
                        ""
                    ).strip()
                )

                cursor.execute(
                    """
                    INSERT INTO viajero
                        (
                            id_reserva,
                            nombre_completo,
                            tipo_documento,
                            numero_documento,
                            es_menor
                        )
                    VALUES
                        (%s, %s, %s, %s, %s)
                    """,
                    (
                        id_reserva,
                        nombre_completo,
                        viajero.get(
                            "tipo_documento",
                            "CC"
                        ),
                        viajero.get(
                            "numero_documento",
                            ""
                        ),
                        viajero.get(
                            "es_menor",
                            False
                        )
                    )
                )

            self.conexion.commit()

        except Exception:

            self.conexion.rollback()
            raise

        finally:

            cursor.close()

    # ==========================================================
    # OBTENER ÚLTIMA RESERVA DEL CLIENTE
    # ==========================================================

    def obtener_ultima_reserva_cliente(
        self,
        id_cliente
    ):

        cursor = self.conexion.cursor()

        cursor.execute(
            """
            SELECT
                r.codigo_reserva,
                r.fecha_reserva,
                r.fecha_viaje,
                r.estado,
                p.nombre,
                p.imagen_url,
                r.id_paquete,
                r.cantidad_adultos,
                r.cantidad_menores,
                r.monto_total
            FROM reserva r
            JOIN paquete_turistico p
                ON p.id_paquete = r.id_paquete
            WHERE r.id_usuario = %s
            ORDER BY r.id_reserva DESC
            LIMIT 1
            """,
            (id_cliente,)
        )

        fila = cursor.fetchone()

        cursor.close()

        if not fila:
            return None

        return {
            "codigo_unico": fila[0],
            "codigo_reserva": fila[0],
            "fecha_reserva": fila[1],
            "fecha_viaje": fila[2],
            "estado": fila[3],
            "paquete_nombre": fila[4],
            "paquete_imagen": fila[5],
            "id_paquete": fila[6],
            "cant_adultos": fila[7],
            "cant_menores": fila[8],
            "monto_total": float(fila[9])
        }

    # ==========================================================
    # ACTUALIZAR FECHA DE LA RESERVA
    # ==========================================================

    def actualizar_fecha(
        self,
        id_reserva,
        id_cliente,
        nueva_fecha
    ):

        cursor = self.conexion.cursor()

        try:

            # Verificar que la reserva pertenece al usuario
            # y obtener el paquete para validar la fecha.

            cursor.execute(
                """
                SELECT
                    r.id_paquete,
                    p.fecha_inicio,
                    p.fecha_fin
                FROM reserva r
                JOIN paquete_turistico p
                    ON p.id_paquete = r.id_paquete
                WHERE r.id_reserva = %s
                  AND r.id_usuario = %s
                """,
                (
                    id_reserva,
                    id_cliente
                )
            )

            reserva = cursor.fetchone()

            if not reserva:

                cursor.close()

                return False

            id_paquete = reserva[0]
            fecha_inicio = reserva[1]
            fecha_fin = reserva[2]

            # --------------------------------------------------
            # VALIDAR RANGO DE FECHA
            # --------------------------------------------------

            if fecha_inicio and nueva_fecha < str(fecha_inicio):

                cursor.close()
                return False

            if fecha_fin and nueva_fecha > str(fecha_fin):

                cursor.close()
                return False

            # --------------------------------------------------
            # ACTUALIZAR FECHA
            # --------------------------------------------------

            cursor.execute(
                """
                UPDATE reserva
                SET fecha_viaje = %s
                WHERE id_reserva = %s
                  AND id_usuario = %s
                """,
                (
                    nueva_fecha,
                    id_reserva,
                    id_cliente
                )
            )

            actualizado = cursor.rowcount > 0

            self.conexion.commit()
            cursor.close()

            return actualizado

        except Exception as e:

            self.conexion.rollback()
            cursor.close()

            print(
                "Error al actualizar fecha:",
                str(e)
            )

            return False

    # ==========================================================
    # GENERAR CÓDIGO DE RESERVA
    # ==========================================================

    @staticmethod
    def _generar_codigo():

        return "MRV-" + "".join(
            random.choices(
                string.ascii_uppercase
                + string.digits,
                k=8
            )
        )
