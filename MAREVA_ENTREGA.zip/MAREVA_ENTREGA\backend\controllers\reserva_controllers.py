﻿from flask import (
    request,
    session,
    redirect,
    url_for,
    render_template,
    jsonify
)

from services.reserva_services import ReservaService
from services.paquete_services import PaqueteService


class ReservaController:

    def __init__(self):
        self.service = ReservaService()
        self.paquete_service = PaqueteService()

    # ==========================================================
    # MOSTRAR FORMULARIO DE RESERVA
    # ==========================================================

    def mostrar_formulario(self, slug):

        paquete = self.paquete_service.obtener_detalle(slug)

        if not paquete:
            return redirect(
                url_for("paquetes.lista")
            )

        return render_template(
            "cliente/reserva.html",
            paquete=paquete
        )

    # ==========================================================
    # DISPONIBILIDAD DEL PAQUETE
    # ==========================================================

    def disponibilidad_json(self, id_paquete):

        data = self.paquete_service.obtener_disponibilidad(
            id_paquete
        )

        if not data:
            return jsonify({
                "error": "Paquete no encontrado"
            }), 404

        return jsonify(data), 200

    # ==========================================================
    # CONFIRMAR RESERVA
    # ==========================================================

    def confirmar(self):

        usuario = session.get("usuario")

        # ------------------------------------------------------
        # MOSTRAR SESIÓN EN TERMINAL
        # ------------------------------------------------------

        print("========================================")
        print("USUARIO QUE LLEGA A RESERVA:")
        print(usuario)
        print("========================================")

        # ------------------------------------------------------
        # VALIDAR SESIÓN
        # ------------------------------------------------------

        if not usuario:
            return redirect(
                url_for("login")
            )

        # ------------------------------------------------------
        # OBTENER ID DEL USUARIO
        # ------------------------------------------------------

        id_usuario = usuario.get("id_usuario")

        if not id_usuario:

            slug_error = request.form.get("paquete")

            paquete_error = None

            if slug_error:
                paquete_error = (
                    self.paquete_service
                    .obtener_detalle(slug_error)
                )

            return render_template(
                "cliente/reserva.html",
                paquete=paquete_error,
                error=(
                    "Tu sesión no contiene el identificador "
                    "del usuario. Cierra sesión e inicia "
                    "sesión nuevamente."
                )
            )

        # ------------------------------------------------------
        # OBTENER PAQUETE
        # ------------------------------------------------------

        slug = request.form.get("paquete")

        paquete = self.paquete_service.obtener_detalle(slug)

        if not paquete:
            return redirect(
                url_for("paquetes.lista")
            )

        # ------------------------------------------------------
        # CANTIDAD DE ADULTOS Y MENORES
        # ------------------------------------------------------

        try:

            adultos = int(
                request.form.get(
                    "adultos",
                    1
                )
            )

            menores = int(
                request.form.get(
                    "menores",
                    0
                )
            )

        except (ValueError, TypeError):

            adultos = 1
            menores = 0

        # ------------------------------------------------------
        # VALIDAR CANTIDADES
        # ------------------------------------------------------

        if adultos < 1:
            adultos = 1

        if menores < 0:
            menores = 0

        total_personas = adultos + menores

        # ------------------------------------------------------
        # FECHA DEL VIAJE
        # ------------------------------------------------------

        fecha_viaje = (
            request.form.get("fecha_inicio")
            or None
        )

        # ------------------------------------------------------
        # VALIDAR FECHA DEL PAQUETE
        # ------------------------------------------------------

        if (
            fecha_viaje
            and paquete.get("fecha_inicio")
            and paquete.get("fecha_fin")
        ):

            fecha_inicio_paquete = str(
                paquete["fecha_inicio"]
            )

            fecha_fin_paquete = str(
                paquete["fecha_fin"]
            )

            if not (
                fecha_inicio_paquete
                <= fecha_viaje
                <= fecha_fin_paquete
            ):

                return render_template(
                    "cliente/reserva.html",
                    paquete=paquete,
                    error=(
                        "La fecha elegida está fuera "
                        "del rango disponible para "
                        "este paquete."
                    )
                )

        # ------------------------------------------------------
        # MÉTODO DE PAGO
        # ------------------------------------------------------

        metodo_pago = request.form.get(
            "metodo_pago",
            "Pendiente"
        )

        # ------------------------------------------------------
        # POLÍTICA DE NO REEMBOLSO
        # ------------------------------------------------------

        politica_no_reembolso = (
            request.form.get(
                "politica_no_reembolso"
            ) == "on"
        )

        # ------------------------------------------------------
        # SERVICIOS EXTRA
        # ------------------------------------------------------

        extras_raw = request.form.getlist(
            "extras"
        )

        extras_ids = []

        for extra in extras_raw:

            if extra.isdigit():

                extras_ids.append(
                    int(extra)
                )

        # ------------------------------------------------------
        # LEER VIAJEROS
        # ------------------------------------------------------

        viajeros = self._leer_viajeros(
            total_personas,
            menores
        )

        # ------------------------------------------------------
        # CALCULAR TOTAL
        # ------------------------------------------------------

        precio_final = float(
            paquete.get(
                "precio_final",
                paquete.get(
                    "precio",
                    0
                )
            )
        )

        monto_total = (
            precio_final * total_personas
        )

        # ------------------------------------------------------
        # CREAR RESERVA
        # ------------------------------------------------------

        resultado = self.service.confirmar_reserva(

            id_usuario=id_usuario,

            id_paquete=paquete["id_paquete"],

            cantidad_adultos=adultos,

            cantidad_menores=menores,

            fecha_viaje=fecha_viaje,

            metodo_pago_informativo=metodo_pago,

            politica_no_reembolso_aceptada=(
                politica_no_reembolso
            ),

            extras_ids=extras_ids,

            viajeros=viajeros,

            monto_total=monto_total
        )

        # ------------------------------------------------------
        # ERROR
        # ------------------------------------------------------

        if not resultado["ok"]:

            paquete_actual = (
                self.paquete_service
                .obtener_detalle(slug)
            )

            return render_template(
                "cliente/reserva.html",
                paquete=paquete_actual,
                error=resultado["error"]
            )

        # ------------------------------------------------------
        # RESERVA EXITOSA
        # ------------------------------------------------------

        session["ultima_reserva_codigo"] = (
            resultado["codigo_unico"]
        )

        session["ultima_reserva_id"] = (
            resultado["id_reserva"]
        )

        return redirect(
            url_for("inicio")
        )

    # ==========================================================
    # OBTENER ÚLTIMA RESERVA DEL CLIENTE
    # ==========================================================

    def obtener_ultima_reserva(self):

        usuario = session.get("usuario")

        if not usuario:
            return redirect(
                url_for("login")
            )

        id_usuario = usuario.get("id_usuario")

        if not id_usuario:

            return jsonify({
                "error": (
                    "La sesión no contiene "
                    "id_usuario."
                )
            }), 401

        reserva = (
            self.service
            .obtener_ultima_reserva(
                id_usuario
            )
        )

        return jsonify(
            reserva if reserva else {}
        )

    # ==========================================================
    # EDITAR FECHA DE RESERVA
    # ==========================================================

    def editar_fecha(self, id_reserva):

        usuario = session.get("usuario")

        if not usuario:
            return redirect(
                url_for("login")
            )

        id_usuario = usuario.get("id_usuario")

        if not id_usuario:

            return jsonify({
                "ok": False,
                "error": (
                    "La sesión no contiene "
                    "id_usuario."
                )
            }), 401

        # ------------------------------------------------------
        # NUEVA FECHA
        # ------------------------------------------------------

        nueva_fecha = request.form.get(
            "fecha_viaje"
        )

        if not nueva_fecha:

            return jsonify({
                "ok": False,
                "error": (
                    "Debes seleccionar una fecha."
                )
            }), 400

        # ------------------------------------------------------
        # ACTUALIZAR FECHA
        # ------------------------------------------------------

        actualizado = self.service.actualizar_fecha(

            id_reserva=id_reserva,

            id_cliente=id_usuario,

            nueva_fecha=nueva_fecha
        )

        if not actualizado:

            return jsonify({
                "ok": False,
                "error": (
                    "No fue posible actualizar "
                    "la fecha de la reserva."
                )
            }), 400

        return jsonify({
            "ok": True,
            "mensaje": (
                "La fecha de la reserva "
                "fue actualizada correctamente."
            )
        })

    # ==========================================================
    # LEER VIAJEROS
    # ==========================================================

    def _leer_viajeros(
        self,
        total_personas,
        cantidad_menores
    ):

        viajeros = []

        for i in range(total_personas):

            # --------------------------------------------------
            # NOMBRE
            # --------------------------------------------------

            nombre = request.form.get(
                f"viajero_nombre_{i}",
                ""
            ).strip()

            if not nombre:
                continue

            # --------------------------------------------------
            # APELLIDO
            # --------------------------------------------------

            apellido = request.form.get(
                f"viajero_apellido_{i}",
                ""
            ).strip()

            # --------------------------------------------------
            # DOCUMENTO
            # --------------------------------------------------

            tipo_documento = request.form.get(
                f"viajero_tipo_doc_{i}",
                "CC"
            ).strip()

            numero_documento = request.form.get(
                f"viajero_num_doc_{i}",
                ""
            ).strip()

            # --------------------------------------------------
            # NOMBRE COMPLETO
            # --------------------------------------------------

            nombre_completo = (
                f"{nombre} {apellido}"
            ).strip()

            # --------------------------------------------------
            # DETERMINAR SI ES MENOR
            # --------------------------------------------------

            es_menor = (
                i >= (
                    total_personas
                    - cantidad_menores
                )
            )

            viajeros.append({

                "nombre_completo":
                    nombre_completo,

                "tipo_documento":
                    tipo_documento,

                "numero_documento":
                    numero_documento,

                "es_menor":
                    es_menor

            })

        return viajeros

