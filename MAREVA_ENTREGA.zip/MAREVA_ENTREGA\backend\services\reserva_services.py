from repositories.reserva_repository import ReservaRepository


class ReservaService:

    def __init__(self):
        self.repo = ReservaRepository()

    # ==========================================================
    # CONFIRMAR RESERVA
    # ==========================================================

    def confirmar_reserva(
        self,
        id_usuario,
        id_paquete,
        cantidad_adultos,
        cantidad_menores,
        fecha_viaje,
        metodo_pago_informativo,
        politica_no_reembolso_aceptada,
        extras_ids,
        viajeros,
        monto_total
    ):

        # ------------------------------------------------------
        # VALIDAR POLÍTICA
        # ------------------------------------------------------

        if not politica_no_reembolso_aceptada:
            return {
                "ok": False,
                "error": (
                    "Debes aceptar la política de no reembolso "
                    "para continuar con la reserva."
                )
            }

        # ------------------------------------------------------
        # CREAR RESERVA
        # ------------------------------------------------------

        resultado = self.repo.crear_reserva(
            id_cliente=id_usuario,
            id_paquete=id_paquete,
            cant_adultos=cantidad_adultos,
            cant_menores=cantidad_menores,
            fecha_viaje=fecha_viaje,
            observaciones="",
            metodo_contacto=metodo_pago_informativo
        )

        if not resultado["ok"]:
            return resultado

        # ------------------------------------------------------
        # SERVICIOS EXTRA
        # ------------------------------------------------------

        if extras_ids:

            self.repo.agregar_servicios_extra(
                resultado["id_reserva"],
                extras_ids
            )

        # ------------------------------------------------------
        # VIAJEROS
        # ------------------------------------------------------

        if viajeros:

            self.repo.agregar_viajeros(
                resultado["id_reserva"],
                viajeros
            )

        # ------------------------------------------------------
        # TOTAL
        # ------------------------------------------------------

        resultado["monto_total"] = monto_total

        return resultado

    # ==========================================================
    # OBTENER ÚLTIMA RESERVA
    # ==========================================================

    def obtener_ultima_reserva(
        self,
        id_cliente
    ):

        return self.repo.obtener_ultima_reserva_cliente(
            id_cliente
        )

    # ==========================================================
    # EDITAR FECHA DE RESERVA
    # ==========================================================

    def actualizar_fecha(
        self,
        id_reserva,
        id_cliente,
        nueva_fecha
    ):

        return self.repo.actualizar_fecha(
            id_reserva=id_reserva,
            id_cliente=id_cliente,
            nueva_fecha=nueva_fecha
        )