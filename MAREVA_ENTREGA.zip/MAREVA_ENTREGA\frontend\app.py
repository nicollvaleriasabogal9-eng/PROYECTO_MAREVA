﻿import sys
import os

# ==========================================================
# CONFIGURACIÓN DE RUTAS
# ==========================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

BACKEND_DIR = os.path.join(
    BASE_DIR,
    "backend"
)

if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)


# ==========================================================
# IMPORTACIONES
# ==========================================================

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session
)

from config.conexion import Conexion

from routes.paquetes_routes import paquetes_bp
from routes.reserva_routes import reserva_bp


# ==========================================================
# CREAR APLICACIÓN
# ==========================================================

app = Flask(
    __name__,

    template_folder=os.path.join(
        os.path.dirname(
            os.path.abspath(__file__)
        ),
        "templates"
    ),

    static_folder=os.path.join(
        os.path.dirname(
            os.path.abspath(__file__)
        ),
        "static"
    )
)


# ==========================================================
# CLAVE DE SESIÓN
# ==========================================================

app.secret_key = "mareva_secret_2026"


# ==========================================================
# BLUEPRINTS
# ==========================================================

app.register_blueprint(
    paquetes_bp
)

app.register_blueprint(
    reserva_bp
)


# ==========================================================
# INICIO
# ==========================================================

@app.route("/")
def inicio():

    return render_template(
        "principal/index.html"
    )


# ==========================================================
# DESTINOS
# ==========================================================

@app.route("/destinos")
def destinos():

    return render_template(
        "cliente/destinos.html"
    )


# ==========================================================
# NIVELES
# ==========================================================

@app.route("/niveles")
def niveles():

    return render_template(
        "cliente/niveles.html"
    )


# ==========================================================
# INSIGNIAS
# ==========================================================

@app.route("/insignias")
def insignias():

    usuario = session.get(
        "usuario",
        {}
    )

    if "insignias" not in usuario:

        usuario["insignias"] = []

    return render_template(
        "cliente/insignias.html",
        usuario=usuario
    )


# ==========================================================
# PERFIL
# ==========================================================

@app.route("/perfil")
def perfil():

    usuario = session.get(
        "usuario"
    )

    if not usuario:

        return redirect(
            url_for("login")
        )

    return render_template(
        "cliente/perfil.html",
        usuario=usuario
    )


# ==========================================================
# LOGIN
# ==========================================================

@app.route(
    "/login",
    methods=["GET", "POST"]
)
def login():

    if request.method == "POST":

        # --------------------------------------------------
        # OBTENER DATOS
        # --------------------------------------------------

        correo = request.form.get(
            "correo",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        ).strip()


        # --------------------------------------------------
        # VALIDAR CAMPOS
        # --------------------------------------------------

        if not correo or not password:

            return render_template(
                "principal/login.html",
                error=(
                    "Debes ingresar "
                    "correo y contraseña."
                )
            )


        conexion = None
        cursor = None


        try:

            # --------------------------------------------------
            # CONECTAR A POSTGRESQL
            # --------------------------------------------------

            conexion = (
                Conexion()
                .obtener_conexion()
            )

            cursor = conexion.cursor()


            # --------------------------------------------------
            # BUSCAR USUARIO
            # --------------------------------------------------

            cursor.execute(
                """
                SELECT
                    id_usuario,
                    nombre,
                    apellido,
                    correo,
                    contrasena,
                    rol,
                    estado
                FROM usuario
                WHERE correo = %s
                """,
                (correo,)
            )


            usuario_db = cursor.fetchone()


            # --------------------------------------------------
            # USUARIO NO EXISTE
            # --------------------------------------------------

            if not usuario_db:

                return render_template(
                    "principal/login.html",
                    error=(
                        "Correo o contraseña "
                        "incorrectos."
                    )
                )


            # --------------------------------------------------
            # SEPARAR DATOS
            # --------------------------------------------------

            (
                id_usuario,
                nombre,
                apellido,
                correo_db,
                contrasena_db,
                rol,
                estado
            ) = usuario_db


            # --------------------------------------------------
            # VALIDAR CONTRASEÑA
            # --------------------------------------------------

            if password != contrasena_db:

                return render_template(
                    "principal/login.html",
                    error=(
                        "Correo o contraseña "
                        "incorrectos."
                    )
                )


            # --------------------------------------------------
            # VALIDAR ESTADO
            # --------------------------------------------------

            if estado != "activo":

                return render_template(
                    "principal/login.html",
                    error=(
                        "Este usuario se encuentra "
                        "inactivo."
                    )
                )


            # --------------------------------------------------
            # LIMPIAR SESIÓN ANTERIOR
            # --------------------------------------------------

            session.clear()


            # --------------------------------------------------
            # GUARDAR USUARIO EN SESIÓN
            # --------------------------------------------------

            session["usuario"] = {

                "id_usuario": id_usuario,

                "nombre": nombre,

                "apellido": apellido,

                "correo": correo_db,

                "rol": rol,

                "nivel": "Explorador",

                "insignias": []

            }


            # --------------------------------------------------
            # MOSTRAR EN TERMINAL
            # --------------------------------------------------

            print(
                "========================================"
            )

            print(
                "USUARIO GUARDADO EN SESION:"
            )

            print(
                session["usuario"]
            )

            print(
                "========================================"
            )


            # --------------------------------------------------
            # IR AL PERFIL
            # --------------------------------------------------

            return redirect(
                url_for("perfil")
            )


        except Exception as e:

            print(
                "Error en login:",
                str(e)
            )

            return render_template(
                "principal/login.html",
                error=(
                    "Ocurrió un error "
                    "al iniciar sesión."
                )
            )


        finally:

            if cursor:

                cursor.close()

            if conexion:

                conexion.close()


    # ------------------------------------------------------
    # MOSTRAR LOGIN
    # ------------------------------------------------------

    return render_template(
        "principal/login.html"
    )


# ==========================================================
# REGISTRO
# ==========================================================

@app.route(
    "/registro",
    methods=["GET", "POST"]
)
def registro():

    if request.method == "POST":

        nombre = request.form.get(
            "nombre",
            ""
        ).strip()

        apellido = request.form.get(
            "apellido",
            ""
        ).strip()

        correo = request.form.get(
            "correo",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        ).strip()

        confirmar = request.form.get(
            "confirmar",
            ""
        ).strip()


        # --------------------------------------------------
        # VALIDAR CAMPOS
        # --------------------------------------------------

        if (
            not nombre
            or not apellido
            or not correo
            or not password
        ):

            return render_template(
                "principal/registro.html",
                error=(
                    "Todos los campos "
                    "son obligatorios."
                )
            )


        # --------------------------------------------------
        # VALIDAR CONTRASEÑAS
        # --------------------------------------------------

        if password != confirmar:

            return render_template(
                "principal/registro.html",
                error=(
                    "Las contraseñas "
                    "no coinciden."
                )
            )


        conexion = None
        cursor = None


        try:

            conexion = (
                Conexion()
                .obtener_conexion()
            )

            cursor = conexion.cursor()


            # --------------------------------------------------
            # VERIFICAR CORREO
            # --------------------------------------------------

            cursor.execute(
                """
                SELECT id_usuario
                FROM usuario
                WHERE correo = %s
                """,
                (correo,)
            )

            existe = cursor.fetchone()


            if existe:

                return render_template(
                    "principal/registro.html",
                    error=(
                        "Ya existe un usuario "
                        "con ese correo."
                    )
                )


            # --------------------------------------------------
            # CREAR USUARIO
            # --------------------------------------------------

            cursor.execute(
                """
                INSERT INTO usuario
                    (
                        nombre,
                        apellido,
                        tipo_documento,
                        numero_documento,
                        telefono,
                        correo,
                        contrasena,
                        rol,
                        acepta_terminos,
                        estado
                    )
                VALUES
                    (
                        %s,
                        %s,
                        'CC',
                        '',
                        '',
                        %s,
                        %s,
                        'cliente',
                        TRUE,
                        'activo'
                    )
                RETURNING id_usuario
                """,
                (
                    nombre,
                    apellido,
                    correo,
                    password
                )
            )


            id_usuario = cursor.fetchone()[0]

            conexion.commit()


            # --------------------------------------------------
            # GUARDAR EN SESIÓN
            # --------------------------------------------------

            session.clear()

            session["usuario"] = {

                "id_usuario": id_usuario,

                "nombre": nombre,

                "apellido": apellido,

                "correo": correo,

                "rol": "cliente",

                "nivel": "Explorador",

                "insignias": []

            }


            print(
                "========================================"
            )

            print(
                "USUARIO REGISTRADO Y GUARDADO:"
            )

            print(
                session["usuario"]
            )

            print(
                "========================================"
            )


            return redirect(
                url_for("perfil")
            )


        except Exception as e:

            if conexion:

                conexion.rollback()

            print(
                "Error en registro:",
                str(e)
            )

            return render_template(
                "principal/registro.html",
                error=(
                    "No fue posible "
                    "crear el usuario."
                )
            )


        finally:

            if cursor:

                cursor.close()

            if conexion:

                conexion.close()


    return render_template(
        "principal/registro.html"
    )


# ==========================================================
# LOGOUT
# ==========================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("inicio")
    )


# ==========================================================
# LIMPIAR SESIÓN
# ==========================================================

@app.route("/limpiar-sesion")
def limpiar_sesion():

    session.clear()

    print(
        "SESION ELIMINADA CORRECTAMENTE"
    )

    return redirect(
        url_for("login")
    )


# ==========================================================
# EJECUTAR APLICACIÓN
# ==========================================================

if __name__ == "__main__":

    app.run(
        debug=True
    )

