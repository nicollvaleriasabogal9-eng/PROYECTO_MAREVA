﻿from flask import Blueprint, render_template, abort
from services.paquete_services import PaqueteService

paquetes_bp = Blueprint("paquetes", __name__)

def obtener_service():
    return PaqueteService()


@paquetes_bp.route("/paquetes")
def lista():
    service = obtener_service()
    paquetes = service.listar_activos()

    return render_template(
        "cliente/paquetes.html",
        paquetes=paquetes
    )


@paquetes_bp.route("/paquetes/<slug>")
def detalle(slug):
    service = obtener_service()
    paquete = service.obtener_detalle(slug)

    if not paquete:
        abort(404)

    return render_template(
        "cliente/detalle_paquete.html",
        paquete=paquete
    )
