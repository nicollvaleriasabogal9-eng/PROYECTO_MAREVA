@echo off
setlocal
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo No se encontro Python. Instalalo y marca la opcion "Add Python to PATH".
  pause
  exit /b 1
)

if not exist "venv\Scripts\python.exe" (
  echo Creando el entorno de MAREVA...
  python -m venv venv
  if errorlevel 1 goto :error
)

echo Instalando dependencias...
"venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error

if not exist ".env" copy ".env.example" ".env" >nul

echo.
echo Preparacion terminada.
echo Abre el archivo .env y cambia CAMBIA_ESTA_CONTRASENA.
echo Despues ejecuta INICIAR_MAREVA.bat.
pause
exit /b 0

:error
echo.
echo No se pudo terminar la preparacion. Revisa el mensaje anterior.
pause
exit /b 1
