# MAREVA — actualización de requisitos

Esta versión incluye:

- Niveles como único sistema de fidelización; Insignias fue retirado.
- Descuento automático del nivel, registrado en cada reserva.
- Acceso diferenciado para cliente, guía turístico y administrador.
- Panel del guía con paquetes, reservas, viajeros y gestión de estados.
- Favoritos temporales en la sesión, sin tabla en PostgreSQL.

## Preparación

1. Si todavía no existe la base `mareva`, créala en pgAdmin y ejecuta primero:

   `database/01_base_original.sql`

2. Sobre esa base ejecuta una sola vez:

   `database/actualizacion_requisitos.sql`

3. Haz doble clic en `PREPARAR_MAREVA.bat`. El archivo crea el entorno, instala las dependencias y genera `.env` si hace falta.

4. Abre `.env`, completa la contraseña de PostgreSQL y verifica el puerto. En este equipo se utilizó `5433`.

5. Para ver la aplicación, haz doble clic en `INICIAR_MAREVA.bat`.

También puedes prepararla manualmente con:

   `python -m venv venv`

   `venv\Scripts\python.exe -m pip install -r requirements.txt`

E iniciarla con:

   `venv\Scripts\python.exe backend\main.py`

La dirección es `http://127.0.0.1:5000`.

## Perfiles de prueba

- Cliente: `yadira@test.co` / `cliente_prueba`.
- Administrador: `cesar@mareva.co` / `Admin_mareva01`.
- Guía: `andres.guia@mareva.co` / `Guia_mareva01`.

La primera autenticación correcta de una cuenta antigua o de un guía reemplaza automáticamente la contraseña de texto por un hash seguro.

## Descuento de la reserva

El servidor calcula:

`valor base = precio del paquete × viajeros + servicios extra`

`ahorro = valor base × porcentaje del nivel / 100`

`valor final = valor base − ahorro`

Los campos `valor_base`, `porcentaje_descuento`, `valor_descuento` y `valor_referencial` quedan asociados a la reserva. El nivel que se alcance con esa compra se usa a partir de la siguiente reserva.

## Favoritos

Los identificadores se conservan únicamente en la sesión firmada de Flask. No existe ni se necesita una tabla de favoritos. Al cerrar sesión se limpia la selección.
