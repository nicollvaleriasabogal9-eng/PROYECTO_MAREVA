@echo off
setlocal
cd /d "%~dp0"

if not exist ".env" (
  echo Falta el archivo .env. Ejecuta primero PREPARAR_MAREVA.bat.
  pause
  exit /b 1
)

findstr /c:"CAMBIA_ESTA_CONTRASENA" ".env" >nul
if not errorlevel 1 (
  echo Abre .env y escribe la contrasena de PostgreSQL antes de continuar.
  pause
  exit /b 1
)

if not exist "venv\Scripts\python.exe" (
  echo Falta la preparacion. Ejecuta primero PREPARAR_MAREVA.bat.
  pause
  exit /b 1
)

echo Iniciando MAREVA...
start "Servidor MAREVA" "venv\Scripts\python.exe" "backend\main.py"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:5000"

echo Si la pagina tarda en abrir, espera unos segundos y actualizala.
exit /b 0
