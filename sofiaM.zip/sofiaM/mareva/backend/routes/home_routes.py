from flask import Blueprint, render_template, redirect, session, url_for
from controllers.gamificacion_controllers import GamificacionController

home_bp = Blueprint('home', __name__)
gamificacion_controller = GamificacionController()

#Muestra la página de inicio
@home_bp.route("/")
def home():
    return render_template("principal/index.html")

#Muestra la página de perfil para clientes
@home_bp.route("/perfil")
def perfil(): 
    usuario = session.get('usuario') or {}
    if usuario.get('rol') != 'cliente':
        return redirect(url_for('auth.mostrar_login'))
    return gamificacion_controller.mostrar_perfil()

#Cierra la sesion del usuario y redirige a la página de inicio
@home_bp.route('/logout')
def logout():
    session.clear()
    return render_template("principal/login.html")
