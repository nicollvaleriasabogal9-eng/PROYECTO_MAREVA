import psycopg
import os
from dotenv import load_dotenv

# Busca el .env tanto en la raíz del código como en la carpeta contenedora.
# Esto permite ejecutar backend/main.py sin duplicar las credenciales.
RUTAS_ENV = [
    os.path.join(os.path.dirname(__file__), '../../.env'),
    os.path.join(os.path.dirname(__file__), '../../../.env'),
]

for ruta_env in RUTAS_ENV:
    if os.path.exists(ruta_env):
        load_dotenv(ruta_env)
        break

class Conexion():
    def __init__(self):
        self.conexion = psycopg.connect(
            host=os.getenv("DB_HOST"),
            dbname=os.getenv("DB_NAME"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD"),
            port=os.getenv("DB_PORT")
        )

    def obtener_conexion(self):
        return self.conexion

   
