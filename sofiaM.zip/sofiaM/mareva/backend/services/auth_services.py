from repositories.auth_repository import AuthRepository
from werkzeug.security import check_password_hash
from hmac import compare_digest


class AuthServices:

    def __init__(self):
        self.repository = AuthRepository()

    def registrar_usuario(
        self,
        nombre,
        apellido,
        tipo_documento,
        numero_documento,
        telefono,
        codigo,
        correo,
        password
    ):
        resultado = self.repository.guardar_usuario(
            nombre,
            apellido,
            tipo_documento,
            numero_documento,
            telefono,
            codigo,
            correo,
            password
        )

        return resultado

    def iniciar_sesion(self, correo, password):
        """Identifica automáticamente al cliente, administrador o guía."""
        candidatos = (
            (
                self.repository.buscar_por_correo(correo),
                self.repository.actualizar_password,
            ),
            (
                self.repository.buscar_guia_por_correo(correo),
                self.repository.actualizar_password_guia,
            ),
        )

        for usuario, actualizar_password in candidatos:
            if not usuario or not usuario.estado:
                continue
            if self._password_correcta(
                usuario.password,
                password,
                correo,
                actualizar_password,
            ):
                return usuario

        return None

    @staticmethod
    def _password_correcta(
        password_hash,
        password_ingresada,
        correo,
        actualizar_password,
    ):
        es_hash = password_hash.startswith(("scrypt:", "pbkdf2:"))

        if es_hash:
            return check_password_hash(password_hash, password_ingresada)
        else:
            # Compatibilidad con las cuentas antiguas importadas con la
            # contraseña sin cifrar.
            password_correcta = compare_digest(
                password_hash,
                password_ingresada,
            )

            # Después del primer acceso correcto, la contraseña antigua se
            # reemplaza automáticamente por un hash seguro.
            if password_correcta:
                actualizar_password(correo, password_ingresada)

            return password_correcta
