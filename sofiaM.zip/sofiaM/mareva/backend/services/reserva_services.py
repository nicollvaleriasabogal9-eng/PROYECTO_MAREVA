from repositories.reserva_repository import ReservaRepository
from services.gamificacion_services import GamificacionService
from utils.calculos_reserva import calcular_totales


class ReservaService:

    def __init__(self):
        self.repo = ReservaRepository()
        self.gamificacion = GamificacionService()

    calcular_totales = staticmethod(calcular_totales)

    def confirmar_reserva(
        self,
        id_cliente,
        id_paquete,
        cant_adultos,
        cant_menores,
        fecha_viaje,
        observaciones,
        alergias,
        mascotas,
        plan,
        metodo_contacto,
        extras_ids,
        viajeros,
    ):
        beneficio = self.gamificacion.obtener_beneficio_reserva(id_cliente)
        valores = self.repo.obtener_valores_reserva(id_paquete, extras_ids)
        if not valores:
            return {"ok": False, "error": "El paquete no está disponible."}

        totales = self.calcular_totales(
            valores["precio_paquete"],
            cant_adultos + cant_menores,
            valores["precio_extras"],
            beneficio["porcentaje_descuento"],
        )
        resultado = self.repo.crear_reserva(
            id_cliente,
            id_paquete,
            cant_adultos,
            cant_menores,
            fecha_viaje,
            observaciones,
            alergias,
            mascotas,
            plan,
            metodo_contacto,
            totales,
        )

        if not resultado["ok"]:
            return resultado

        self.repo.agregar_servicios_extra(
            resultado["id_reserva"], valores["extras_validos"]
        )
        if viajeros:
            self.repo.agregar_viajeros(resultado["id_reserva"], viajeros)

        # La reserva nueva puede subir el nivel para la siguiente compra.
        resultado["nivel_aplicado"] = beneficio["nivel"]
        resultado["estadisticas"] = self.gamificacion.sincronizar_cliente(
            id_cliente
        )
        return resultado

    def obtener_ultima_reserva(self, id_cliente):
        return self.repo.obtener_ultima_reserva_cliente(id_cliente)
