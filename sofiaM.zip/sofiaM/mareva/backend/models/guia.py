class GuiaTuristico:
    def __init__(
        self,
        id_guia,
        nombre,
        apellido,
        idiomas,
        especialidad,
        telefono,
        correo,
        contrasena,
        estado,
    ):
        self.id = id_guia
        self.id_guia = id_guia
        self.nombre = nombre
        self.apellido = apellido
        self.idiomas = idiomas
        self.especialidad = especialidad
        self.telefono = telefono
        self.correo = correo
        self.password = contrasena
        self.estado = estado
        self.rol = "guia"
