TRANSICIONES_RESERVA = {
    "solicitada": {"confirmada", "cancelada"},
    "confirmada": {"en_proceso", "cancelada"},
    "en_proceso": {"completada"},
    "completada": set(),
    "cancelada": set(),
}


def transicion_valida(estado_actual, nuevo_estado):
    return nuevo_estado in TRANSICIONES_RESERVA.get(estado_actual, set())
