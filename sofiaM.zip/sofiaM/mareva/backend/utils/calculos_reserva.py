from decimal import Decimal, ROUND_HALF_UP


def calcular_totales(
    precio_paquete,
    cantidad_personas,
    precio_extras,
    porcentaje_descuento,
):
    precio_paquete = Decimal(str(precio_paquete))
    precio_extras = Decimal(str(precio_extras or 0))
    porcentaje = Decimal(str(porcentaje_descuento or 0))
    porcentaje = min(Decimal("100"), max(Decimal("0"), porcentaje))
    cantidad = max(1, int(cantidad_personas))

    valor_base = (
        precio_paquete * cantidad + precio_extras
    ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    valor_descuento = (
        valor_base * porcentaje / Decimal("100")
    ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return {
        "valor_base": valor_base,
        "porcentaje_descuento": porcentaje,
        "valor_descuento": valor_descuento,
        "valor_final": valor_base - valor_descuento,
    }
