import random
import string
from decimal import Decimal

from config.conexion import Conexion


class ReservaRepository:

    def __init__(self):
        self.conexion = Conexion().obtener_conexion()

    def obtener_valores_reserva(self, id_paquete, ids_servicios_extra):
        cursor = self.conexion.cursor()
        cursor.execute("""
            SELECT precio
              FROM paquete_turistico
             WHERE id_paquete = %s
               AND estado = 'activo'
        """, (id_paquete,))
        fila = cursor.fetchone()
        if not fila:
            cursor.close()
            return None

        ids_solicitados = sorted(set(ids_servicios_extra or []))
        extras_validos = []
        total_extras = Decimal("0")
        if ids_solicitados:
            cursor.execute("""
                SELECT id_servicio_extra, precio
                  FROM servicio_extra
                 WHERE id_paquete = %s
                   AND estado = TRUE
                   AND id_servicio_extra = ANY(%s)
            """, (id_paquete, ids_solicitados))
            for id_extra, precio in cursor.fetchall():
                extras_validos.append(id_extra)
                total_extras += Decimal(str(precio or 0))

        cursor.close()
        return {
            "precio_paquete": Decimal(str(fila[0])),
            "precio_extras": total_extras,
            "extras_validos": extras_validos,
        }

    def crear_reserva(
        self,
        id_cliente,
        id_paquete,
        cant_adultos,
        cant_menores,
        fecha_viaje,
        observaciones,
        alergias,
        mascotas,
        plan,
        metodo_contacto,
        totales,
    ):
        cursor = self.conexion.cursor()
        codigo_unico = self._generar_codigo()

        detalles = []
        if observaciones:
            detalles.append(observaciones)
        if alergias:
            detalles.append(f"Alergias: {alergias}")
        if mascotas:
            detalles.append("Viaja con mascotas: sí")
        if plan:
            detalles.append(f"Plan seleccionado: {plan}")
        observaciones_completas = "\n".join(detalles) or None

        try:
            cursor.execute("""
                INSERT INTO reserva
                    (codigo_unico, fecha_viaje, estado, valor_base,
                     porcentaje_descuento, valor_descuento, valor_referencial,
                     cant_adultos, cant_menores, observaciones,
                     metodo_contacto, id_cliente, id_paquete)
                VALUES (%s, %s, 'confirmada', %s, %s, %s, %s,
                        %s, %s, %s, %s, %s, %s)
                RETURNING id_reserva
            """, (
                codigo_unico,
                fecha_viaje,
                totales["valor_base"],
                totales["porcentaje_descuento"],
                totales["valor_descuento"],
                totales["valor_final"],
                cant_adultos,
                cant_menores,
                observaciones_completas,
                metodo_contacto,
                id_cliente,
                id_paquete,
            ))

            id_reserva = cursor.fetchone()[0]
            self.conexion.commit()
            return {
                "ok": True,
                "id_reserva": id_reserva,
                "codigo_unico": codigo_unico,
                **totales,
            }
        except Exception as error:
            self.conexion.rollback()
            if "CUPOS_INSUFICIENTES" in str(error):
                return {
                    "ok": False,
                    "error": "No hay cupos suficientes para las fechas elegidas.",
                }
            return {
                "ok": False,
                "error": "No fue posible procesar la reserva. Intenta de nuevo.",
            }
        finally:
            cursor.close()

    def agregar_servicios_extra(self, id_reserva, ids_servicios_extra):
        if not ids_servicios_extra:
            return
        cursor = self.conexion.cursor()
        for id_extra in ids_servicios_extra:
            cursor.execute("""
                INSERT INTO reserva_servicio_extra
                    (id_reserva, id_servicio_extra)
                VALUES (%s, %s)
                ON CONFLICT DO NOTHING
            """, (id_reserva, id_extra))
        self.conexion.commit()
        cursor.close()

    def agregar_viajeros(self, id_reserva, viajeros):
        if not viajeros:
            return
        cursor = self.conexion.cursor()
        for viajero in viajeros:
            cursor.execute("""
                INSERT INTO viajero_reserva
                    (nombre, apellido, tipo_documento,
                     numero_documento, id_reserva)
                VALUES (%s, %s, %s, %s, %s)
            """, (
                viajero["nombre"],
                viajero["apellido"],
                viajero["tipo_documento"],
                viajero["numero_documento"],
                id_reserva,
            ))
        self.conexion.commit()
        cursor.close()

    def obtener_ultima_reserva_cliente(self, id_cliente):
        cursor = self.conexion.cursor()
        cursor.execute("""
            SELECT r.codigo_unico, r.fecha_reserva, r.estado, p.nombre,
                   p.emoji, r.fecha_viaje, r.valor_base,
                   r.porcentaje_descuento, r.valor_descuento,
                   r.valor_referencial
              FROM reserva r
              JOIN paquete_turistico p ON p.id_paquete = r.id_paquete
             WHERE r.id_cliente = %s
             ORDER BY r.id_reserva DESC
             LIMIT 1
        """, (id_cliente,))
        fila = cursor.fetchone()
        cursor.close()
        if not fila:
            return None
        return {
            "codigo_unico": fila[0],
            "fecha_reserva": fila[1],
            "estado": fila[2],
            "paquete_nombre": fila[3],
            "paquete_emoji": fila[4],
            "fecha_viaje": fila[5],
            "valor_base": fila[6],
            "porcentaje_descuento": fila[7],
            "valor_descuento": fila[8],
            "valor_final": fila[9],
        }

    @staticmethod
    def _generar_codigo():
        caracteres = string.ascii_uppercase + string.digits
        return "MRV-" + "".join(random.choices(caracteres, k=8))
