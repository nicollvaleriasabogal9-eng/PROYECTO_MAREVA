BEGIN;

-- Compatibilidad con el catálogo web existente.
ALTER TABLE paquete_turistico
    ADD COLUMN IF NOT EXISTS slug VARCHAR(150),
    ADD COLUMN IF NOT EXISTS emoji VARCHAR(10) NOT NULL DEFAULT '🧳';

UPDATE paquete_turistico
   SET slug = 'paquete-' || id_paquete
 WHERE slug IS NULL OR BTRIM(slug) = '';

ALTER TABLE paquete_turistico
    ALTER COLUMN slug SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_paquete_turistico_slug
    ON paquete_turistico (slug);

-- 1. Se retira por completo el módulo de insignias.
DROP TABLE IF EXISTS promocion_insignia CASCADE;
DROP TABLE IF EXISTS cliente_insignia CASCADE;
DROP TABLE IF EXISTS insignia CASCADE;

-- 2. La reserva conserva el cálculo del descuento que recibió el cliente.
ALTER TABLE reserva
    ADD COLUMN IF NOT EXISTS valor_base NUMERIC(12,2),
    ADD COLUMN IF NOT EXISTS porcentaje_descuento NUMERIC(5,2) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS valor_descuento NUMERIC(12,2) NOT NULL DEFAULT 0;

UPDATE reserva r
   SET valor_base = COALESCE(r.valor_base, r.valor_referencial, p.precio),
       valor_referencial = COALESCE(r.valor_referencial, p.precio),
       porcentaje_descuento = COALESCE(r.porcentaje_descuento, 0),
       valor_descuento = COALESCE(r.valor_descuento, 0)
  FROM paquete_turistico p
 WHERE p.id_paquete = r.id_paquete;

ALTER TABLE reserva
    ALTER COLUMN valor_base SET NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
          FROM pg_constraint
         WHERE conname = 'chk_reserva_porcentaje_descuento'
    ) THEN
        ALTER TABLE reserva
            ADD CONSTRAINT chk_reserva_porcentaje_descuento
            CHECK (porcentaje_descuento BETWEEN 0 AND 100);
    END IF;
END $$;

-- 3. Los guías obtienen credenciales propias sin duplicarlos en cliente.
ALTER TABLE guia_turistico
    ADD COLUMN IF NOT EXISTS contrasena VARCHAR(255);

UPDATE guia_turistico
   SET contrasena = 'Guia_mareva01'
 WHERE contrasena IS NULL OR BTRIM(contrasena) = '';

ALTER TABLE guia_turistico
    ALTER COLUMN contrasena SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_guia_turistico_correo_lower
    ON guia_turistico (LOWER(correo))
    WHERE correo IS NOT NULL;

COMMIT;

-- Contraseña inicial de los guías de prueba: Guia_mareva01
-- Al iniciar sesión por primera vez, MAREVA la sustituye por un hash seguro.
