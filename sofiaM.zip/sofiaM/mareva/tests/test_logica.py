import sys
import unittest
from decimal import Decimal
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from utils.calculos_reserva import calcular_totales
from utils.estados_reserva import transicion_valida


class CalculoReservaTest(unittest.TestCase):
    def test_aplica_descuento_a_paquete_y_extras(self):
        resultado = calcular_totales(1_000_000, 2, 100_000, 10)
        self.assertEqual(resultado["valor_base"], Decimal("2100000.00"))
        self.assertEqual(resultado["valor_descuento"], Decimal("210000.00"))
        self.assertEqual(resultado["valor_final"], Decimal("1890000.00"))

    def test_limita_porcentaje_invalido(self):
        self.assertEqual(
            calcular_totales(500_000, 1, 0, 120)["valor_final"],
            Decimal("0.00"),
        )
        self.assertEqual(
            calcular_totales(500_000, 1, 0, -5)["valor_final"],
            Decimal("500000.00"),
        )


class EstadosGuiaTest(unittest.TestCase):
    def test_transiciones_permitidas(self):
        self.assertTrue(transicion_valida("confirmada", "en_proceso"))
        self.assertTrue(transicion_valida("en_proceso", "completada"))

    def test_transiciones_bloqueadas(self):
        self.assertFalse(transicion_valida("completada", "confirmada"))
        self.assertFalse(transicion_valida("confirmada", "completada"))


if __name__ == "__main__":
    unittest.main()
